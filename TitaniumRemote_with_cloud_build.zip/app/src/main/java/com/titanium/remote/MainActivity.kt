package com.titanium.remote

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

/** Titanium Remote protocol v1: TV is the HTTP client and polls this phone. */
class MainActivity : Activity() {
    private val queue = LinkedBlockingQueue<JSONObject>()
    @Volatile private var server: ServerSocket? = null
    private lateinit var status: TextView
    private lateinit var address: TextView
    private lateinit var log: TextView
    private lateinit var mode: Spinner
    private lateinit var serverField: EditText
    private lateinit var userField: EditText
    private lateinit var passField: EditText
    private lateinit var m3uField: EditText
    private lateinit var textField: EditText
    private val token = UUID.randomUUID().toString().replace("-", "")
    private val port = 8765

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(7, 17, 31))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
n        }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, 8, 0, 8)
        }
        root.addView(label("TITANIUM REMOTE", 25f))
        root.addView(label("Phone and Samsung TV must use the same Wi-Fi network.", 14f))
        status = label("Starting local connection…", 15f); root.addView(status)
        address = label("Finding phone address…", 14f); root.addView(address)
        root.addView(label("On the TV: Settings → Phone remote → enter the phone address and pairing code.", 13f))

        root.addView(label("IPTV SOURCE", 18f))
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Xtream Codes", "M3U URL"))
        }
        root.addView(mode)
        serverField = edit("Server URL (e.g. http://host:port)")
        userField = edit("Username")
        passField = edit("Password")
        m3uField = edit("Paste the complete http(s) M3U URL")
        root.addView(serverField); root.addView(userField); root.addView(passField); root.addView(m3uField)
        fun refreshFields() {
            val xtream = mode.selectedItemPosition == 0
            serverField.visibility = if (xtream) android.view.View.VISIBLE else android.view.View.GONE
            userField.visibility = if (xtream) android.view.View.VISIBLE else android.view.View.GONE
            passField.visibility = if (xtream) android.view.View.VISIBLE else android.view.View.GONE
            m3uField.visibility = if (xtream) android.view.View.GONE else android.view.View.VISIBLE
        }
        mode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = refreshFields()
        }
        refreshFields()
        root.addView(Button(this).apply {
            text = "SEND SOURCE TO TV"
            setOnClickListener {
                if (mode.selectedItemPosition == 0) {
                    val srv = serverField.text.toString().trim()
                    val usr = userField.text.toString().trim()
                    val pwd = passField.text.toString()
                    if (srv.isBlank() || usr.isBlank() || pwd.isBlank()) {
                        status.text = "Enter server URL, username and password."; return@setOnClickListener
                    }
                    queue.offer(JSONObject().put("type", "iptv_credentials").put("format", "xtream")
                        .put("server", srv).put("username", usr).put("password", pwd))
                } else {
                    val url = m3uField.text.toString().trim()
                    if (!url.matches(Regex("^https?://\\S+$", RegexOption.IGNORE_CASE)) || url.length > 2000) {
                        status.text = "Enter a valid complete http(s) M3U URL."; return@setOnClickListener
                    }
                    queue.offer(JSONObject().put("type", "iptv_credentials").put("format", "m3u").put("url", url))
                }
                status.text = "Source queued. Open the Add source screen on TV if needed."
            }
        })

        root.addView(label("REMOTE KEYBOARD", 18f))
        textField = edit("Type text to send to the active TV field")
        root.addView(textField)
        root.addView(Button(this).apply {
            text = "SEND TEXT"
            setOnClickListener {
                val value = textField.text.toString()
                if (value.isBlank()) status.text = "Type something first."
                else {
                    queue.offer(JSONObject().put("type", "text").put("text", value))
                    status.text = "Text queued for TV."; textField.text.clear()
                }
            }
        })
        root.addView(label("Keep this screen open while using the remote.", 12f))
        log = label("Waiting for TV to connect…", 12f); root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
        startServer()
    }

    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        setPadding(12, 10, 12, 10)
    }

    private fun startServer() {
        thread(name = "TitaniumRemoteHTTP") {
            try {
                val ss = ServerSocket(port, 20, InetAddress.getByName("0.0.0.0"))
                server = ss
                runOnUiThread {
                    status.text = "● Local server running"
                    address.text = "Phone address: http://${localIp()}:$port\nPairing code: $token"
                    log.text = "Protocol v1 • Waiting for TV connection"
                }
                while (!ss.isClosed) {
                    val socket = ss.accept()
                    thread(name = "TitaniumRemoteClient") { handle(socket) }
                }
            } catch (e: Exception) {
                if (server?.isClosed != true) runOnUiThread { status.text = "Server error: ${e.message}" }
            }
        }
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 4000
                val reader = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                val method = parts.getOrNull(0)?.uppercase() ?: "GET"
                val path = parts.getOrNull(1)?.substringBefore('?') ?: "/"
                var auth = ""
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.startsWith("X-Titanium-Token:", ignoreCase = true)) auth = line.substringAfter(':').trim()
                }

                val statusCode: Int
                val body: ByteArray
                if (method == "OPTIONS") {
                    statusCode = 204; body = ByteArray(0)
                } else {
                    statusCode = 200
                    val response = when {
                        method != "GET" -> JSONObject().put("error", "method_not_allowed")
                        path == "/health" -> JSONObject().put("app", "Titanium Remote").put("protocol", 1).put("status", "ok")
                        path == "/pair" -> JSONObject().put("paired", auth == token).put("token_required", true)
                        path == "/next" && auth == token -> queue.poll() ?: JSONObject().put("type", "none")
                        path == "/next" -> JSONObject().put("error", "unauthorized")
                        path == "/ack" && auth == token -> JSONObject().put("ok", true)
                        else -> JSONObject().put("error", "not_found")
                    }
                    body = response.toString().toByteArray(Charsets.UTF_8)
                }
                val reason = if (statusCode == 204) "No Content" else "OK"
                val headers = "HTTP/1.1 $statusCode $reason\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: X-Titanium-Token, Content-Type\r\n" +
                    "Access-Control-Max-Age: 600\r\n" +
                    "Cache-Control: no-store, no-cache, must-revalidate\r\n" +
                    "Pragma: no-cache\r\n" +
                    "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
                val out = s.getOutputStream()
                out.write(headers.toByteArray(Charsets.US_ASCII)); out.write(body); out.flush()
                runOnUiThread { log.text = "TV request: $method $path" }
            } catch (_: Exception) { /* TV may close a polling request during reconnect. */ }
        }
    }

    private fun localIp(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val addresses = interfaces.nextElement().inetAddresses
                while (addresses.hasMoreElements()) {
                    val a = addresses.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: "unknown"
                }
            }
        } catch (_: Exception) {}
        return "unknown"
    }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}

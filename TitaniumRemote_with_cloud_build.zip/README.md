# Titanium Remote for Android

Android companion source for `TitaniumTVbeta3_503.wgt` (Titanium Remote protocol v1).

## Features
- Shows the phone's local IPv4 address and pairing code.
- Runs the HTTP server on TCP port 8765; the TV initiates pairing and polls the phone.
- Sends text to the currently active TV text field.
- Sends Xtream Codes credentials or an M3U URL to the TV's Add Source flow.
- Supports CORS `OPTIONS` preflight and allows the TV's `X-Titanium-Token` header.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35), allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

This delivery is Android Studio source code, not a prebuilt APK. An Android SDK/Gradle build environment is required to produce the APK.

## Use
1. Install the generated APK and connect the phone to the same Wi-Fi as the Samsung TV.
2. Open the app and leave it in the foreground.
3. On the TV, open Settings → Phone remote.
4. Enter the phone address and pairing code displayed in the app, then connect.
5. To send text, open a text field on the TV, type on the phone and tap **SEND TEXT**.
6. To send an IPTV source, choose Xtream Codes or M3U and tap **SEND SOURCE TO TV**. Review and confirm on the TV.

See `TV_INTEGRATION_PROTOCOL.md` for endpoint and payload details.

## Network safety
The local HTTP connection is not encrypted. Use a trusted private Wi-Fi network only. Do not expose TCP port 8765 to the public internet. Keep the app open during use.

package com.titanium.remote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.view.inputmethod.EditorInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import kotlin.math.abs

private fun tr(ar: String, en: String): String = if (Hub.ar) ar else en
private fun dp(v: Int): Int = Ui.dp(v)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var pageHost: FrameLayout
    private lateinit var mainCol: LinearLayout
    private val pages = ArrayList<View>()
    private val tabs = ArrayList<LinearLayout>()
    private var tab = 0
    // tab bar position -> page index (the Preferences page lives behind the header icon, not in the tab bar)
    private val navPages = intArrayOf(0, 1, 2, 5, 4)
    private var prefsBtnIcon: ImageView? = null

    private lateinit var chipDot: View
    private lateinit var chipText: TextView
    private lateinit var pairPanel: View
    private lateinit var remotePanel: View
    private lateinit var pairStatus: TextView
    private lateinit var pairIp: TextView
    private lateinit var codeBox: EditText
    private lateinit var padFace: PadFace
    private var settingCode = false
    private var forcePair = false   // paired on the phone but the TV lost it: show the pairing screen again without "Unpair"

    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hub.init(this)
        Ui.init(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.layoutDirection = if (Hub.ar) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR   // follows the language chosen in Settings
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = insetsOf(ins)
            v.setPadding(0, i[0], 0, i[1])
            ins
        }
        setContentView(root)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        mainCol = col
        col.addView(buildHeader())
        col.addView(buildNav())
        pageHost = FrameLayout(this)
        col.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
        pages.add(buildRemotePage())
        pages.add(buildSourcePage())
        pages.add(buildKeyboardPage())
        pages.add(buildSettingsPage())
        pages.add(buildRecoveryPage())
        pages.add(buildSubsPage())   // index 5: Keys
        for (p in pages) pageHost.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
        selectTab(0)

        startRemoteService()
        handleIntent(intent)
        if (savedInstanceState == null) showSplash()   // every fresh launch; not when the screen is only rebuilt (language / layout switch)
        root.requestApplyInsets()
    }

    @Suppress("DEPRECATION")
    private fun insetsOf(ins: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            intArrayOf(i.top, i.bottom)
        } else {
            intArrayOf(ins.systemWindowInsetTop, ins.systemWindowInsetBottom)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Hub.onChange = { refresh() }
        Hub.onKbd = { on -> onTvKbd(on) }
        startRemoteService()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        Hub.onChange = null
        Hub.onKbd = null
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startRemoteService() {
        try {
            startForegroundService(Intent(this, RemoteService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "titanium") {
            val c = d.getQueryParameter("c") ?: return
            handleCode(c)
        }
    }

    // ------------------------------------------------------------------ splash (the same intro as the TV app)
    private var introPlayer: MediaPlayer? = null

    private fun playIntroSound() {
        if (!Hub.introSound()) return
        try {
            val mp = MediaPlayer.create(this, R.raw.intro_snd) ?: return
            mp.setVolume(0.9f, 0.9f)
            mp.setOnCompletionListener {
                try { it.release() } catch (_: Exception) {}
                if (introPlayer === it) introPlayer = null
            }
            introPlayer = mp
            mp.start()
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        Hub.onLibrary = null
        Hub.onAbk = null
        Hub.onKeys = null
        try { introPlayer?.release() } catch (_: Exception) {}
        introPlayer = null
        super.onDestroy()
    }

    /**
     * App intro: the real Titanium logo plays its intro (play + bars slide apart, wordmark), then the logo glides up
     * and the remote slides in from the bottom (see [TitaniumIntro]). Same intro sound as before.
     * A tap skips it.
     */
    private fun showSplash() {
        val sp = FrameLayout(this)
        sp.setBackgroundColor(Color.BLACK)
        sp.isClickable = true

        sp.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val intro = WidgetIntro(this)
        sp.addView(intro, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(sp, FrameLayout.LayoutParams(MATCH, MATCH))

        // the real screen waits underneath: header logo hidden, nav + page below the screen
        val header = mainCol.getChildAt(0)
        val rest = listOf(mainCol.getChildAt(1), mainCol.getChildAt(2))
        header.alpha = 0f
        for (v in rest) { v.alpha = 0f; v.translationY = dp(380).toFloat() }

        var finished = false
        var exiting = false
        val finish = object : Runnable {
            override fun run() {
                if (finished) return
                finished = true
                ui.removeCallbacks(this)
                try { intro.stop() } catch (_: Exception) {}
                header.animate().cancel()
                header.alpha = 1f
                for (v in rest) { v.animate().cancel(); v.translationY = 0f; v.alpha = 1f }
                sp.animate().alpha(0f).setDuration(if (exiting) 60 else 160).withEndAction {
                    if (sp.parent != null) root.removeView(sp)
                    askNotificationPermission()
                }.start()
            }
        }
        val exit = Runnable {
            if (finished || exiting) return@Runnable
            exiting = true
            val logoW = (dp(26) * 340f / 69f)
            val ty = dp(14) + dp(26) / 2f
            val tx = if (Hub.ar) sp.width - dp(20) - logoW / 2f else dp(20) + logoW / 2f
            val tScale = (logoW * .9f) / (intro.width * .8f)
            intro.exit(WidgetIntro.EXIT_MS, tx, ty, tScale)
            // black cover fades out while the remote rises from the bottom and the logo glides up into the header
            val fade = ValueAnimator.ofFloat(0f, 1f)
            fade.duration = WidgetIntro.EXIT_MS
            fade.addUpdateListener { sp.setBackgroundColor(Color.argb(((1f - it.animatedValue as Float) * 255).toInt(), 0, 0, 0)) }
            fade.start()
            for (v in rest) {
                v.animate().translationY(0f).alpha(1f).setDuration(WidgetIntro.EXIT_MS)
                    .setInterpolator(PathInterpolator(.22f, .8f, .24f, 1f)).start()
            }
            header.animate().alpha(1f).setStartDelay((WidgetIntro.EXIT_MS * .55f).toLong()).setDuration((WidgetIntro.EXIT_MS * .45f).toLong()).start()
            ui.postDelayed(finish, WidgetIntro.EXIT_MS + 80)
        }
        sp.setOnClickListener { finish.run() }
        sp.post {
            try { intro.play() } catch (_: Exception) { finish.run() }
        }
        playIntroSound()
        ui.postDelayed(exit, WidgetIntro.EXIT_AT)
        // safety net: whatever happens, the black cover must never stay on the screen
        ui.postDelayed({ finish.run(); if (sp.parent != null) root.removeView(sp) }, WidgetIntro.DURATION + 1500)
    }

    private fun askNotificationPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ header + navigation
    private fun buildHeader(): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(20), dp(14), dp(20), dp(10))

        val logo = WidgetLogo(this, dp(26))
        logo.showFinal()
        logo.layoutDirection = View.LAYOUT_DIRECTION_LTR   // the logo is drawn left-to-right in both languages
        h.addView(logo, LinearLayout.LayoutParams(logo.logoWidth, dp(26)))

        val sp = View(this)
        h.addView(sp, LinearLayout.LayoutParams(0, 1, 1f))

        val chip = LinearLayout(this)
        chip.orientation = LinearLayout.HORIZONTAL
        chip.gravity = Gravity.CENTER_VERTICAL
        chip.setPadding(dp(14), dp(7), dp(14), dp(7))
        chip.background = Ui.glass(20)
        chipDot = View(this)
        chipDot.background = Ui.oval(Ui.MUTED)
        val dl = LinearLayout.LayoutParams(dp(11), dp(11))
        dl.marginEnd = dp(8)
        chip.addView(chipDot, dl)
        Ui.pressable(chip)
        chip.setOnClickListener {
            val seenNow = System.currentTimeMillis() - Hub.lastSeen < 7000
            if (forcePair) {
                forcePair = false
                refresh()
            } else if (Hub.isPaired() && !seenNow) {
                forcePair = true
                clearCodeBox()
                selectTab(0)
                refresh()
            } else selectTab(3)
        }
        chipText = Ui.text(this, "", 13f, Ui.TEXT, 5)
        chip.addView(chipText)
        h.addView(chip)

        // Preferences: icon only, in the corner next to the connection status (a sliders icon, so it is not mixed up with other gear icons)
        val prefsBtn = FrameLayout(this)
        prefsBtn.background = Ui.glass(20)
        val prefsIc = Ui.icon(this, R.drawable.ic_tune, 20, TAB_OFF)
        prefsBtnIcon = prefsIc
        prefsBtn.addView(prefsIc, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        prefsBtn.contentDescription = tr("التفضيلات", "Preferences")
        Ui.pressable(prefsBtn)
        prefsBtn.setOnClickListener { selectTab(if (tab == 3) 0 else 3) }
        h.addView(prefsBtn, LinearLayout.LayoutParams(dp(38), dp(34)).also { it.marginStart = dp(8) })

        return h
    }

    // ------------------------------------------------------------------ settings page (4th tab)
    private lateinit var setPairVal: TextView
    private lateinit var setIpVal: TextView
    private lateinit var setUnpair: View

    private fun sectionTitle(t: String): TextView {
        val v = Ui.text(this, t, 12f, Ui.MUTED, 5)
        v.setPadding(dp(4), 0, dp(4), 0)
        v.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(22); it.bottomMargin = dp(8) }
        return v
    }

    private fun settingsCard(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.glass(20)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        return c
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(Ui.HAIR)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, 1).also { it.topMargin = dp(12); it.bottomMargin = dp(12) }
        return v
    }

    private fun smallHint(t: String): TextView {
        val v = Ui.text(this, t, 12f, Ui.MUTED, 4)
        v.setLineSpacing(dp(2).toFloat(), 1f)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(4); it.marginEnd = dp(56) }
        return v
    }

    /** Label on one side, value on the other. */
    private fun infoRow(label: String, value: TextView): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, label, 15f, Ui.TEXT, 5), LinearLayout.LayoutParams(0, WRAP, 1f))
        value.gravity = Gravity.END
        r.addView(value, LinearLayout.LayoutParams(WRAP, WRAP))
        return r
    }

    private fun buildSettingsPage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("التفضيلات", "Preferences"), 22f, Ui.TEXT, 7))

        // ---- language ----
        p.addView(sectionTitle(tr("اللغة", "Language")))
        val langCard = settingsCard()
        val langRow = LinearLayout(this)
        langRow.orientation = LinearLayout.HORIZONTAL
        langRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
        fun langBtn(label: String, code: String) {
            val sel = Hub.ar == (code == "ar")
            val b = Ui.pill(this, label, if (sel) Ui.ACCENT_DEEP else Ui.SURF, if (sel) Color.WHITE else Ui.TEXT) {
                if (!sel) {
                    Hub.setLang(code)
                    recreate()
                }
            }
            langRow.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        langBtn("العربية", "ar")
        langBtn("English", "en")
        langCard.addView(langRow)
        p.addView(langCard)

        // ---- remote ----
        p.addView(sectionTitle(tr("الريموت", "Remote")))
        val remote = settingsCard()
        remote.addView(Ui.text(this, tr("شكل الريموت", "Remote layout"), 15f, Ui.TEXT, 5))
        val layRow = LinearLayout(this)
        layRow.orientation = LinearLayout.HORIZONTAL
        layRow.layoutDirection = View.LAYOUT_DIRECTION_LTR
        fun layBtn(label: String, n: Int) {
            val sel = Hub.layout() == n
            val b = Ui.pill(this, label, if (sel) Ui.ACCENT_DEEP else Ui.SURF, if (sel) Color.WHITE else Ui.TEXT) {
                if (!sel) {
                    Hub.setLayout(n)
                    recreate()
                }
            }
            layRow.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.setMargins(dp(4), dp(8), dp(4), dp(4)) })
        }
        layBtn(tr("كلاسيك", "Classic"), 0)
        layBtn(tr("أقواس", "Arcs"), 1)
        remote.addView(layRow)
        remote.addView(divider())
        remote.addView(touchRow())
        remote.addView(smallHint(tr("بيستبدل لوحة الأسهم بلوحة لمس في صفحة الريموت.", "Swaps the arrows pad for a touchpad on the remote page.")))
        remote.addView(divider())
        remote.addView(soundRow())
        remote.addView(smallHint(tr("نفس صوت انترو تطبيق التلفزيون عند فتح التطبيق.", "Plays the TV app's intro sound when the app opens.")))
        remote.addView(divider())
        remote.addView(switchRow(tr("الاهتزاز عند اللمس", "Haptic feedback"), Hub.haptics()) { Hub.setHaptics(it); if (it) Ui.haptic(remote) })
        remote.addView(smallHint(tr("اهتزاز خفيف مع كل زر في الريموت.", "A light buzz with every key on the remote.")))
        remote.addView(divider())
        remote.addView(switchRow(tr("صوت الضغط", "Key click sound"), Hub.clickSound()) { Hub.setClickSound(it); if (it) Ui.click(this) })
        remote.addView(smallHint(tr("صوت نقرة خفيف مع كل زر في الريموت.", "A soft click sound with every key on the remote.")))
        p.addView(remote)

        // ---- TV / connection ----
        p.addView(sectionTitle(tr("التلفزيون والاتصال", "TV & connection")))
        val tv = settingsCard()
        setPairVal = Ui.text(this, "", 14f, Ui.MUTED, 5)
        tv.addView(infoRow(tr("حالة الربط", "Pairing"), setPairVal))
        tv.addView(divider())
        tv.addView(infoRow(tr("هذا الجهاز", "This device"), Ui.text(this, Hub.deviceName(), 14f, Ui.MUTED, 5)))
        tv.addView(divider())
        setIpVal = Ui.text(this, "", 14f, Ui.MUTED, 5)
        setIpVal.textDirection = View.TEXT_DIRECTION_LTR
        tv.addView(infoRow(tr("العنوان والمنفذ", "IP & port"), setIpVal))
        p.addView(tv)

        setUnpair = Ui.pill(this, tr("إلغاء الربط", "Unpair TV"), Color.TRANSPARENT, Ui.RED, R.drawable.ic_tv, Ui.BORDER) { confirmUnpair() }
        p.addView(setUnpair, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(18) })

        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
        val foot = Ui.text(this, "Titanium Remote $ver", 12f, Ui.MUTED, 4)
        foot.gravity = Gravity.CENTER
        p.addView(foot, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(26) })
        return scrollPage(p)
    }

    /** Label + switch row used in the phone settings. */
    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, label, 15f, Ui.TEXT, 5), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = android.widget.Switch(this)
        sw.isChecked = checked
        val on = intArrayOf(android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Ui.ACCENT, Ui.MUTED))
        sw.trackTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Color.argb(90, 110, 168, 255), Color.argb(60, 255, 255, 255)))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        r.addView(sw)
        return r
    }

    /** "Intro sound" switch (the intro plays the same sound as the TV's). */
    private fun soundRow(): View =
        switchRow(tr("صوت الانترو", "Intro sound"), Hub.introSound()) { Hub.setIntroSound(it) }

    /** "Touchpad instead of arrows" switch: decides what the middle of the remote page shows. */
    private fun touchRow(): View =
        switchRow(tr("لوحة لمس بدل الأسهم", "Touchpad instead of arrows"), Hub.touchMode()) {
            Hub.setTouchMode(it)
            setPadMode(it)
        }

    private val TAB_OFF = Color.parseColor("#B8BEC9")

    private fun buildNav(): View {
        // top tab bar (as in the reference): one rounded strip, thin dividers, the active tab has a tinted pill
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(12), dp(2), dp(12), dp(8))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        nav.layoutDirection = if (Hub.ar) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        nav.setPadding(dp(6), dp(8), dp(6), dp(8))
        nav.background = Ui.rect(Color.parseColor("#101216"), 26, 1, Ui.HAIR)
        wrap.addView(nav, FrameLayout.LayoutParams(MATCH, WRAP))
        val items = listOf(
            Pair(R.drawable.ic_remote, tr("ريموت", "Remote")),
            Pair(R.drawable.ic_list, tr("المصدر", "Source")),
            Pair(R.drawable.ic_keyboard, tr("كتابة وبحث", "Type & search")),
            Pair(R.drawable.ic_key, tr("مفاتيح", "Keys")),
            Pair(R.drawable.ic_recovery, tr("الاسترجاع", "Recovery"))
        )
        for ((idx, item) in items.withIndex()) {
            if (idx > 0) {
                val dv = View(this)
                dv.setBackgroundColor(Ui.HAIR)
                nav.addView(dv, LinearLayout.LayoutParams(1, dp(40)))
            }
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(2), 0, dp(2))
            val pill = FrameLayout(this)
            val ic = Ui.icon(this, item.first, 24, TAB_OFF)
            pill.addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            t.addView(pill, LinearLayout.LayoutParams(dp(50), dp(32)))
            val lbl = Ui.text(this, item.second, 11f, TAB_OFF, 5)
            lbl.maxLines = 1
            val ll = LinearLayout.LayoutParams(WRAP, WRAP)
            ll.topMargin = dp(3)
            t.addView(lbl, ll)
            t.setOnClickListener { selectTab(navPages[idx]); if (navPages[idx] == 2) autoOpenSearch() }
            Ui.pressable(t)
            tabs.add(t)
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return wrap
    }

    /** The TV opened its search box: show this phone's typing page with the keyboard open (on = false: the box closed). */
    private var typeBox: EditText? = null
    private var kbdAuto = false
    private var tvBoxOpen = false

    /** Tapping the "Type & search" tab opens the TV's search box itself (the TV answers with /kbd_on, which opens the keyboard here). */
    private fun autoOpenSearch() {
        val live = System.currentTimeMillis() - Hub.lastSeen < 7000
        if (Hub.isPaired() && live && !tvBoxOpen) key("search")
    }

    private fun onTvKbd(on: Boolean) {
        tvBoxOpen = on
        if (on) {
            selectTab(2)
            kbdAuto = true
            typeBox?.let { b ->
                b.requestFocus()
                b.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(b, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) }, 200)
            }
        } else if (kbdAuto) {
            val wasType = tab == 2
            kbdAuto = false
            hideKeyboard()
            if (wasType) selectTab(0)
        }
    }

    private fun selectTab(i: Int) {
        kbdAuto = false
        tab = i
        for ((idx, p) in pages.withIndex()) p.visibility = if (idx == i) View.VISIBLE else View.GONE
        for ((idx, t) in tabs.withIndex()) {
            val on = navPages[idx] == i
            val pill = t.getChildAt(0) as FrameLayout
            (pill.getChildAt(0) as ImageView).setColorFilter(if (on) Ui.ACCENT else TAB_OFF)
            pill.background = if (on) Ui.rect(Color.argb(90, 110, 168, 255), 15) else null
            (t.getChildAt(1) as TextView).setTextColor(if (on) Ui.TEXT else TAB_OFF)
        }
        prefsBtnIcon?.setColorFilter(if (i == 3) Ui.ACCENT else TAB_OFF)
        hideKeyboard()
    }

    private fun scrollPage(content: View): ScrollView {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(8), dp(20), dp(24))
        return l
    }

    private fun field(hint: String, type: Int): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        e.typeface = Ui.f4
        e.textSize = 15f
        val focused = Ui.glass(14, true)
        focused.setStroke(dp(1), Ui.ACCENT)
        val states = StateListDrawable()
        states.addState(intArrayOf(android.R.attr.state_focused), focused)
        states.addState(intArrayOf(), Ui.glass(14))
        e.background = states
        e.setPadding(dp(16), dp(14), dp(16), dp(14))
        return e
    }

    private fun gap(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    // ------------------------------------------------------------------ remote page
    private fun buildRemotePage(): View {
        val page = FrameLayout(this)
        pairPanel = buildPairPanel()
        page.addView(scrollPage(pairPanel), FrameLayout.LayoutParams(MATCH, MATCH))

        // the remote never scrolls: DesignCanvas scales the whole layout to fit the page
        remotePanel = buildRemotePanel()
        page.addView(remotePanel, FrameLayout.LayoutParams(MATCH, MATCH))
        return page
    }

    private fun step(n: String, text: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val badge = Ui.text(this, n, 13f, Ui.ACCENT, 7)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.oval(Color.argb(40, 110, 168, 255), 1, Color.argb(90, 110, 168, 255))
        val bl = LinearLayout.LayoutParams(dp(30), dp(30))
        bl.marginEnd = dp(12)
        r.addView(badge, bl)
        val t = Ui.text(this, text, 14f, Ui.MUTED, 4)
        t.setLineSpacing(dp(3).toFloat(), 1f)
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    private fun buildPairPanel(): View {
        val p = vbox()
        val hero = FrameLayout(this)
        hero.background = Ui.glass(22, true)
        hero.addView(Ui.icon(this, R.drawable.ic_tv, 30, Ui.ACCENT), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        p.addView(hero, LinearLayout.LayoutParams(dp(64), dp(64)).also { it.topMargin = dp(8) })
        p.addView(Ui.text(this, tr("اربط التلفزيون", "Pair your TV"), 22f, Ui.TEXT, 7), LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(16) })

        val steps = LinearLayout(this)
        steps.orientation = LinearLayout.VERTICAL
        steps.background = Ui.glass(20)
        steps.setPadding(dp(16), dp(16), dp(16), dp(16))
        steps.addView(step(tr("١", "1"), tr("على التلفزيون افتح: الإعدادات ← ريموت تيتانيوم.", "On the TV open: Settings → Titanium Remote.")))
        steps.addView(step(tr("٢", "2"), tr("هيظهر QR وكود من ٤ أرقام.", "A QR and a 4-digit code appear.")), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) })
        steps.addView(step(tr("٣", "3"), tr("امسح الـ QR أو اكتب الكود هنا. الربط بيتحفظ ومش هتكرره تاني.", "Scan the QR or type the code here. The pairing is saved — you won't repeat it.")), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) })
        p.addView(steps, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(18) })

        val scan = Ui.pill(this, tr("مسح QR من التلفزيون", "Scan the QR on the TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_qr) { scanQr() }
        val sl = LinearLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = dp(22)
        p.addView(scan, sl)

        val orRow = LinearLayout(this)
        orRow.orientation = LinearLayout.HORIZONTAL
        orRow.gravity = Gravity.CENTER_VERTICAL
        val l1 = View(this)
        l1.setBackgroundColor(Ui.HAIR)
        val l2 = View(this)
        l2.setBackgroundColor(Ui.HAIR)
        orRow.addView(l1, LinearLayout.LayoutParams(0, 1, 1f))
        val orLbl = Ui.text(this, tr("أو اكتب الكود", "or type the code"), 13f, Ui.MUTED, 5)
        orRow.addView(orLbl, LinearLayout.LayoutParams(WRAP, WRAP).also { it.setMargins(dp(12), 0, dp(12), 0) })
        orRow.addView(l2, LinearLayout.LayoutParams(0, 1, 1f))
        p.addView(orRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(20) })

        codeBox = field("0000", InputType.TYPE_CLASS_NUMBER)
        codeBox.gravity = Gravity.CENTER
        codeBox.textSize = 34f
        codeBox.typeface = Ui.f7
        codeBox.letterSpacing = 0.4f
        codeBox.textDirection = View.TEXT_DIRECTION_LTR
        codeBox.filters = arrayOf(InputFilter.LengthFilter(4))
        codeBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (settingCode) return
                val v = s?.toString() ?: ""
                if (v.length == 4) handleCode(v)
                else if (Hub.pendingCode != null) Hub.disarm()
            }
        })
        val cl = LinearLayout.LayoutParams(MATCH, WRAP)
        cl.topMargin = dp(10)
        p.addView(codeBox, cl)

        pairStatus = Ui.text(this, "", 13f, Ui.AMBER, 5)
        pairStatus.gravity = Gravity.CENTER
        pairStatus.setLineSpacing(dp(3).toFloat(), 1f)
        val pl = LinearLayout.LayoutParams(MATCH, WRAP)
        pl.topMargin = dp(16)
        p.addView(pairStatus, pl)

        pairIp = Ui.text(this, "", 12f, Ui.MUTED, 4)
        pairIp.gravity = Gravity.CENTER
        pairIp.textDirection = View.TEXT_DIRECTION_LTR
        val il = LinearLayout.LayoutParams(MATCH, WRAP)
        il.topMargin = dp(28)
        p.addView(pairIp, il)
        return p
    }

    private fun key(k: String, action: String = "press", rep: Boolean = false) {
        if (!Hub.isPaired()) {
            toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            return
        }
        Hub.send(JSONObject().put("type", "key").put("key", k).put("action", action).put("rep", rep))
    }

    private fun spaced(v: View, m: Int = 9): View {
        val lp = v.layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(m), dp(m), dp(m), dp(m))
        v.layoutParams = lp
        return v
    }

    private fun row(vararg vs: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        for (v in vs) r.addView(v)
        return r
    }

    private fun keyBtn(res: Int, k: String, size: Int = 60, iconDp: Int = 26): FrameLayout {
        val b = Ui.roundBtn(this, res, size, iconDp)
        Ui.holdRepeat(b, false) { rep -> key(k, "press", rep) }
        return b
    }

    /** Round coloured remote key (Users / Translate / Ask Titanium): flat disc + icon; sends the matching key to the TV. */
    private fun colorKey(res: Int, k: String, bg: Int, fg: Int, desc: String): FrameLayout {
        val f = FrameLayout(this)
        f.contentDescription = desc
        f.background = Ui.ripple(Ui.oval(bg), Ui.oval(Color.WHITE))
        val ic = ImageView(this)
        ic.setImageResource(res)
        ic.setColorFilter(fg)
        f.addView(ic, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        f.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        Ui.holdRepeat(f, false) { rep -> key(k, "press", rep) }
        return f
    }

    /** "Ask Titanium" key: light-blue disc with the logo's pause bars and two blinking eyes. */
    private fun askKey(k: String, desc: String): FrameLayout {
        val f = FrameLayout(this)
        f.contentDescription = desc
        f.foreground = Ui.ripple(Ui.oval(Color.TRANSPARENT), Ui.oval(Color.WHITE))
        f.addView(AskKeyFace(this), FrameLayout.LayoutParams(MATCH, MATCH))
        f.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        Ui.holdRepeat(f, false) { rep -> key(k, "press", rep) }
        return f
    }

    /** Flat charcoal round key with a solid white icon (top shortcut row). */
    private fun flatKey(res: Int, k: String): FrameLayout {
        val f = FrameLayout(this)
        f.background = Ui.ripple(Ui.oval(Color.parseColor("#2B2E34")), Ui.oval(Color.WHITE))
        val ic = ImageView(this)
        ic.setImageResource(res)
        ic.setColorFilter(Color.WHITE)
        f.addView(ic, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        f.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        Ui.holdRepeat(f, false) { rep -> key(k, "press", rep) }
        return f
    }

    private fun labelKey(label: String, k: String): TextView {
        val t = Ui.labelBtn(this, label)
        t.layoutParams = LinearLayout.LayoutParams(dp(84), dp(40))
        Ui.holdRepeat(t, false) { rep -> key(k, "press", rep) }
        return t
    }

    /** Round shortcut key with a small caption under it. */
    private fun shortcut(res: Int, k: String, label: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(flatKey(res, k))
        val t = Ui.text(this, label, 10f, Ui.MUTED, 5)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        c.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(3) })
        return c
    }

    /** Classic remote layout (design space 360 x 640 dp, see DesignCanvas): same glass look as the Arcs layout, labelled keys, 20 dp side margins. */
    private fun buildRemotePanel(): View {
        arcRing = null
        arcCanvas = null
        if (Hub.layout() == 1) return buildRemotePanelArcs()
        val cv = DesignCanvas(this)
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        cv.setBackgroundColor(if (night) Color.parseColor("#07080B") else Color.parseColor("#DFDFDF"))   // same black as the header: no seam
        val dark = Color.parseColor(if (night) "#1F212A" else "#363636")   // bluish charcoal glass, like the Arcs layout

        fun disc(res: Int, k: String, d: Float, cx: Float, cy: Float, frac: Float, desc: String, repeat: Boolean = false) {
            val v = DiscKey(this, res, frac, dark, Color.WHITE, desc, glass = true)
            Ui.holdRepeat(v, repeat) { rep -> key(k, "press", rep) }
            cv.put(v, cx, cy, d)
        }

        fun pill(res: Int, k: String, cx: Float, cy: Float, w: Float, h: Float, label: String, iconAfter: Boolean = false) {
            val v = PillKey(this, res, label, dark, Color.WHITE, label, iconAfter, glass = true)
            Ui.holdRepeat(v, false) { rep -> key(k, "press", rep) }
            cv.put(v, cx, cy, w, h)
        }

        fun tile(res: Int, k: String, cx: Float, cy: Float, label: String, bg: Int, tint: Int, fg: Int = Color.WHITE) {
            val v = TileKey(this, res, label, bg, tint, label, fg)
            Ui.holdRepeat(v, false) { rep -> key(k, "press", rep) }
            cv.put(v, cx, cy, 100f, 66f)
        }

        // top row: Series / Movies / Live (labelled)
        tile(R.drawable.ic_tv_s, "series", 70f, 42f, tr("مسلسلات", "Series"), dark, Color.parseColor("#6EA8FF"))
        tile(R.drawable.ic_movie_s, "movies", 180f, 42f, tr("أفلام", "Movies"), dark, Color.parseColor("#FFC857"))
        tile(R.drawable.ic_live_s, "live", 290f, 42f, tr("مباشر", "Live"), dark, Color.parseColor("#FF5A5A"))

        // TV settings (named so it is not confused with the app's own Preferences tab) / Sort & Filter
        pill(R.drawable.ic_gear_m, "settings", 96f, 108f, 152f, 42f, tr("إعدادات التلفزيون", "TV settings"))
        pill(R.drawable.ic_sort_m, "sortf", 264f, 108f, 152f, 42f, tr("ترتيب وفلترة", "Sort & Filter"))

        // big pad with faint arrow hints and an OK disc
        padFace = PadFace(this, night) { k, a, rep -> key(k, a, rep) }
        padFace.contentDescription = tr("لوحة التحكم", "Direction pad")
        padFace.glass = true
        padFace.wide = true   // touchpad mode: a wider rounded rectangle (arrows mode keeps the 190 dp circle)
        cv.put(padFace, 180f, 232f, 212f, 190f)

        // Back / Home: same style, inside the 20 dp margins
        disc(R.drawable.ic_arrow_back, "back", 52f, 46f, 304f, 0.5f, tr("رجوع", "Back"))
        disc(R.drawable.ic_home_s, "home", 52f, 314f, 304f, 0.5f, tr("الرئيسية", "Home"))

        // Users / Translate / Ask Titanium: the TV remote's red / yellow / blue keys (same colours, same functions), labelled, one straight row
        tile(R.drawable.ic_users, "red", 70f, 378f, tr("الحسابات", "Users"), Color.parseColor("#FF0000"), Color.WHITE)
        tile(R.drawable.ic_translate_b, "yellow", 180f, 378f, tr("ترجمة", "Translate"), Color.parseColor("#E2EC00"), Color.BLACK, Color.BLACK)
        tile(R.drawable.ic_sparkle, "blue", 290f, 378f, tr("اسأل تيتانيوم", "Ask Titanium"), Color.parseColor("#0A0AA8"), Color.WHITE)

        // media: back 10 s / play-pause / forward 10 s
        disc(R.drawable.ic_replay10, "rw10", 50f, 90f, 460f, 0.72f, tr("رجوع ١٠ ثوان", "Back 10 s"))
        disc(R.drawable.ic_play_s, "play_pause", 66f, 180f, 460f, 0.56f, tr("تشغيل / إيقاف", "Play / Pause"))
        disc(R.drawable.ic_forward10, "ff10", 50f, 270f, 460f, 0.72f, tr("تقديم ١٠ ثوان", "Forward 10 s"))

        // Previous / Next (the TV's CH- / CH+: previous / next episode or channel in the player)
        pill(R.drawable.ic_skip_prev, "ch_down", 81f, 528f, 122f, 42f, tr("السابق", "Previous"))
        disc(R.drawable.ic_info, "info", 46f, 180f, 528f, 0.58f, tr("معلومات البث", "Stream info"))
        pill(R.drawable.ic_skip_next, "ch_up", 279f, 528f, 122f, 42f, tr("التالي", "Next"), iconAfter = true)

        // Reorder categories (`green`); Sort & Filter is separate above. Kept clear of the bottom edge / gesture bar.
        pill(R.drawable.ic_reorder, "green", 180f, 580f, 320f, 42f, tr("ترتيب التصنيفات", "Reorder categories"))

        setPadMode(Hub.touchMode())
        return cv
    }

    /** "Arcs" layout (Settings > Remote layout): same top rows and Previous / Next as the classic one, four curved keys around a smaller pad. */
    private fun buildRemotePanelArcs(): View {
        val cv = DesignCanvas(this)
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        cv.setBackgroundColor(if (night) Color.parseColor("#07080B") else Color.parseColor("#DFDFDF"))
        val dark = Color.parseColor(if (night) "#1F212A" else "#363636")   // bluish charcoal like the reference

        fun disc(res: Int, k: String, d: Float, cx: Float, cy: Float, frac: Float, desc: String, bg: Int = dark, tint: Int = Color.WHITE) {
            val v = DiscKey(this, res, frac, bg, tint, desc, glass = true)
            Ui.holdRepeat(v, false) { rep -> key(k, "press", rep) }
            cv.put(v, cx, cy, d)
        }

        fun pill(res: Int, k: String, cx: Float, cy: Float, w: Float, h: Float, label: String, iconAfter: Boolean = false, bg: Int = dark) {
            val v = FitPill(this, res, label, bg, Color.WHITE, label, iconAfter)
            Ui.holdRepeat(v, false) { rep -> key(k, "press", rep) }
            cv.put(v, cx, cy, w, h)
        }

        // top row + Settings / Sort & Filter: identical to the classic layout
        fun tile(res: Int, k: String, cx: Float, label: String, tint: Int) {
            val v = TileKey(this, res, label, dark, tint, label)
            Ui.holdRepeat(v, false) { rep -> key(k, "press", rep) }
            cv.put(v, cx, 48f, 108f, 66f)
        }
        tile(R.drawable.ic_tv_s, "series", 62f, tr("مسلسلات", "Series"), Color.parseColor("#6EA8FF"))
        tile(R.drawable.ic_movie_s, "movies", 180f, tr("أفلام", "Movies"), Color.parseColor("#FFC857"))
        tile(R.drawable.ic_live_s, "live", 298f, tr("مباشر", "Live"), Color.parseColor("#FF5A5A"))
        pill(R.drawable.ic_gear_m, "settings", 97f, 128f, 158f, 46f, tr("الإعدادات", "Settings"))
        pill(R.drawable.ic_sort_m, "sortf", 263f, 128f, 158f, 46f, tr("ترتيب وفلترة", "Sort & Filter"))

        // curved keys on the pad's four diagonals: Back / Favorites on top, Translate / Ask Titanium below
        val arcs = ArcRing(this, night, Hub.ar, listOf(
            ArcRing.Arc(R.drawable.ic_arrow_back, tr("رجوع", "Back"), Color.WHITE, "back"),
            ArcRing.Arc(R.drawable.ic_heart, tr("المفضلة", "Favorites"), Color.parseColor("#FF5A7A"), "favorites"),
            ArcRing.Arc(R.drawable.ic_sparkle, tr("اسأل تيتانيوم", "Ask Titanium"), Color.WHITE, "blue", Color.parseColor("#0A0AA8"), Color.WHITE),
            ArcRing.Arc(R.drawable.ic_translate_b, tr("ترجمة", "Translate"), Color.BLACK, "yellow", Color.parseColor("#E2EC00"), Color.BLACK)
        )) { k -> key(k) }
        arcs.contentDescription = tr("مفاتيح منحنية", "Curved keys")
        arcRing = arcs
        arcCanvas = cv
        cv.put(arcs, 180f, 302f, 292.8f)

        padFace = PadFace(this, night) { k, a, rep -> key(k, a, rep) }
        padFace.contentDescription = tr("لوحة التحكم", "Direction pad")
        padFace.glass = true
        cv.put(padFace, 180f, 302f, 153.6f)

        // one row: Previous (round, left edge) / back 10 s / play-pause / forward 10 s / Next (round, right edge)
        disc(R.drawable.ic_skip_prev, "ch_down", 46f, 32f, 486f, 0.5f, tr("السابق", "Previous"))
        disc(R.drawable.ic_replay10, "rw10", 50f, 100f, 486f, 0.72f, tr("رجوع ١٠ ثوان", "Back 10 s"))
        disc(R.drawable.ic_playpause_c, "play_pause", 66f, 180f, 486f, 0.6f, tr("تشغيل / إيقاف", "Play / Pause"))
        disc(R.drawable.ic_forward10, "ff10", 50f, 260f, 486f, 0.72f, tr("تقديم ١٠ ثوان", "Forward 10 s"))
        disc(R.drawable.ic_skip_next, "ch_up", 46f, 328f, 486f, 0.5f, tr("التالي", "Next"))

        // Users (red) and Reorder categories
        pill(R.drawable.ic_users, "red", 85f, 566f, 130f, 44f, tr("الحسابات", "Users"), bg = Color.parseColor("#C80000"))
        disc(R.drawable.ic_info, "info", 44f, 180f, 566f, 0.58f, tr("معلومات البث", "Stream info"))
        pill(R.drawable.ic_reorder_m, "green", 275f, 566f, 130f, 44f, tr("ترتيب التصنيفات", "Reorder"), bg = Color.parseColor("#1E9E4A"))

        setPadMode(Hub.touchMode())
        return cv
    }

    private var arcRing: ArcRing? = null
    private var arcCanvas: DesignCanvas? = null

    private fun setPadMode(touch: Boolean) {
        val ring = arcRing
        val cv = arcCanvas
        if (ring != null && cv != null) {
            // Arcs layout: in touchpad mode the pad becomes a rounded rectangle and the four curved keys follow its outline
            ring.rect = touch
            padFace.wide = touch
            if (touch) {
                cv.update(ring, 180f, 302f, 304f, 278f)
                cv.update(padFace, 180f, 302f, 190f, 164f)
            } else {
                cv.update(ring, 180f, 302f, 292.8f, 292.8f)
                cv.update(padFace, 180f, 302f, 153.6f, 153.6f)
            }
        }
        padFace.touchMode = touch
        padFace.invalidate()
    }

    private fun clearCodeBox() {
        if (!::codeBox.isInitialized) return
        settingCode = true
        codeBox.setText("")
        settingCode = false
    }

    private fun confirmUnpair() {
        AlertDialog.Builder(this)
            .setTitle(tr("إلغاء الربط؟", "Unpair the TV?"))
            .setMessage(tr("هتحتاج تربط التلفزيون من جديد بكود.", "You will need to pair again with a code."))
            .setPositiveButton(tr("إلغاء الربط", "Unpair")) { _, _ ->
                Hub.forgetAll()
                clearCodeBox()
            }
            .setNegativeButton(tr("رجوع", "Cancel"), null)
            .show()
    }

    // ------------------------------------------------------------------ pairing
    private fun scanQr() {
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(this, opts).startScan()
                .addOnSuccessListener { code ->
                    val m = Regex("(\\d{4})").find(code.rawValue ?: "")
                    if (m != null) handleCode(m.groupValues[1])
                    else toast(tr("الـ QR ده مش من التلفزيون", "That QR is not from the TV"))
                }
                .addOnFailureListener {
                    toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
                }
        } catch (_: Exception) {
            toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
        }
    }

    private fun handleCode(code: String) {
        if (code.length != 4 || !code.all { it.isDigit() }) return
        Hub.armCode(code)
        settingCode = true
        codeBox.setText(code)
        codeBox.setSelection(codeBox.text.length)
        settingCode = false
        hideKeyboard()
        selectTab(0)
        refresh()
    }

    // ------------------------------------------------------------------ Recovery center (5th tab): accounts backup + forgotten PIN
    private var refreshBackupCb: (() -> Unit)? = null
    private var bkFilter = 0            // 0 = all, 1 = automatic only, 2 = manual only
    private var bkNewestFirst = true    // sort by date

    // ------------------------------------------------------------------ Keys (page 5, 4th tab): API keys shared with the TV (SubDL, TMDB; more can be added as one more keyCard)
    private var subsPaint: (() -> Unit)? = null
    private val keyPaints = ArrayList<() -> Unit>()

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast(tr("معرفتش افتح الرابط", "Could not open the link")) }
    }

    /** SubDL: a bare key or pasted text/URL containing api_key=...; "" if it does not look like a key. */
    private fun cleanSdKey(raw: String): String {
        var k = raw.trim()
        Regex("api_key=([A-Za-z0-9_\\-]+)").find(k)?.let { k = it.groupValues[1] }
        k = k.trim().trim('"', '\'', '`')
        return if (k.length in 16..200 && k.none { it.isWhitespace() }) k else ""
    }

    /** TMDB v3 key: 32 hex characters (the long Read Access Token is not what the TV uses). */
    private fun cleanTmKey(raw: String): String =
        Regex("(?<![0-9A-Fa-f])[0-9A-Fa-f]{32}(?![0-9A-Fa-f])").find(raw)?.value ?: ""

    private fun maskKey(k: String): String = if (k.length <= 8) "••••" else k.take(3) + "••••••" + k.takeLast(3)

    private fun linkText(label: String, color: Int, onClick: () -> Unit): TextView {
        val t = Ui.text(this, label, 13f, color, 5)
        t.setPadding(dp(2), dp(8), dp(2), dp(8))
        Ui.pressable(t)
        t.setOnClickListener { onClick() }
        return t
    }

    /** One provider card: header with status, paste field, Paste / Save, small links. */
    private fun keyCard(
        id: String, title: String, sub: String, hint: String,
        signupUrl: String, keyUrl: String, badKey: String, clean: (String) -> String
    ): View {
        val card = settingsCard()

        // header: title + subtitle, status pill at the end
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(Ui.text(this, title, 18f, Ui.TEXT, 7))
        titles.addView(Ui.text(this, sub, 12f, Ui.MUTED, 4), LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(2) })
        head.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        val stPill = LinearLayout(this)
        stPill.orientation = LinearLayout.HORIZONTAL
        stPill.gravity = Gravity.CENTER_VERTICAL
        stPill.setPadding(dp(10), dp(5), dp(12), dp(5))
        val stDot = View(this)
        val stText = Ui.text(this, "", 12f, Ui.TEXT, 5)
        stPill.addView(stDot, LinearLayout.LayoutParams(dp(8), dp(8)).also { it.marginEnd = dp(6) })
        stPill.addView(stText)
        head.addView(stPill, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(8) })
        card.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val masked = Ui.text(this, "", 12f, Ui.MUTED, 4)
        masked.layoutDirection = View.LAYOUT_DIRECTION_LTR
        masked.gravity = Gravity.START
        card.addView(masked, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(8) })

        // paste field
        val keyBox = field(tr("الصق المفتاح هنا", "Paste the key here"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
        keyBox.setSingleLine(true)
        keyBox.layoutDirection = View.LAYOUT_DIRECTION_LTR
        keyBox.textDirection = View.TEXT_DIRECTION_LTR
        card.addView(keyBox, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(8) })

        fun saveKey(raw: String) {
            val k = clean(raw)
            if (k.isEmpty()) { toast(badKey); return }
            Hub.setApiKey(id, k, true)
            keyBox.setText("")
            hideKeyboard()
            subsPaint?.invoke()
            toast(if (Hub.isPaired()) tr("اتحفظ واتبعت للتلفزيون", "Saved and sent to the TV") else tr("اتحفظ. هيروح للتلفزيون لما تربطه", "Saved. It goes to the TV once it is paired"))
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val pasteBtn = Ui.pill(this, tr("لصق", "Paste"), Ui.SURF, Ui.TEXT, 0, Ui.BORDER) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val t = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: "" } catch (_: Exception) { "" }
            if (t.isBlank()) toast(tr("الحافظة فاضية", "The clipboard is empty")) else saveKey(t)   // a valid pasted key is saved and linked straight away
        }
        val saveBtn = Ui.pill(this, tr("حفظ وربط", "Save & link"), Ui.ACCENT_DEEP, Color.WHITE, 0) { saveKey(keyBox.text.toString()) }
        row.addView(pasteBtn, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.marginEnd = dp(5) })
        row.addView(saveBtn, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.marginStart = dp(5) })
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })

        // small links
        val links = LinearLayout(this)
        links.orientation = LinearLayout.HORIZONTAL
        links.gravity = Gravity.CENTER_VERTICAL
        links.addView(linkText(tr("عمل حساب", "Create account"), Ui.ACCENT) { openLink(signupUrl) })
        links.addView(Ui.text(this, "·", 13f, Ui.MUTED, 4), LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(10); it.marginEnd = dp(10) })
        links.addView(linkText(tr("صفحة المفتاح", "Key page"), Ui.ACCENT) { openLink(keyUrl) })
        links.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val clearLink = linkText(tr("مسح", "Remove"), Ui.RED) {
            AlertDialog.Builder(this)
                .setMessage(tr("تمسح المفتاح من الموبايل والتلفزيون؟", "Remove the key from the phone and the TV?"))
                .setPositiveButton(tr("مسح", "Remove")) { _, _ -> Hub.setApiKey(id, "", true); subsPaint?.invoke() }
                .setNegativeButton(tr("إلغاء", "Cancel"), null)
                .show()
        }
        links.addView(clearLink)
        card.addView(links, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(4) })

        val h = Ui.text(this, hint, 12f, Ui.MUTED, 4)
        h.setLineSpacing(dp(3).toFloat(), 1f)
        card.addView(h, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(2) })

        keyPaints.add {
            val k = Hub.apiKey(id)
            val col: Int
            if (k.isEmpty()) {
                col = Ui.MUTED
                stText.text = tr("فاضي", "Empty")
                masked.visibility = View.GONE
                clearLink.visibility = View.GONE
            } else {
                col = if (Hub.isPaired()) Ui.GREEN else Ui.ACCENT
                stText.text = if (Hub.isPaired()) tr("مربوط", "Linked") else tr("محفوظ", "Saved")
                masked.text = maskKey(k)
                masked.visibility = View.VISIBLE
                clearLink.visibility = View.VISIBLE
            }
            stDot.background = Ui.oval(col)
            stPill.background = Ui.rect(Color.argb(38, Color.red(col), Color.green(col), Color.blue(col)), 14)
        }
        return card
    }

    private fun buildSubsPage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("مفاتيح", "Keys"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("مفاتيح الخدمات اللي التلفزيون بيستخدمها. اللي تحطه هنا يوصل للتلفزيون لوحده.", "Keys for the services the TV uses. A key saved here reaches the TV by itself."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        p.addView(hint, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(6) })

        keyPaints.clear()
        p.addView(
            keyCard(
                "sdk", "SubDL", tr("ترجمة الأفلام والمسلسلات", "Movie & series subtitles"),
                tr("اعمل حساب مجاني، افتح بروفايلك، انسخ كود الـ API وارجع الصقه هنا.", "Create a free account, open your profile, copy the API code and paste it here."),
                "https://subdl.com", "https://subdl.com/panel/api",
                tr("ده مش شكل مفتاح صحيح. انسخ كود الـ API من حسابك في SubDL", "That does not look like a key. Copy the API code from your SubDL account"),
                { cleanSdKey(it) }
            ),
            LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(16) }
        )
        p.addView(
            keyCard(
                "tmk", "TMDB", tr("القصص والصور وربط الفيلم بالترجمة", "Plots, images and matching titles for subtitles"),
                tr("اعمل حساب مجاني، افتح إعدادات API وانسخ «API Key» (٣٢ حرف) مش الـ Read Access Token. لو سبته فاضي التطبيق بيستخدم مفتاحه العادي.", "Create a free account, open the API settings and copy the “API Key” (32 characters), not the Read Access Token. Leave it empty and the app uses its default key."),
                "https://www.themoviedb.org/signup", "https://www.themoviedb.org/settings/api",
                tr("ده مش شكل مفتاح TMDB. المطلوب «API Key» من ٣٢ حرف", "That is not a TMDB key. It should be the 32-character “API Key”"),
                { cleanTmKey(it) }
            ),
            LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) }
        )

        subsPaint = { keyPaints.forEach { it() } }
        subsPaint?.invoke()
        Hub.onKeys = { subsPaint?.invoke() }

        val foot = Ui.text(this, tr("المفاتيح بتتخزّن على موبايلك وتلفزيونك بس.", "Keys are stored only on your phone and TV."), 12f, Ui.MUTED, 4)
        p.addView(foot, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) })
        return scrollPage(p)
    }

    private fun buildRecoveryPage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("مركز الاسترجاع", "Recovery center"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("نسخ حسابات التلفزيون المحفوظة على الموبايل، وفك الرقم السري لو نسيته.", "The TV's accounts backups kept on this phone, and a way out if you forget a PIN."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        p.addView(hint, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(8) })

        val bkBox = LinearLayout(this)
        bkBox.orientation = LinearLayout.VERTICAL
        p.addView(bkBox, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(18) })
        fun refreshBackup() {
            bkBox.removeAllViews()
            val list = Hub.profilesBackups()
            bkBox.addView(
                Ui.text(this, tr("النسخ الاحتياطي والاسترجاع", "Backup & restore"), 16f, Ui.TEXT, 7),
                LinearLayout.LayoutParams(WRAP, WRAP).also { it.bottomMargin = dp(10) }
            )
            // automatic backup switch: the phone decides, the TV follows (and tells the phone if it is flipped there)
            val autoCard = LinearLayout(this)
            autoCard.orientation = LinearLayout.VERTICAL
            autoCard.background = Ui.glass(18)
            autoCard.setPadding(dp(16), dp(12), dp(16), dp(12))
            autoCard.addView(switchRow(tr("نسخ احتياطي تلقائي", "Automatic backup"), Hub.autoBackup()) { on ->
                Hub.setAutoBackup(on, true)
                toast(
                    if (!on) tr("النسخ التلقائي اتقفل", "Automatic backup is off")
                    else if (Hub.isPaired()) tr("اتفعّل. التلفزيون هيبعت نسخ لوحده", "On. The TV will send backups by itself")
                    else tr("اتفعّل. هيشتغل لما تربط التلفزيون", "On. It starts once the TV is paired")
                )
            })
            val autoHint = Ui.text(
                this,
                tr("التلفزيون بيبعت نسخة من حساباته للموبايل لوحده كل يوم تقريباً. بيتحفظ آخر ${Hub.MAX_AUTO} نسخ تلقائية (الجديدة بتشيل الأقدم)، والنسخ اللي بتعملها بإيدك بتتحفظ لوحدها (لحد ${Hub.MAX_MANUAL}).", "The TV sends its accounts to this phone by itself about once a day. The last ${Hub.MAX_AUTO} automatic backups are kept (a new one pushes the oldest out); backups you make yourself are kept separately (up to ${Hub.MAX_MANUAL})."),
                12f, Ui.MUTED, 4
            )
            autoHint.setLineSpacing(dp(3).toFloat(), 1f)
            autoCard.addView(autoHint, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(6) })
            bkBox.addView(autoCard, LinearLayout.LayoutParams(MATCH, WRAP).also { it.bottomMargin = dp(12) })
            val selId = Hub.selectedBackupId()
            if (list.isEmpty()) {
                val empty = LinearLayout(this)
                empty.orientation = LinearLayout.VERTICAL
                empty.background = Ui.glass(18)
                empty.setPadding(dp(16), dp(14), dp(16), dp(14))
                empty.addView(Ui.text(this, tr("مفيش نسخة على الموبايل لسه", "No backup on this phone yet"), 15f, Ui.TEXT, 7))
                val eh = Ui.text(this, tr("من التلفزيون: النسخ الاحتياطي والاسترجاع ← نسخ الحسابات للموبايل. هتظهر هنا لحظة ما توصل.", "On the TV: Backup & restore, then copy accounts to the phone. It shows up here as soon as it arrives."), 13f, Ui.MUTED, 4)
                eh.setLineSpacing(dp(3).toFloat(), 1f)
                empty.addView(eh, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(4) })
                bkBox.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))
                return
            }
            // filter (all / automatic / manual) + sort by date
            fun chip(label: String, on: Boolean, click: () -> Unit): TextView {
                val c = Ui.text(this, label, 13f, if (on) Ui.TEXT else Ui.MUTED, 7)
                c.setPadding(dp(11), dp(8), dp(11), dp(8))
                c.background = Ui.rect(if (on) Color.argb(90, 110, 168, 255) else Color.argb(30, 255, 255, 255), 18)
                Ui.pressable(c)
                c.setOnClickListener { click() }
                return c
            }
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            val lp = { LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginEnd = dp(6) } }
            bar.addView(chip(tr("الكل", "All"), bkFilter == 0) { bkFilter = 0; refreshBackup() }, lp())
            bar.addView(chip(tr("تلقائية", "Automatic"), bkFilter == 1) { bkFilter = 1; refreshBackup() }, lp())
            bar.addView(chip(tr("يدوية", "Manual"), bkFilter == 2) { bkFilter = 2; refreshBackup() }, lp())
            bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            bar.addView(chip(if (bkNewestFirst) tr("الأحدث ↓", "Newest ↓") else tr("الأقدم ↑", "Oldest ↑"), false) { bkNewestFirst = !bkNewestFirst; refreshBackup() })
            bkBox.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
            val nAuto = list.count { it.auto }
            val nMan = list.size - nAuto
            bkBox.addView(
                Ui.text(this, tr("تلقائية $nAuto/${Hub.MAX_AUTO} · يدوية $nMan/${Hub.MAX_MANUAL}", "Automatic $nAuto/${Hub.MAX_AUTO} · Manual $nMan/${Hub.MAX_MANUAL}"), 12f, Ui.MUTED, 4),
                LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(8); it.bottomMargin = dp(10) }
            )
            val shown = list.filter { bkFilter == 0 || (bkFilter == 1 && it.auto) || (bkFilter == 2 && !it.auto) }
                .let { l -> if (bkNewestFirst) l.sortedByDescending { it.t } else l.sortedBy { it.t } }
            if (shown.isEmpty()) {
                bkBox.addView(Ui.text(this, tr("مفيش نسخ بالفلتر ده", "No backups match this filter"), 13f, Ui.MUTED, 4))
            }
            for ((idx, info) in shown.withIndex()) {
                val whenTxt = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(info.t))
                val card = LinearLayout(this)
                card.orientation = LinearLayout.VERTICAL
                card.background = Ui.glass(18)
                card.setPadding(dp(16), dp(14), dp(16), dp(12))
                val head = LinearLayout(this)
                head.orientation = LinearLayout.HORIZONTAL
                head.gravity = Gravity.CENTER_VERTICAL
                head.addView(Ui.text(this, tr("${info.n} بروفايل", "${info.n} profiles"), 15f, Ui.TEXT, 7))
                val tag = Ui.text(this, if (info.auto) tr("تلقائية", "Automatic") else tr("يدوية", "Manual"), 11f, if (info.auto) Ui.ACCENT else Color.parseColor("#FFC857"), 7)
                tag.setPadding(dp(9), dp(3), dp(9), dp(3))
                tag.background = Ui.rect(if (info.auto) Color.argb(60, 110, 168, 255) else Color.argb(60, 255, 200, 87), 10)
                head.addView(tag, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(8) })
                card.addView(head)
                card.addView(
                    Ui.text(this, whenTxt, 12f, Ui.MUTED, 4),
                    LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(2) }
                )
                if (info.id == selId) {
                    card.addView(
                        Ui.text(this, tr("دي اللي هتتحمّل لو عملت استرجاع من التلفزيون", "This is the one a TV restore pulls"), 11f, Ui.MUTED, 4),
                        LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(2) }
                    )
                }
                val del = Ui.labelBtn(this, tr("حذف النسخة", "Delete backup"))
                del.setTextColor(Ui.RED)
                del.setPadding(dp(16), dp(11), dp(16), dp(11))
                del.setOnClickListener {
                    AlertDialog.Builder(this)
                        .setMessage(tr("تحذف النسخة دي من الموبايل؟", "Delete this backup from this phone?"))
                        .setPositiveButton(tr("حذف", "Delete")) { _, _ ->
                            Hub.deleteProfilesBackup(info.id)
                            refreshBackup()
                        }
                        .setNegativeButton(tr("إلغاء", "Cancel"), null)
                        .show()
                }
                val btns = LinearLayout(this)
                btns.orientation = LinearLayout.HORIZONTAL
                if (info.id != selId) {
                    val use = Ui.labelBtn(this, tr("اعتمدها للاسترجاع", "Use for restore"))
                    use.setPadding(dp(16), dp(11), dp(16), dp(11))
                    use.setOnClickListener {
                        Hub.selectBackup(info.id)
                        refreshBackup()
                    }
                    btns.addView(use)
                }
                btns.addView(del, LinearLayout.LayoutParams(WRAP, WRAP).also { if (info.id != selId) it.marginStart = dp(8) })
                card.addView(btns, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(10) })
                bkBox.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).also { if (idx > 0) it.topMargin = dp(10) })
            }
        }

        refreshBackup()
        refreshBackupCb = { refreshBackup() }
        Hub.onAbk = { refreshBackup() }

        // ---- forgot a profile PIN on the TV? The paired phone asks the TV to open its "remove PIN" list ----
        val pinCard = LinearLayout(this)
        pinCard.orientation = LinearLayout.VERTICAL
        pinCard.background = Ui.glass(18)
        pinCard.setPadding(dp(16), dp(14), dp(16), dp(14))
        pinCard.addView(Ui.text(this, tr("نسيت الرقم السري لبروفايل؟", "Forgot a profile PIN?"), 16f, Ui.TEXT, 7))
        val pinHint = Ui.text(
            this,
            tr("هتفتح على التلفزيون قائمة البروفايلات اللي عليها رقم سري، وتختار منها اللي عايز تشيل رقمه بالريموت.", "This opens a list on the TV of the profiles that have a PIN; pick the one to clear with the TV remote."),
            13f, Ui.MUTED, 4
        )
        pinHint.setLineSpacing(dp(3).toFloat(), 1f)
        pinCard.addView(pinHint, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(4) })
        val pinBtn = Ui.labelBtn(this, tr("فك الرقم السري من التلفزيون", "Clear a PIN on the TV"))
        pinBtn.setPadding(dp(16), dp(11), dp(16), dp(11))
        pinBtn.setOnClickListener {
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else {
                Hub.send(JSONObject().put("type", "pinreset"))
                toast(tr("بصّ على التلفزيون واختار البروفايل", "Look at the TV and pick the profile"))
            }
        }
        pinCard.addView(pinBtn, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(10) })
        p.addView(pinCard, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(26) })

        return scrollPage(p)
    }

    // ------------------------------------------------------------------ IPTV source page
    private fun buildSourcePage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("مصادر IPTV", "IPTV sources"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("احفظ أكتر من مصدر على الموبايل، وبعدين اختار أي واحد وابعته للتلفزيون. هتراجعه على التلفزيون وتضغط موافق.", "Save as many sources as you like on the phone, then pick any one and send it to the TV. You confirm on the TV."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        val hl = LinearLayout.LayoutParams(WRAP, WRAP)
        hl.topMargin = dp(8)
        p.addView(hint, hl)

        // ---- saved list ----
        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        p.addView(listBox, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(16) })

        // ---- add / edit form ----
        val formTitle = Ui.text(this, tr("إضافة مصدر", "Add a source"), 16f, Ui.TEXT, 7)
        p.addView(formTitle, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(26) })

        var xtream = true
        var editId: String? = null
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.glass(20)
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        val sx = Ui.text(this, "Xtream Codes", 13f, Ui.TEXT, 7)
        val sm = Ui.text(this, "M3U", 13f, Ui.TEXT, 7)
        for (t in listOf(sx, sm)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        seg.addView(sx)
        seg.addView(sm)
        p.addView(seg, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(12) })

        // import the server details from a photo / screenshot (on-device text recognition)
        val imgBtn = Ui.labelBtn(this, tr("استيراد البيانات من صورة", "Import details from an image"))
        imgBtn.setPadding(dp(16), dp(11), dp(16), dp(11))
        imgBtn.setOnClickListener {
            try {
                val pick = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                @Suppress("DEPRECATION")
                startActivityForResult(Intent.createChooser(pick, tr("اختار صورة فيها بيانات السيرفر", "Pick an image with the server details")), 78)
            } catch (_: Exception) {
                toast(tr("معرفتش افتح المعرض", "Could not open the gallery"))
            }
        }
        p.addView(imgBtn, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(12) })

        val name = field(tr("اسم القائمة (اختياري)", "Playlist name (optional)"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        name.filters = arrayOf(InputFilter.LengthFilter(60))
        val server = field("http://host:port", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field(tr("اسم المستخدم", "Username"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
        val pass = field(tr("كلمة المرور", "Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        val m3u = field(tr("رابط M3U كامل (http / https)", "Full M3U link (http / https)"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        for (e in listOf(name, server, user, pass, m3u)) {
            e.textDirection = View.TEXT_DIRECTION_LTR
            p.addView(e, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(12) })
        }
        fun render() {
            sx.background = if (xtream) Ui.accentRect(17) else null
            sm.background = if (xtream) null else Ui.accentRect(17)
            sx.setTextColor(if (xtream) Color.WHITE else Ui.MUTED)
            sm.setTextColor(if (xtream) Ui.MUTED else Color.WHITE)
            val xv = if (xtream) View.VISIBLE else View.GONE
            server.visibility = xv
            user.visibility = xv
            pass.visibility = xv
            m3u.visibility = if (xtream) View.GONE else View.VISIBLE
        }
        sx.setOnClickListener { xtream = true; render() }
        sm.setOnClickListener { xtream = false; render() }
        render()

        imageImport = { text ->
            val r = ServerOcr.parse(text)
            if (r == null) {
                toast(tr("مالقيتش بيانات سيرفر في الصورة", "No server details found in the image"))
            } else {
                if (r.xtream) {
                    xtream = true
                    if (r.server.isNotEmpty()) server.setText(r.server)
                    if (r.user.isNotEmpty()) user.setText(r.user)
                    if (r.pass.isNotEmpty()) pass.setText(r.pass)
                } else {
                    xtream = false
                    m3u.setText(r.m3u)
                }
                render()
                toast(if (r.complete) tr("تم. راجع الخانات خصوصاً كلمة المرور", "Done. Check the fields, especially the password")
                      else tr("لقيت جزء من البيانات، كمّل الباقي بإيدك", "Found part of the details; fill in the rest"))
            }
        }

        var refreshList: () -> Unit = {}
        val cancel = Ui.text(this, tr("إلغاء التعديل", "Cancel editing"), 13f, Ui.ACCENT, 7)
        cancel.setPadding(dp(4), dp(10), dp(4), dp(10))
        cancel.visibility = View.GONE

        fun resetForm() {
            editId = null
            for (e in listOf(name, server, user, pass, m3u)) e.text.clear()
            formTitle.text = tr("إضافة مصدر", "Add a source")
            cancel.visibility = View.GONE
        }
        cancel.setOnClickListener { resetForm(); hideKeyboard() }

        /** Validates the form and returns the source, or null (after showing why). */
        fun readForm(): Hub.Src? {
            val nm = name.text.toString().trim()
            val id = editId ?: Hub.newSourceId()
            if (xtream) {
                val srv = server.text.toString().trim()
                val usr = user.text.toString().trim()
                val pwd = pass.text.toString()
                if (srv.isEmpty() || usr.isEmpty() || pwd.isEmpty()) {
                    toast(tr("اكتب السيرفر واسم المستخدم وكلمة المرور", "Enter server, username and password"))
                    return null
                }
                return Hub.Src(id, nm, true, srv, usr, pwd, "")
            }
            val url = m3u.text.toString().trim()
            if (!Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(url) || url.length > 2000) {
                toast(tr("اكتب رابط M3U كامل", "Enter a complete M3U link"))
                return null
            }
            return Hub.Src(id, nm, false, "", "", "", url)
        }

        fun sendSource(s: Hub.Src) {
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else {
                Hub.send(Hub.sourceEvent(s))
                toast(tr("اتبعت للتلفزيون — افتح «إضافة مصدر» عليه", "Sent — open “Add source” on the TV"))
            }
        }

        /** Shares a source's details as plain text through the Android share sheet (WhatsApp, Messenger, any app). */
        fun shareSource(s: Hub.Src) {
            val lines = mutableListOf<String>()
            if (s.name.isNotBlank()) lines.add(s.name)
            if (s.xtream) {
                lines.add(tr("السيرفر", "Server") + ": " + s.server)
                lines.add(tr("اسم المستخدم", "Username") + ": " + s.user)
                lines.add(tr("كلمة المرور", "Password") + ": " + s.pass)
            } else {
                lines.add(s.url)
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, s.title())
                putExtra(Intent.EXTRA_TEXT, lines.joinToString("\n"))
            }
            try {
                startActivity(Intent.createChooser(intent, tr("مشاركة المصدر", "Share source")))
            } catch (_: Exception) {
                toast(tr("معرفتش افتح قائمة المشاركة", "Could not open the share sheet"))
            }
        }

        val saveBtn = Ui.pill(this, tr("حفظ", "Save"), Ui.SURF, Ui.TEXT, 0, Ui.BORDER) {
            val s = readForm()
            if (s != null) {
                Hub.saveSource(s)
                resetForm()
                hideKeyboard()
                refreshList()
                toast(tr("تم الحفظ", "Saved"))
            }
        }
        val saveSendBtn = Ui.pill(this, tr("حفظ وإرسال للتلفزيون", "Save & send to TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) {
            val s = readForm()
            if (s != null) {
                Hub.saveSource(s)
                resetForm()
                hideKeyboard()
                refreshList()
                sendSource(s)
            }
        }
        p.addView(saveSendBtn, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(20) })
        p.addView(saveBtn, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })
        p.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(6) })

        fun startEdit(s: Hub.Src) {
            editId = s.id
            xtream = s.xtream
            name.setText(s.name)
            server.setText(s.server)
            user.setText(s.user)
            pass.setText(s.pass)
            m3u.setText(s.url)
            render()
            formTitle.text = tr("تعديل المصدر", "Edit source")
            cancel.visibility = View.VISIBLE
            name.requestFocus()
        }

        refreshList = {
            refreshBackupCb?.invoke()
            listBox.removeAllViews()
            val all = Hub.sources()
            if (all.isEmpty()) {
                val empty = Ui.text(this, tr("مفيش مصادر محفوظة لسه. أضف أول مصدر من تحت.", "No saved sources yet. Add your first one below."), 13f, Ui.MUTED, 4)
                listBox.addView(empty, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(4) })
            } else {
                listBox.addView(Ui.text(this, tr("المصادر المحفوظة", "Saved sources"), 16f, Ui.TEXT, 7))
                for (s in all) {
                    val card = LinearLayout(this)
                    card.orientation = LinearLayout.VERTICAL
                    card.background = Ui.glass(18)
                    card.setPadding(dp(16), dp(14), dp(16), dp(12))
                    val t1 = Ui.text(this, s.title(), 15f, Ui.TEXT, 7)
                    t1.maxLines = 1
                    t1.ellipsize = android.text.TextUtils.TruncateAt.END
                    t1.textDirection = View.TEXT_DIRECTION_LTR
                    val t2 = Ui.text(this, s.subtitle(), 12f, Ui.MUTED, 4)
                    t2.maxLines = 1
                    t2.ellipsize = android.text.TextUtils.TruncateAt.END
                    t2.textDirection = View.TEXT_DIRECTION_LTR
                    card.addView(t1)
                    card.addView(t2, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(2) })

                    // one row: [Send (fills the rest)] [Edit] [Delete] ... [share icon at the opposite corner]
                    val row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    val send = LinearLayout(this)
                    send.orientation = LinearLayout.HORIZONTAL
                    send.gravity = Gravity.CENTER
                    send.setPadding(dp(10), 0, dp(10), 0)
                    send.background = Ui.rect(Ui.ACCENT_DEEP, 22)
                    send.addView(Ui.icon(this, R.drawable.ic_send, 18, Color.WHITE), LinearLayout.LayoutParams(dp(18), dp(18)))
                    val sendLbl = Ui.text(this, tr("إرسال", "Send"), 15f, Color.WHITE, 7)
                    sendLbl.maxLines = 1
                    send.addView(sendLbl, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(8) })
                    Ui.pressable(send)
                    send.setOnClickListener { sendSource(s) }
                    row.addView(send, LinearLayout.LayoutParams(0, dp(44), 1f))
                    val edit = Ui.labelBtn(this, tr("تعديل", "Edit"))
                    edit.gravity = Gravity.CENTER
                    edit.setPadding(dp(12), 0, dp(12), 0)
                    edit.setOnClickListener { startEdit(s) }
                    row.addView(edit, LinearLayout.LayoutParams(WRAP, dp(44)).also { it.marginStart = dp(6) })
                    val del = Ui.labelBtn(this, tr("حذف", "Delete"))
                    del.gravity = Gravity.CENTER
                    del.setTextColor(Ui.RED)
                    del.setPadding(dp(12), 0, dp(12), 0)
                    del.setOnClickListener {
                        AlertDialog.Builder(this)
                            .setMessage(tr("تحذف «${s.title()}» من الموبايل؟", "Delete “${s.title()}” from this phone?"))
                            .setPositiveButton(tr("حذف", "Delete")) { _, _ ->
                                if (editId == s.id) resetForm()
                                Hub.deleteSource(s.id)
                                refreshList()
                            }
                            .setNegativeButton(tr("إلغاء", "Cancel"), null)
                            .show()
                    }
                    row.addView(del, LinearLayout.LayoutParams(WRAP, dp(44)).also { it.marginStart = dp(6) })
                    val share = FrameLayout(this)
                    share.background = Ui.rect(Color.argb(40, 255, 255, 255), 22)
                    share.contentDescription = tr("مشاركة", "Share")
                    share.addView(Ui.icon(this, R.drawable.ic_share, 20, Ui.TEXT), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                    Ui.pressable(share)
                    share.setOnClickListener { shareSource(s) }
                    row.addView(share, LinearLayout.LayoutParams(dp(44), dp(44)).also { it.marginStart = dp(6) })
                    card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(12) })
                    listBox.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })
                }
            }
        }
        refreshList()
        // the TV just copied sources / accounts to this phone: redraw
        Hub.onLibrary = {
            refreshList()
            toast(tr("وصلت نسخة من التلفزيون", "A backup arrived from the TV"))
        }

        return scrollPage(p)
    }

    // ------------------------------------------------------------------ keyboard page
    private fun buildKeyboardPage(): View {
        val p = vbox()
        // step 1: open the search box on the TV
        val openSearch = Ui.pill(this, tr("فتح البحث على التلفزيون", "Open search on the TV"), Ui.SURF, Ui.TEXT, R.drawable.ic_search_s) { key("search") }
        p.addView(openSearch, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(12) })

        val hint = Ui.text(this, tr("اكتب هنا وهيظهر على التلفزيون.", "Type here and it shows on the TV."), 15f, Ui.TEXT, 4)
        p.addView(hint, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(16) })

        // step 2: the text box, with mic and clear next to it
        val box = field(tr("اكتب هنا…", "Type here…"), InputType.TYPE_CLASS_TEXT)
        typeBox = box
        box.setSingleLine(false)
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        box.minLines = 6
        box.maxLines = 9
        box.gravity = Gravity.TOP

        var pending: Runnable? = null
        fun sendNow() {
            val v = box.text.toString()
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else if (v.isBlank() && !Hub.liveType()) {
                toast(tr("اكتب حاجة الأول", "Type something first"))
            } else {
                // live mode: "replace" makes the TV box equal to the box here (TV 0.3.511+); normal mode inserts at the TV caret
                val ev = JSONObject().put("type", "text").put("text", v)
                if (Hub.liveType()) ev.put("replace", true)
                Hub.send(ev)
                if (!Hub.liveType()) {
                    box.text.clear()
                    toast(tr("اتبعت للتلفزيون", "Sent to the TV"))
                }
            }
        }
        box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!Hub.liveType() || !Hub.isPaired()) return
                pending?.let { box.removeCallbacks(it) }
                val r = Runnable { sendNow() }
                pending = r
                box.postDelayed(r, 300)
            }
        })
        // keyboard Search / Enter key: live mode presses OK on the TV, otherwise sends the text then presses OK
        box.setOnEditorActionListener { _, _, _ ->
            pending?.let { box.removeCallbacks(it) }
            if (Hub.liveType()) {
                sendNow()
                key("enter")
            } else if (box.text.isNotBlank()) {
                sendNow()
                key("enter")
            }
            true
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.TOP
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        val mic = Ui.roundBtn(this, R.drawable.ic_mic, 46, 22)
        mic.setOnClickListener { startVoice() }
        Ui.pressable(mic)
        val clr = Ui.roundBtn(this, R.drawable.ic_backspace, 46, 22)
        clr.setOnClickListener {
            pending?.let { box.removeCallbacks(it) }
            box.text.clear()
            key("clear_text")
        }
        Ui.pressable(clr)
        val snd = Ui.roundBtn(this, R.drawable.ic_send, 46, 22)   // backup: send the text by hand
        snd.contentDescription = tr("ابعت النص", "Send text")
        snd.setOnClickListener {
            pending?.let { box.removeCallbacks(it) }
            sendNow()
        }
        Ui.pressable(snd)
        side.addView(mic)
        side.addView(clr, LinearLayout.LayoutParams(dp(46), dp(46)).also { it.topMargin = dp(10) })
        side.addView(snd, LinearLayout.LayoutParams(dp(46), dp(46)).also { it.topMargin = dp(10) })
        row.addView(side, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(10) })
        p.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })

        // step 3: OK (primary) - confirms on the TV. The text itself is already sent while typing; sending by hand is the small button beside the box
        val ok = Ui.pill(this, tr("موافق", "OK"), Ui.ACCENT_DEEP, Color.WHITE, 0) {
            pending?.let { box.removeCallbacks(it) }
            if (Hub.isPaired() && (Hub.liveType() || box.text.isNotBlank())) sendNow()
            key("enter")
        }
        p.addView(ok, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(16) })

        val live = switchRow(tr("إرسال لحظي أثناء الكتابة", "Send while typing"), Hub.liveType()) { Hub.setLiveType(it) }
        p.addView(live, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(22) })
        val liveHint = Ui.text(this, tr("النص يظهر على التلفزيون وإنت بتكتب من غير إرسال. فعّله بس لو تلفزيونك نسخة 0.3.511 أو أحدث، وإلا النص هيتكرر.", "Text shows on the TV as you type, no Send needed. Turn it on only if your TV app is version 0.3.511 or newer, otherwise the text will be duplicated."), 12f, Ui.MUTED, 4)
        p.addView(liveHint, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(4) })
        return scrollPage(p)
    }

    private fun startVoice() {
        val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, if (Hub.ar) "ar-EG" else java.util.Locale.getDefault().toLanguageTag())
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, 77)
        } catch (_: Exception) {
            toast(tr("الإملاء الصوتي مش متاح على الموبايل ده", "Voice input is not available on this phone"))
        }
    }

    /** set by the sources page: receives the text found in the picked image */
    private var imageImport: ((String) -> Unit)? = null

    private fun readServerImage(uri: Uri) {
        try {
            val img = InputImage.fromFilePath(this, uri)
            toast(tr("بقرأ الصورة…", "Reading the image…"))
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
                .addOnSuccessListener { r -> imageImport?.invoke(r.text) }
                .addOnFailureListener { toast(tr("معرفتش أقرأ الصورة", "Could not read the image")) }
        } catch (_: Exception) {
            toast(tr("معرفتش أفتح الصورة", "Could not open the image"))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK) {
            data?.data?.let { readServerImage(it) }
        }
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) typeBox?.let { it.setText(t); it.setSelection(it.text.length) }
        }
    }

    // ------------------------------------------------------------------ state
    private fun refresh() {
        subsPaint?.invoke()
        val paired = Hub.isPaired()
        val seen = System.currentTimeMillis() - Hub.lastSeen < 7000
        if (forcePair && seen) forcePair = false   // the TV is back (by itself or after the new code): return to the remote
        val showPair = !paired || forcePair
        pairPanel.visibility = if (showPair) View.VISIBLE else View.GONE
        remotePanel.visibility = if (showPair) View.GONE else View.VISIBLE

        remotePanel.alpha = if (paired && !seen) 0.5f else 1f   // TV offline: the keys look inactive
        val err = Hub.error
        val dot: Int
        val label: String
        if (!Hub.running && err != null) {
            dot = Ui.RED
            label = tr("السيرفر واقف", "Server stopped")
        } else if (!paired) {
            dot = Ui.MUTED
            label = tr("مش مربوط", "Not paired")
        } else if (seen) {
            dot = Ui.GREEN
            label = tr("التلفزيون متصل", "TV connected")
        } else {
            dot = Ui.AMBER
            label = tr("مربوط • التلفزيون مش متصل", "Paired • TV offline")
        }
        chipDot.background = Ui.oval(dot)
        chipText.text = if (!Hub.running && err != null) label else if (paired && seen && !forcePair) tr("متصل", "Connected") else tr("غير متصل", "Offline")
        setPairVal.text = label
        setPairVal.setTextColor(dot)
        setIpVal.text = "${Hub.localIp()}:${Hub.PORT}"
        setUnpair.visibility = if (paired) View.VISIBLE else View.GONE

        if (showPair) {
            val c = Hub.pendingCode
            if (Hub.locked()) {
                pairStatus.setTextColor(Ui.RED)
                pairStatus.text = tr("محاولات كتير غلط. استنى دقيقة وجرّب تاني.", "Too many wrong codes. Wait a minute and try again.")
            } else if (Hub.mismatch && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.RED)
                pairStatus.text = tr("الكود اللي على التلفزيون مختلف. اتأكد من الأرقام.", "The code on the TV is different. Check the digits.")
            } else if (c != null && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.AMBER)
                pairStatus.text = tr("بانتظار التلفزيون… سيب شاشة «ريموت تيتانيوم» مفتوحة عليه.", "Waiting for the TV… keep the “Titanium Remote” screen open on it.")
            } else if (c != null) {
                pairStatus.setTextColor(Ui.RED)
                pairStatus.text = tr("الكود انتهت صلاحيته. اكتبه تاني أو امسح الـ QR.", "The code expired. Type it again or scan the QR.")
            } else {
                pairStatus.setTextColor(Ui.MUTED)
                pairStatus.text = if (paired) tr("لو التلفزيون رجع يتصل لوحده هترجع للريموت. اضغط الحالة فوق للرجوع.", "If the TV reconnects by itself you return to the remote. Tap the status above to go back.") else ""
            }
            val ip = Hub.localIp()
            pairIp.text = if (ip.isEmpty()) "" else tr("عنوان الموبايل: $ip", "Phone address: $ip")
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val v = currentFocus ?: root
            im.hideSoftInputFromWindow(v.windowToken, 0)
        } catch (_: Exception) {
        }
    }
}

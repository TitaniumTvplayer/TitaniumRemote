# Titanium Remote — patch notes

Drop these files into the existing project at the same paths (they replace the originals one-for-one):

- `app/src/main/java/com/titanium/remote/Hub.kt`
- `app/src/main/java/com/titanium/remote/MainActivity.kt`
- `app/src/main/java/com/titanium/remote/RemoteServer.kt` (unchanged logic, included for completeness — no edits were needed here)
- `app/src/main/res/drawable/ic_share.xml` (new icon)

## What changed

1. **Multiple accounts backups kept on the phone** (Hub.kt)
   - Previously the phone kept only the single most-recent "accounts backup" from the TV, overwriting it every time.
   - Now up to the last 10 backups are kept, each as its own file (`tv_profiles_backup_<id>.json`) with an index (`pb_list`) of id/profile-count/timestamp in prefs.
   - An existing single old-style backup on a phone that already has the app is folded into the new list automatically the first time it's read (`migrateLegacyBackup`), so nothing is lost on update.
   - `Hub.profilesBackupJson()` (no args) keeps returning the *newest* backup — this is what the TV's "Accounts restore from phone" button still pulls over HTTP, so no TV-side change was needed for this part.
   - New API: `Hub.profilesBackups()` (list, newest first), `Hub.profilesBackupJson(id)`, `Hub.deleteProfilesBackup(id)`.

2. **Backup list UI** (MainActivity.kt, IPTV sources page)
   - The single "Accounts backup from the TV" card is now a list of cards, one per kept backup, each showing its date and profile count, with its own Delete button.
   - The newest one is labeled and marked as "the one a TV restore pulls".

3. **Share a saved source** (MainActivity.kt + ic_share.xml)
   - Each saved source card now has a "Share" button next to "Send to TV".
   - It opens the normal Android share sheet (`ACTION_SEND`, text/plain) with the source's name and either its Xtream server/username/password or its M3U link — so it can go to WhatsApp, Messenger, any messaging app, etc.

## Not yet done — TV side (.wgt) for item 1

The **automatic phone backup toggle** lives entirely in the TV app, not here:
- A new "Automatic phone backup" switch was added to the TV's Settings → Backup & restore screen.
- When it's on and the phone is connected, the TV silently re-sends both the accounts and sources backups to the phone (quiet, no toast), throttled to at most once per hour per connection.
- That's already built into `TitaniumTV_0_3_549.wgt` (shared separately) — nothing more to do on the TV side for this feature.

## Suggested things to check on your end
- Confirm 10 kept backups is a sensible cap (easy to change — `Hub.MAX_BACKUPS`).
- Confirm the auto-backup interval (currently 1 hour, in `app.js`'s `abkMaybe()`) suits how often you reconnect.
- The Share text includes the Xtream password in plain text — intentional per your request, but worth knowing since the receiving app (WhatsApp etc.) will store that text too.


## v2.9.16 — "Forgot PIN" button
- IPTV sources page: new card "نسيت الرقم السري لبروفايل؟ / Forgot a profile PIN?" with a button that sends a `pinreset` event to the paired TV.
- The TV (`TitaniumTV_0_3_552.wgt`) then opens a list of the profiles that have a PIN; the user picks one with the TV remote and its PIN is cleared.
- Only `MainActivity.kt` changed (Hub.kt / RemoteServer.kt need nothing: `Hub.send()` already relays any event).
- Not compiled here (no Android toolchain in this workspace) — please build once and check the card renders.


## v2.9.17 — Preferences title, widget logo/intro, saved-sources cards
- **Preferences page**: its heading now reads "التفضيلات / Preferences" (it still said "الإعدادات / Settings"), matching the tab.
- **Header logo**: new `WidgetLogo` (WidgetBrand.kt) = the TV widget's logo redrawn 1:1: same 3D bars + play, same wordmark images (tw_l / tw_m / tw_r.png), same 10.5 s loop (play glides over the word, sparkles, kashida stretch).
- **Intro**: new `WidgetIntro` = the widget's intro timeline (bars + play start together and slide apart over 1.45 s, wordmark fades up at 0.85 s, tagline "بلايـر كل العيـله" at 1.7 s), black background, same intro sound. Total 3.4 s, tap to skip.
- **Saved sources cards**: rebuilt with fixed 44 dp heights (the send button no longer stretches). Row = Send (fills) · Edit · Delete · **Share as a round icon-only button at the opposite corner**.
- New files: `WidgetBrand.kt`, `res/drawable-nodpi/tw_l.png, tw_m.png, tw_r.png, tw_word.png`. The old `TitaniumLogo` / `TitaniumIntro` classes are left in the project, now unused (delete them whenever you like).
- Not compiled here (no Android toolchain) — please build once and check the header logo, intro and a source card.


## v2.9.18 — "Forgot PIN" moved down, no tagline in the intro, import server details from an image
- **Forgot PIN card** now sits at the very end of the IPTV sources page (after the add/edit form).
- **Intro**: the "بلايـر كل العيـله" line is removed (phone only; the TV intro keeps it). Intro is 2.9 s.
- **Import from image** (sources form, under the Xtream/M3U switch): "استيراد البيانات من صورة" opens the gallery, reads the text on the phone (ML Kit text recognition, Latin) and fills the fields: a full get.php link (username= / password=), or labelled lines (Server/Host/URL, Username/User, Password/Pass; value on the same line or the next), or a lone M3U link. The person checks the fields before saving. New file `ServerOcr.kt`.
- **One line to add to `app/build.gradle(.kts)` dependencies** (not part of this patch):
  `implementation("com.google.android.gms:play-services-mlkit-text-recognition:19.0.1")`
  (same Play-services family as the QR scanner already used; the model downloads on first use).
- Not compiled here (no Android toolchain) — please build once. OCR can confuse O/0 and l/1, so check the password.


## v2.9.19 — intro exit (logo glides up, remote rises) + saved-source cards
- **Intro exit**: after the logo settles (2.1 s) it glides up and shrinks into the header while the nav + remote slide in from the bottom (0.75 s, ease-out) and the black cover fades; the real header logo fades in as the intro logo arrives. Tap still skips straight to the screen. (MainActivity.showSplash + WidgetIntro.exit)
- **Saved-source cards**: the Send button is now on its own full-width row (its label was being clipped to "ابعت"); below it Edit · Delete, and the share icon at the opposite corner.


## v2.9.20 — saved-source cards back to one row
- Send / Edit / Delete / Share are on one row again (as in v2.9.18); the Send label is the short "إرسال / Send" (+ icon) so it fits without clipping, with tighter button padding.


## v2.9.21 — 5th tab: Recovery center (الاسترجاع)
- New tab after Preferences (leftmost in Arabic): **مركز الاسترجاع / Recovery center**. It holds the TV accounts backups (latest + older, delete) with an explanatory card when there is none yet, and the **Forgot a profile PIN** card. Both moved out of the IPTV sources page, which is now only sources.
- Tab bar fits 5 tabs (slightly narrower pills, 11 sp labels). New icon `ic_recovery.xml`.
- A backup arriving from the TV refreshes the Recovery tab live (`refreshBackupCb`), the sources list refreshes as before.
- Tab name is easy to change (`tr("الاسترجاع","Recovery")` in buildNav, `tr("مركز الاسترجاع", ...)` in buildRecoveryPage).


## v2.9.22 — automatic backup switch (synced with the TV) + up to 5 backups
- **Recovery tab → "نسخ احتياطي تلقائي / Automatic backup" switch.** The phone is the source of truth: every TV poll (`/next`) carries `abk` + `abkv` (a version bumped only when the phone flips it); the TV applies it when the version changes. If the switch is flipped on the TV itself, the TV tells the phone (`POST /library/abk`) and the switch here redraws. Needs the TV widget **0.3.553** (included, `TitaniumTV_0_3_553.wgt`): the TV already had an "Automatic phone backup" option (hourly while connected); it is now linked.
- **Up to 5 backups** (was 10; the list already existed). The TV marks its automatic backups (`auto:1`); on the phone one automatic backup per ~20 h replaces the previous automatic one, so the 5 slots cover days instead of 5 hours of the hourly auto-backup. Manual backups always add a new one. Oldest is trimmed past 5.
- **Pick which backup a TV restore pulls**: each card has "اعتمدها للاسترجاع / Use for restore"; the picked one is outlined and labelled (default: newest). Cards show "تلقائية" for automatic ones and the list shows "n من 5".
- Files: Hub.kt, RemoteServer.kt, MainActivity.kt (phone); widget js/app.js + config.xml version 0.3.553 (TV).
- Not compiled/run here.


## v2.9.23 — separate quotas for automatic / manual backups, one list with filter + sort
- **Automatic backups**: up to 5; when they are full the new one pushes the OLDEST automatic one out and takes its place. Within a day of the previous automatic backup the newest automatic one is just refreshed (so 5 slots cover about 5 days, not 5 hours of the TV's hourly auto-send). `AUTO_GAP` in Hub.kt.
- **Manual backups** (the ones the person makes) are stored separately: up to 5, never pushed out by automatic ones. `MAX_AUTO` / `MAX_MANUAL` in Hub.kt.
- **One list** in the Recovery tab; every card has a tag next to it: "تلقائية / Automatic" (blue) or "يدوية / Manual" (amber).
- **Filter**: All · Automatic · Manual. **Sort by date**: newest ↓ / oldest ↑ (tap to flip). Counter "تلقائية 3/5 · يدوية 2/5". Choices are kept while the app is open.
- TV widget unchanged (0.3.553 from the previous step still applies). Not compiled/run here.


## v2.9.24 — smaller pill labels (no clipping) + the ±10 s keys really jump 10 s
- **Pill keys** (Sort & Filter, Settings, Users, Reorder categories in the Arcs layout) now use a new `FitPill` (FitPill.kt): 13 sp label (was larger), vertically centred so nothing is cut at the bottom, and it shrinks by itself down to 9 sp when a label is long. The classic layout is unchanged.
- **±10 s keys**: the phone sent the same `ff` / `rw` keys as the TV's own FF / REW buttons, which the TV player maps to 30 s. The two round keys now send `ff10` / `rw10`; **TV widget 0.3.554** (`TitaniumTV_0_3_554.wgt`) seeks exactly 10 s for them. The real remote's FF / REW stay 30 s. Install the widget together with this patch (with the old widget the two keys do nothing).
- Not compiled/run here.

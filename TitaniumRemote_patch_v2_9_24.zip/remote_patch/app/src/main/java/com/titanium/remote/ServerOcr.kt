package com.titanium.remote

/**
 * Reads server details out of the text that on-device OCR found in a photo / screenshot.
 * Looks for (in this order): a full link that carries username= and password= (Xtream "get.php" link), then labelled lines
 * (Server / Host / URL, Username / User, Password / Pass — the value is on the same line or the next one), then a lone
 * M3U link. Whatever is found is returned; the caller fills the form and the person checks it.
 */
object ServerOcr {
    class Result(val xtream: Boolean, val server: String, val user: String, val pass: String, val m3u: String) {
        val complete: Boolean get() = if (xtream) server.isNotEmpty() && user.isNotEmpty() && pass.isNotEmpty() else m3u.isNotEmpty()
    }

    private val URL = Regex("""https?://[^\s"'<>]+""", RegexOption.IGNORE_CASE)
    private val BASE = Regex("""^(https?://[^/\s?#]+)""", RegexOption.IGNORE_CASE)
    private val HOSTPORT = Regex("""^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}(:\d{2,5})?""", RegexOption.IGNORE_CASE)
    private val Q_USER = Regex("""[?&]username=([^&\s]+)""", RegexOption.IGNORE_CASE)
    private val Q_PASS = Regex("""[?&]password=([^&\s]+)""", RegexOption.IGNORE_CASE)
    private val L_SERVER = Regex("""\b(server|host|url|portal|dns|address)\b""", RegexOption.IGNORE_CASE)
    private val L_USER = Regex("""\b(user\s*name|username|user|usr|login)\b""", RegexOption.IGNORE_CASE)
    private val L_PASS = Regex("""\b(pass\s*word|password|pass|pwd)\b""", RegexOption.IGNORE_CASE)

    fun parse(raw: String): Result? {
        val lines = raw.replace('\u00A0', ' ').lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null

        // 1) links
        var m3u = ""
        var firstBase = ""
        for (l in lines) {
            for (m in URL.findAll(l)) {
                val u = m.value.trimEnd('.', ',', ';', ')', ']')
                val usr = Q_USER.find(u)?.groupValues?.get(1)
                val pwd = Q_PASS.find(u)?.groupValues?.get(1)
                val base = BASE.find(u)?.groupValues?.get(1)
                if (usr != null && pwd != null && base != null) return Result(true, base, usr, pwd, u)
                if (m3u.isEmpty() && (u.contains("get.php", true) || u.contains("type=m3u", true) || u.contains(".m3u", true))) m3u = u
                if (firstBase.isEmpty() && base != null) firstBase = base
            }
        }

        // 2) labelled lines
        val usr = labelled(lines, L_USER).orEmpty()
        val pwd = labelled(lines, L_PASS).orEmpty()
        var srv = ""
        val sv = labelled(lines, L_SERVER).orEmpty()
        if (sv.isNotEmpty()) {
            val b = BASE.find(sv)?.groupValues?.get(1)
            srv = b ?: if (HOSTPORT.containsMatchIn(sv)) "http://" + HOSTPORT.find(sv)!!.value else ""
        }
        if (srv.isEmpty() && (usr.isNotEmpty() || pwd.isNotEmpty())) srv = firstBase
        if (srv.isNotEmpty() || usr.isNotEmpty() || pwd.isNotEmpty()) return Result(true, srv, usr, pwd, "")

        // 3) a lone M3U link
        if (m3u.isNotEmpty()) return Result(false, "", "", "", m3u)
        return null
    }

    /** value after a label on the same line, or the next line when the label stands alone */
    private fun labelled(lines: List<String>, label: Regex): String? {
        for ((i, l) in lines.withIndex()) {
            val m = label.find(l) ?: continue
            var v = l.substring(m.range.last + 1).trim().trimStart(':', '=', '-', '–', '،').trim()
            if (v.isEmpty() && i + 1 < lines.size) v = lines[i + 1].trim()
            val tok = v.split(Regex("\\s+")).firstOrNull().orEmpty().trim('"', '\'', '“', '”')
            if (tok.isNotEmpty()) return tok
        }
        return null
    }
}

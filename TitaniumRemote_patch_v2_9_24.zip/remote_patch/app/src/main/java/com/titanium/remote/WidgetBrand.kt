package com.titanium.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator

/**
 * The TV widget's brand mark, redrawn 1:1 on the phone (same shapes, same wordmark images, same timings as the widget's CSS):
 * [WidgetLogo] = the header logo with its 10.5 s loop, [WidgetIntro] = the start-up intro (bars + play slide apart, wordmark).
 * Coordinates below are the widget's own 640x130 viewBox units.
 */
internal object Brand {
    val EASE_IO: Interpolator = PathInterpolator(.42f, 0f, .58f, 1f)
    val OUT: Interpolator = PathInterpolator(.22f, .8f, .24f, 1f)

    /** piecewise animation: kf = t0,v0,t1,v1,... (t in 0..1); every interval eased with [ip] (CSS keyframe timing). */
    fun anim(t: Float, ip: Interpolator, vararg kf: Float): Float {
        val n = kf.size / 2
        if (t <= kf[0]) return kf[1]
        for (i in 0 until n - 1) {
            val a = kf[i * 2]; val b = kf[i * 2 + 2]
            if (t <= b) {
                val f = if (b > a) (t - a) / (b - a) else 1f
                val va = kf[i * 2 + 1]; val vb = kf[i * 2 + 3]
                return va + (vb - va) * ip.getInterpolation(f.coerceIn(0f, 1f))
            }
        }
        return kf[kf.size - 1]
    }

    fun bmp(ctx: Context, id: Int): Bitmap {
        val o = BitmapFactory.Options()
        o.inScaled = false
        return BitmapFactory.decodeResource(ctx.resources, id, o)
    }

    fun stroke(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.WHITE
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }

    /** the two 3D bars (x 560..622 in the widget) */
    fun bars(): Path = Path().also { p ->
        for (dx in floatArrayOf(0f, 34f)) {
            p.moveTo(560f + dx, 30f); p.lineTo(574f + dx, 22f); p.lineTo(588f + dx, 30f); p.lineTo(574f + dx, 38f); p.close()
            p.moveTo(560f + dx, 30f); p.lineTo(574f + dx, 38f); p.lineTo(574f + dx, 110f); p.lineTo(560f + dx, 102f); p.close()
            p.moveTo(574f + dx, 38f); p.lineTo(588f + dx, 30f); p.lineTo(588f + dx, 102f); p.lineTo(574f + dx, 110f); p.close()
        }
    }

    /** the 3D outlined play triangle (x 30..104) */
    fun play(): Path = Path().also { p ->
        p.moveTo(44f, 34f); p.lineTo(44f, 104f); p.lineTo(104f, 69f); p.close()
        p.moveTo(30f, 24f); p.lineTo(30f, 94f); p.lineTo(44f, 104f)
        p.moveTo(30f, 24f); p.lineTo(44f, 34f)
        p.moveTo(30f, 24f); p.lineTo(90f, 59f); p.lineTo(104f, 69f)
    }

    fun star(cx: Float, cy: Float, big: Float, small: Float): Path = Path().also { p ->
        p.moveTo(cx, cy - big); p.lineTo(cx + small, cy - small); p.lineTo(cx + big, cy); p.lineTo(cx + small, cy + small)
        p.lineTo(cx, cy + big); p.lineTo(cx - small, cy + small); p.lineTo(cx - big, cy); p.lineTo(cx - small, cy - small); p.close()
    }
}

/** Header logo: same layers and 10.5 s loop as the widget header (play glides over the word, sparkles, kashida stretch). */
class WidgetLogo(ctx: Context, private val hPx: Int) : View(ctx) {
    val logoWidth: Int = (hPx * 340f / 69f).toInt()
    private val k = hPx / 69f          // device px per box unit (the widget's logo box is 340 x 69)
    private val u = 340f / 640f        // box units per viewBox unit
    private val wl = Brand.bmp(ctx, R.drawable.tw_l)
    private val wm = Brand.bmp(ctx, R.drawable.tw_m)
    private val wr = Brand.bmp(ctx, R.drawable.tw_r)
    private val sp = Brand.stroke()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bars = Brand.bars()
    private val play = Brand.play()
    private val k1 = Brand.star(612f, 21f, 11f, 3f)
    private val k2 = Brand.star(630f, 36.4f, 6.4f, 1.8f)
    private val k3 = Brand.star(590f, 13.6f, 5.6f, 1.6f)
    private val r = RectF()
    private var t0 = 0L
    private var running = false

    /** kept name from the old logo class: just starts the loop. */
    fun showFinal() { start() }

    private fun start() { if (running) return; running = true; t0 = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }
    override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(logoWidth, hPx) }

    private fun twinkle(ms: Long, delayMs: Long): Float {
        val x = ms - delayMs
        if (x < 0) return 1f
        val f = (x % 2200L) / 2200f
        val a = if (f < .5f) f * 2f else (1f - f) * 2f
        return .35f + .65f * Brand.EASE_IO.getInterpolation(a)
    }

    override fun onDraw(c: Canvas) {
        val ms = SystemClock.uptimeMillis() - t0
        val t = (ms % 10500L) / 10500f
        val e = Brand.EASE_IO
        val fy = Brand.anim(t, e, 0f, 0f, .4686f, 0f, .5714f, -3f, .6743f, 0f, 1f, 0f)
        val px = Brand.anim(t, PathInterpolator(.6f, 0f, .25f, 1f), 0f, 0f, .3571f, 0f, .4686f, 233f, .6743f, 233f, .7857f, 0f, 1f, 0f)
        val wa = Brand.anim(t, e, 0f, 1f, .3314f, 1f, .4343f, 0f, .7086f, 0f, .8114f, 1f, 1f, 1f)
        val wy = Brand.anim(t, e, 0f, 0f, .3314f, 0f, .4343f, 4f, .7086f, 4f, .8114f, 0f, 1f, 0f)
        val sa = Brand.anim(t, e, 0f, 1f, .3314f, 1f, .4171f, 0f, .7257f, 0f, .8286f, 1f, 1f, 1f)
        // kashida pull on the last letter (widget: lgr / lgm / lgx)
        val trx = Brand.anim(t, e, 0f, 0f, .0381f, 0f, .1524f, 17.33f, .1905f, 17.33f, .3238f, 0f, 1f, 0f)
        val msx = Brand.anim(t, e, 0f, 1f, .0381f, 1f, .1524f, 5.25f, .1905f, 5.25f, .3238f, 1f, 1f, 1f)
        val lx = Brand.anim(t, e, 0f, 0f, .0381f, 0f, .1524f, 5f, .1905f, 5f, .3238f, 0f, 1f, 0f)
        val lr = Brand.anim(t, e, 0f, 0f, .0381f, 0f, .1524f, -2f, .1905f, -2f, .3238f, 0f, 1f, 0f)

        c.save(); c.scale(k, k); c.translate(0f, fy)
        // bars
        c.save(); c.scale(u, u); c.drawPath(bars, sp); c.restore()
        // play (glides to the bars and back)
        c.save(); c.translate(px, 0f); c.scale(u, u); c.drawPath(play, sp); c.restore()
        // wordmark
        bp.alpha = (wa * 255).toInt()
        c.save(); c.translate(0f, wy)
        c.translate(171f, 34f); c.scale(.92f, .92f); c.translate(lx, 0f); c.rotate(lr); c.translate(-171f, -34f)
        r.set(64.8f, 3.7f, 140.16f, 64.8f); c.drawBitmap(wl, null, r, bp)
        c.save(); c.scale(msx, 1f, 140.16f, 34f); r.set(140.16f, 3.7f, 152.4f, 64.8f); c.drawBitmap(wm, null, r, bp); c.restore()
        r.set(151.37f + trx, 3.7f, 285.28f + trx, 64.8f); c.drawBitmap(wr, null, r, bp)
        c.restore()
        // sparkles
        c.save(); c.scale(u, u)
        fill.alpha = (sa * twinkle(ms, 0) * 255).toInt(); c.drawPath(k1, fill)
        fill.alpha = (sa * twinkle(ms, 700) * 255).toInt(); c.drawPath(k2, fill)
        fill.alpha = (sa * twinkle(ms, 1400) * 255).toInt(); c.drawPath(k3, fill)
        c.restore()
        c.restore()
        if (running) postInvalidateOnAnimation()
    }
}

/** Start-up intro, same timeline as the widget: bars + play start together in the middle and slide apart (1.45 s), wordmark fades up at .85 s (no tagline on the phone). */
class WidgetIntro(ctx: Context) : View(ctx) {
    companion object {
        const val EXIT_AT = 2100L      // the logo has settled: from here it glides up and the remote rises
        const val EXIT_MS = 750L
        const val DURATION = EXIT_AT + EXIT_MS
    }
    private val word = Brand.bmp(ctx, R.drawable.tw_word)
    private val sp = Brand.stroke()
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bars = Brand.bars()
    private val play = Brand.play()
    private val r = RectF()
    private var t0 = 0L
    private var running = false

    fun play() { running = true; t0 = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
    fun stop() { running = false }

    private var exitStart = 0L
    private var exitMs = 1L
    private var exitX = 0f
    private var exitY = 0f
    private var exitScale = 1f

    /** glide the logo to (x, y) in this view's coordinates, shrinking to [scale], fading out over the last 45 % */
    fun exit(ms: Long, x: Float, y: Float, scale: Float) {
        exitMs = ms; exitX = x; exitY = y; exitScale = scale; exitStart = SystemClock.uptimeMillis()
    }

    override fun onDraw(c: Canvas) {
        val ms = (SystemClock.uptimeMillis() - t0).coerceAtLeast(0L)
        val sec = ms / 1000f
        val p = (sec / 1.45f).coerceIn(0f, 1f)
        val move = Brand.anim(p, Brand.OUT, 0f, 0f, .45f, 0f, 1f, 1f)          // 0 -> 1 after 45 % of the slide
        val scale = Brand.anim(p, Brand.EASE_IO, 0f, 1f, .14f, 1.06f, .24f, 1f, 1f, 1f)
        val barsX = -219.3f * (1f - move)      // widget: -377 px on a 1100 px stage = -219.3 viewBox units
        val playX = 402.6f * (1f - move)       // 692 px = 402.6 units (relative to the bars group)
        val wp = ((sec - .85f) / .75f).coerceIn(0f, 1f)
        val wa = Brand.OUT.getInterpolation(wp)

        val s = width * .8f / 542f
        val ox = (width - 542f * s) / 2f - 44f * s
        val oy = height * .46f - 65f * s
        // exit: glide up into the header while shrinking, then fade
        var fade = 1f
        c.save()
        if (exitStart > 0L) {
            val ep = ((SystemClock.uptimeMillis() - exitStart).toFloat() / exitMs).coerceIn(0f, 1f)
            val e = Brand.EASE_IO.getInterpolation(ep)
            val cx = width / 2f
            val cy = oy + 65f * s
            c.translate((exitX - cx) * e, (exitY - cy) * e)
            val sc = 1f + (exitScale - 1f) * e
            c.scale(sc, sc, cx, cy)
            fade = 1f - ((ep - .55f) / .45f).coerceIn(0f, 1f)
        }
        sp.alpha = (fade * 255).toInt()
        c.save(); c.translate(ox, oy); c.scale(s, s)
        // bars + play (play rides inside the bars' group, as in the widget)
        c.save(); c.translate(barsX, 0f); c.scale(scale, scale, 545.2f, 64.6f)
        c.save(); c.translate(-36f, 0f); c.drawPath(bars, sp); c.restore()
        c.save(); c.translate(playX + 14f, 0f); c.drawPath(play, sp); c.restore()
        c.restore()
        // wordmark
        bp.alpha = (wa * fade * 255).toInt()
        c.save(); c.translate(0f, 5.8f * (1f - wa)); c.scale(.89f, .89f, 318f, 65f)
        r.set(117.21f, 5.5f, 117.21f + 402f, 5.5f + 115.7f); c.drawBitmap(word, null, r, bp)
        c.restore()
        c.restore()
        c.restore()
        if (running) postInvalidateOnAnimation()
    }
}

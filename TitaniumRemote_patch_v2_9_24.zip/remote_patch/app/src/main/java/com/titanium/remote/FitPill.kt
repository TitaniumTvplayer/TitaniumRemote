package com.titanium.remote

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Rounded glass key with an icon and a label that always fits: the text is a bit smaller than before, never touches the
 * edges and is shrunk (down to 9 sp) when the label is long, so nothing is cut off. Same look as the other glass keys.
 */
class FitPill(
    ctx: Context, res: Int, private val label: String, bg: Int, fg: Int, desc: String, iconAfter: Boolean = false
) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val tv: TextView = Ui.text(ctx, label, 13f, fg, 7)
    private val padH = (14 * d).toInt()
    private val iconPx = (18 * d).toInt()
    private val gapPx = (8 * d).toInt()

    init {
        contentDescription = desc
        isClickable = true
        isFocusable = true
        val top = mix(bg, Color.WHITE, 0.10f)
        val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bg))
        face.cornerRadius = 100 * d
        face.setStroke(maxOf(1, d.toInt()), Color.argb(46, 255, 255, 255))
        val mask = GradientDrawable()
        mask.cornerRadius = 100 * d
        mask.setColor(Color.WHITE)
        background = Ui.ripple(face, mask)

        tv.maxLines = 1
        tv.includeFontPadding = false
        tv.gravity = Gravity.CENTER
        val icon = ImageView(ctx)
        icon.setImageResource(res)
        icon.setColorFilter(fg)
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.layoutDirection = View.LAYOUT_DIRECTION_LTR      // icon always on the left of the label, like the other keys
        if (iconAfter) {
            row.addView(tv, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
            row.addView(icon, LinearLayout.LayoutParams(iconPx, iconPx).also { it.marginStart = gapPx })
        } else {
            row.addView(icon, LinearLayout.LayoutParams(iconPx, iconPx).also { it.marginEnd = gapPx })
            row.addView(tv, LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        }
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val avail = w - 2 * padH - iconPx - gapPx
        var sp = 13f
        val p = tv.paint
        while (sp > 9f) {
            p.textSize = sp * resources.displayMetrics.scaledDensity
            if (p.measureText(label) <= avail) break
            sp -= 0.5f
        }
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.argb(
        255,
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}

# Titanium Remote 2.0

Phone-side remote for the Titanium TV app (`TitaniumTV_0.3.504.wgt`).

- Pairing: the TV shows a 4-digit code + QR. Scan it (or type the code) once; the pairing is saved on both sides.
- Remote: arrows / OK / Back / Home, touchpad, play-pause, seek, CH +/-, keyboard text, IPTV source sending.
- Runs as a foreground service, so it keeps working with the screen off.
- Alexandria font, the same Titanium logo and intro as the TV app (play glyph + bars slide apart, wordmark, tagline, loader, intro sound).

Build: push to GitHub (Actions builds `app-release.apk` + `app-debug.apk`) or open in Android Studio.
The repo contains a fixed signing key (`app/titanium.jks`) so new builds install over old ones.
Protocol: see `TV_INTEGRATION_PROTOCOL.md` (v1 endpoints unchanged; added `X-Titanium-Code` pairing and `key` events).

## 2.8
- Remote page re-laid out from the supplied reference: tab bar moved to the top (Remote / Source / Type & search / Settings); Series / Movies / Live round keys; two wide keys (Settings, Sort & Filter); smaller OK disc; Back is now bigger with an outline and a straight arrow, Home sits mirrored on the other side of the pad; Previous / Next keys; Search moved to the "Type & search" tab.
- "Sort & Filter" now sends the new `sortf` key (opens the TV's existing Sort & Filter window). Category reordering is its own key at the bottom ("Reorder categories", `green`). Needs the matching TV build (see protocol 2.8).

## 2.7
- Remote page rebuilt from the user's layout sketch (`Pad.kt`): light-grey page; small Settings / Search / Sort keys down the left; Series / Movies / Live / Home round keys across the top; one big black ring with the dark OK disc (no arrow glyphs - tap the ring's top / right / bottom / left to send the arrow, hold to repeat; "Touchpad instead of arrows" still turns the ring into a swipe pad); Users (red), Translate (yellow, lower) and Ask Titanium (deep blue) keys; back-10 / Play-Pause / forward-10 row.
- The layout lives in a fixed 360 x 545 dp design space (`DesignCanvas`) and scales uniformly to fit any screen, so nothing scrolls.
- Back, Info and CH +/- are not in this layout and were removed from the page.
- Light and dark mode: the remote page follows the phone theme. Light = grey page; dark = deep-black page with lifted charcoal keys and a slightly lighter ring.
- Flat look: all gradients removed (surfaces, accent buttons, OK disc, Ask Titanium key); no shadows.
- Back-10 / forward-10, Users, Movies, Translate and Live icons are now the supplied artwork (and the Series TV, vector-traced from the supplied glow image; white-on-alpha PNGs in `drawable-nodpi`, tinted in code); the remaining icons are redrawn vectors to match the layout sketch. Left keys are squircles; Ask Titanium has a shaded deep-blue disc.

## 2.6
- Remote page keys restyled like the TV app: Users / Translate / Ask Titanium are flat round keys (rose, yellow, light blue). Ask Titanium shows the logo's pause bars with two dots above that blink like eyes (`AskKey.kt`).
- Top shortcut row: flat charcoal round keys with solid white icons (`ic_*_s.xml`).
- New intro: the real Titanium logo (outlined play | wordmark | outlined pause bars, same motion as the TV app) plays in the middle of the screen, glides up, and the new remote artwork slides up from the bottom edge. Same intro sound, tap skips it. Layer: `drawable-nodpi/intro_remote.png` (transparent white-line remote), code in `Intro.kt`. The old swoosh / close-up layers were removed.

## 2.5
- New app icon (launcher, round, themed/monochrome) from the new artwork: play + bars, swoosh and remote.
- New intro from the same artwork: close-up on the logo, camera pulls back, the swoosh sweeps in and the remote slides into place. Same intro sound, tap skips it. Layers: `drawable-nodpi/intro_logo|intro_swoosh|intro_remote.png`, code in `Intro.kt`.

- Remote page now fits on one screen, no scrolling: arrows pad / OK 10 % smaller, tighter spacing, "Unpair TV" button removed from the page (still in the phone settings). If a very short screen still can't fit it, the page scales down to fit.
- Top row reversed (Home first from the right, then Live, Movies, Series, Search, Settings); the old Home key is gone, Back and Info are small keys at the two edges beside the pad.
- Arrows / Touchpad switch removed from the remote page; it is now a switch in the phone settings ("Touchpad instead of arrows").

- Top shortcut row reversed (Settings, Search, Series, Movies, Live, Home) with a new Home key first from the right (opens the TV app's home). The old Home button is gone; Back and Info are smaller and sit at the left/right edges.

- Coloured keys are now round icon buttons (Accounts / Translate / Ask Titanium). The green key moved to the top row (between Settings and Search) as "Sort" with a filter icon; it still sends `green`, so the TV app must open its sort + filter dialog for it.
- Clearer top-row icons: Movies = clapperboard, Series = stack of cards with a play button.

- Phone settings moved from a dialog behind the header gear to a 4th tab in the bottom bar (Remote / Source / Keyboard / Settings), laid out as cards: Remote (touchpad instead of arrows, intro sound), TV & connection (live pairing status, device, IP & port), Unpair TV, version.

## 2.4
- Logo and intro now identical to the TV app (TitaniumTVbeta3_507): same vector logo (outlined play | wordmark | outlined bars), same intro timeline and easing, same tagline, loader and sound. Tap skips it. "Intro sound" switch in the phone settings.
- New consistent rounded-stroke icon set; glass surfaces (same look as the TV), accent-gradient primary buttons, press feedback on every key.
- Remote: labelled shortcut row (Live / Movies / Series / Search / Settings), larger d-pad chevrons with a ring around OK, accent Play/Pause. Pairing screen with numbered steps. Bottom bar with a pill indicator. Input fields highlight on focus.
- Launcher icon = the TV app's glyph (plus a themed monochrome icon for Android 13+); notification icon is now a vector.

## 2.3
- Top row of the remote: Live, Movies, Series, Search, Settings. Live/Movies/Series press the same tabs as the TV top bar; Search opens the TV search box (needs TV app 0.3.507).

## 2.2
- Saved sources: keep many IPTV sources on the phone, pick any one and send it to the TV. Playlist name is optional (the TV falls back to host · user).

## 2.1
- Coloured keys row under the pad: Red = Accounts, Green = Sort, Yellow = Translate, Blue = Ask Titanium.
- The gear in the top shortcut row opens the TV app's Settings on the TV (needs TV app 0.3.505). Phone settings: gear in the header.

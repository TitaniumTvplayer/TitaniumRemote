package com.titanium.remote

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.LinkedBlockingDeque

/** Shared state between the UI, the foreground service and the HTTP server. */
object Hub {
    const val PORT = 8765
    val queue = LinkedBlockingDeque<JSONObject>()

    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val rnd = SecureRandom()

    @Volatile var running = false
    @Volatile var error: String? = null
    @Volatile var lastSeen = 0L
    @Volatile var splashDone = false
    @Volatile var mismatch = false
    @Volatile var onChange: (() -> Unit)? = null

    /** Set while the app screen is in front: the TV asks the phone to open its typing keyboard (search box opened on the TV). */
    @Volatile var onKbd: ((Boolean) -> Unit)? = null

    /** Returns true when the app screen is open and will show / hide the keyboard; false when it cannot (the TV then uses its own keyboard). */
    fun kbd(on: Boolean): Boolean {
        val f = onKbd ?: return false
        main.post { f(on) }
        return true
    }

    @Volatile var pendingCode: String? = null
    @Volatile private var pendingUntil = 0L
    @Volatile private var lockUntil = 0L
    private val tried = HashSet<String>()

    /** App language: "" = follow the phone, "ar" or "en" = chosen in the app settings. */
    fun lang(): String = if (::prefs.isInitialized) prefs.getString("lang", "") ?: "" else ""

    fun setLang(l: String) {
        if (::prefs.isInitialized) prefs.edit().putString("lang", l).apply()
    }

    val ar: Boolean get() = when (lang()) {
        "ar" -> true
        "en" -> false
        else -> Locale.getDefault().language == "ar"
    }

    private var appCtx: Context? = null

    fun init(ctx: Context) {
        if (appCtx == null) appCtx = ctx.applicationContext
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences("titanium_remote", Context.MODE_PRIVATE)
        }
    }

    private fun randomHex(bytes: Int): String {
        val b = ByteArray(bytes)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun deviceId(): String {
        var id = prefs.getString("id", null)
        if (id == null) {
            id = randomHex(8)
            prefs.edit().putString("id", id).apply()
        }
        return id
    }

    fun deviceName(): String = android.os.Build.MODEL ?: "Android"

    /** Play the TV intro sound together with the phone intro (on by default, same as the TV). */
    fun introSound(): Boolean = ::prefs.isInitialized && prefs.getBoolean("intro_sound", true)

    fun setIntroSound(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("intro_sound", on).apply()
    }

    /** Short click sound on every key press (on by default; switch in Preferences). */
    fun clickSound(): Boolean = !::prefs.isInitialized || prefs.getBoolean("click_sound", true)

    fun setClickSound(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("click_sound", on).apply()
    }

    /** Haptic feedback on every key press (on by default; switch in Preferences). */
    fun haptics(): Boolean = !::prefs.isInitialized || prefs.getBoolean("haptics", true)

    /** Typing page: send the text to the TV while typing (off by default until the TV build is confirmed to replace the field text). */
    fun liveType(): Boolean = ::prefs.isInitialized && prefs.getBoolean("live_type", false)

    fun setLiveType(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("live_type", on).apply()
    }

    fun setHaptics(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("haptics", on).apply()
    }

    /** Remote page shows the touchpad instead of the arrows pad (set from the phone settings). */
    fun touchMode(): Boolean = ::prefs.isInitialized && prefs.getBoolean("touch_mode", false)

    fun setTouchMode(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("touch_mode", on).apply()
    }

    /** Remote page layout: 0 = classic, 1 = arcs (chosen in the phone settings). */
    fun layout(): Int = if (::prefs.isInitialized) prefs.getInt("layout", 0) else 0

    fun setLayout(l: Int) {
        if (::prefs.isInitialized) prefs.edit().putInt("layout", l).apply()
    }

    // ---- saved TV pairings (long random tokens, stored on the phone) ----
    private fun tokenList(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(prefs.getString("tokens", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun isPaired(): Boolean = tokenList().isNotEmpty()

    fun validToken(t: String?): Boolean = !t.isNullOrEmpty() && tokenList().contains(t)

    @Synchronized
    private fun addToken(): String {
        val t = randomHex(16)
        val l = tokenList()
        l.add(t)
        while (l.size > 5) l.removeAt(0)
        prefs.edit().putString("tokens", JSONArray(l).toString()).apply()
        return t
    }

    fun forgetAll() {
        prefs.edit().remove("tokens").apply()
        queue.clear()
        pendingCode = null
        changed()
    }

    // ---- 4-digit pairing code shown on the TV and typed / scanned on the phone ----
    fun armCode(code: String) {
        synchronized(this) {
            pendingCode = code
            pendingUntil = System.currentTimeMillis() + 5 * 60_000L
            tried.clear()
            mismatch = false
        }
        changed()
    }

    fun disarm() {
        pendingCode = null
        mismatch = false
        changed()
    }

    /** True during the one-minute lock that follows too many different wrong codes. */
    fun locked(): Boolean = System.currentTimeMillis() < lockUntil

    fun codeActive(): Boolean = pendingCode != null && System.currentTimeMillis() < pendingUntil

    /** Returns (token, "") when the TV's code matches the one entered on the phone, else (null, reason). */
    @Synchronized
    fun tryPair(code: String): Pair<String?, String> {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return Pair(null, "locked")
        if (!codeActive()) return Pair(null, "need_code")
        if (code == pendingCode) {
            pendingCode = null
            mismatch = false
            tried.clear()
            val t = addToken()
            changed()
            return Pair(t, "")
        }
        // the same wrong code retried by the TV does not count; many DIFFERENT guesses lock pairing for a minute
        val fresh = tried.add(code)
        val wasMismatch = mismatch
        mismatch = true
        if (tried.size >= 5) {
            lockUntil = now + 60_000L
            pendingCode = null
            tried.clear()
            changed()
        } else if (fresh || !wasMismatch) {
            changed()
        }
        return Pair(null, "bad_code")
    }

    // ---- saved IPTV sources (kept on the phone, sent to the TV on demand) ----
    class Src(
        val id: String,
        var name: String,
        var xtream: Boolean,
        var server: String = "",
        var user: String = "",
        var pass: String = "",
        var url: String = ""
    ) {
        /** Name shown in the list: the playlist name if given, else the host (and user for Xtream). */
        fun title(): String {
            if (name.isNotBlank()) return name
            val h = hostOf(if (xtream) server else url)
            return if (xtream && user.isNotBlank()) "$h · $user" else h
        }

        fun subtitle(): String =
            if (xtream) "Xtream · " + hostOf(server) + " · " + user else "M3U · " + hostOf(url)
    }

    fun hostOf(s: String): String =
        s.trim().replace(Regex("^[a-zA-Z]+://"), "").substringBefore('/').ifEmpty { s }

    fun newSourceId(): String = randomHex(4)

    @Synchronized
    fun sources(): MutableList<Src> {
        val out = mutableListOf<Src>()
        try {
            val a = JSONArray(prefs.getString("sources", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Src(
                        o.getString("id"), o.optString("name"), o.optString("fmt") != "m3u",
                        o.optString("server"), o.optString("user"), o.optString("pass"), o.optString("url")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeSources(l: List<Src>) {
        val a = JSONArray()
        for (s in l) {
            a.put(
                JSONObject().put("id", s.id).put("name", s.name).put("fmt", if (s.xtream) "xtream" else "m3u")
                    .put("server", s.server).put("user", s.user).put("pass", s.pass).put("url", s.url)
            )
        }
        prefs.edit().putString("sources", a.toString()).apply()
    }

    /** Adds the source, or replaces the one with the same id. */
    @Synchronized
    fun saveSource(s: Src) {
        val l = sources()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l.add(s)
        writeSources(l)
    }

    @Synchronized
    fun deleteSource(id: String) {
        writeSources(sources().filter { it.id != id })
    }

    /** The event the TV expects; "name" is only added when the user gave one. */
    fun sourceEvent(s: Src): JSONObject {
        val e = JSONObject().put("type", "iptv_credentials")
        if (s.xtream) e.put("format", "xtream").put("server", s.server).put("username", s.user).put("password", s.pass)
        else e.put("format", "m3u").put("url", s.url)
        if (s.name.isNotBlank()) e.put("name", s.name)
        return e
    }

    // ---- TV -> phone backup (the TV POSTs /library/sources or /library/profiles) ----
    /** Called on the main thread when the TV has just stored something on the phone (the Source page redraws). */
    @Volatile var onLibrary: (() -> Unit)? = null

    private const val PROFILES_FILE = "tv_profiles_backup.json" // legacy single-file format, migrated on first read
    private const val MAX_BODY = 16 * 1024 * 1024
    /** automatic backups kept (a new one pushes the oldest automatic one out) and manual backups kept: separate quotas */
    const val MAX_AUTO = 5
    const val MAX_MANUAL = 5
    private const val AUTO_GAP = 24L * 3600L * 1000L // an automatic backup less than a day after the previous automatic one replaces it (keeps it fresh without using a new slot)

    fun maxBody(): Int = MAX_BODY

    private fun sameSource(a: Src, b: Src): Boolean =
        if (a.xtream && b.xtream)
            a.server.trim().trimEnd('/').equals(b.server.trim().trimEnd('/'), true) && a.user.trim() == b.user.trim()
        else !a.xtream && !b.xtream && a.url.trim() == b.url.trim()

    /**
     * Sources sent by the TV (same item format as the TV's own "Sources backup" file). Sources the phone already has are skipped.
     * Returns (added, total in the message) or null when the message is not valid.
     */
    @Synchronized
    fun importSources(body: String): Pair<Int, Int>? {
        val arr = try {
            JSONObject(body).getJSONArray("sources")
        } catch (_: Exception) {
            return null
        }
        val l = sources()
        var added = 0
        var total = 0
        for (i in 0 until minOf(arr.length(), 200)) {
            val o = arr.optJSONObject(i) ?: continue
            val xt = o.optString("type") == "xtream"
            val s = if (xt) Src(newSourceId(), o.optString("name").take(60), true, o.optString("server").take(300), o.optString("username").take(200), o.optString("password").take(200), "")
            else Src(newSourceId(), o.optString("name").take(60), false, "", "", "", o.optString("url").take(2000))
            if (xt && (s.server.isBlank() || s.user.isBlank() || s.pass.isBlank())) continue
            if (!xt && !Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(s.url.trim())) continue
            total++
            if (l.any { sameSource(it, s) }) continue
            l.add(s)
            added++
        }
        if (total == 0) return null
        if (added > 0) writeSources(l)
        main.post { onLibrary?.invoke() }
        return Pair(added, total)
    }

    /** One accounts backup kept on the phone: its storage id, how many profiles it holds, and when it was saved. */
    data class BackupEntry(val id: String, val n: Int, val t: Long, val auto: Boolean = false)

    private fun backupFile(id: String) = java.io.File(appCtx!!.filesDir, "tv_profiles_backup_$id.json")

    private fun backupIndex(): MutableList<BackupEntry> {
        val out = mutableListOf<BackupEntry>()
        try {
            val a = JSONArray(prefs.getString("pb_list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(BackupEntry(o.getString("id"), o.optInt("n"), o.optLong("t"), o.optInt("a") == 1))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeBackupIndex(l: List<BackupEntry>) {
        val a = JSONArray()
        for (e in l) a.put(JSONObject().put("id", e.id).put("n", e.n).put("t", e.t).put("a", if (e.auto) 1 else 0))
        prefs.edit().putString("pb_list", a.toString()).apply()
    }

    /** A single old-style backup (from before multiple backups were kept) is folded into the new list, once. */
    private fun migrateLegacyBackup() {
        val c = appCtx ?: return
        if (prefs.contains("pb_list")) return
        val n = prefs.getInt("pb_n", 0)
        val legacy = java.io.File(c.filesDir, PROFILES_FILE)
        if (n <= 0 || !legacy.exists()) {
            writeBackupIndex(emptyList())
            return
        }
        try {
            val id = randomHex(6)
            legacy.copyTo(backupFile(id), overwrite = true)
            writeBackupIndex(listOf(BackupEntry(id, n, prefs.getLong("pb_t", System.currentTimeMillis()))))
            legacy.delete()
        } catch (_: Exception) {
            writeBackupIndex(emptyList())
        }
    }

    /** The TV's accounts (profiles) backup, kept as the TV wrote it, alongside any earlier ones (automatic and manual ones have separate quotas). Returns the number of profiles or null when it is not a Titanium profiles backup. */
    @Synchronized
    fun saveProfilesBackup(body: String): Int? {
        var auto = false
        val n = try {
            val o = JSONObject(body)
            if (o.optString("app") != "Titanium" || o.optString("kind") != "profiles") return null
            val pf = o.getJSONArray("pf")
            if (pf.length() == 0 || o.optJSONObject("d") == null) return null
            auto = o.optInt("auto") == 1
            pf.length()
        } catch (_: Exception) {
            return null
        }
        val c = appCtx ?: return null
        migrateLegacyBackup()
        return try {
            val id = randomHex(6)
            backupFile(id).writeText(body, Charsets.UTF_8)
            val l = backupIndex()
            val now = System.currentTimeMillis()
            // the TV's automatic backups: within a day the newest automatic one is simply refreshed (no new slot)
            if (auto) {
                val topAuto = l.firstOrNull { it.auto }
                if (topAuto != null && now - topAuto.t < AUTO_GAP) {
                    l.remove(topAuto)
                    try {
                        backupFile(topAuto.id).delete()
                    } catch (_: Exception) {
                    }
                    if (prefs.getString("pb_sel", "") == topAuto.id) prefs.edit().putString("pb_sel", id).apply()
                }
            }
            l.add(0, BackupEntry(id, n, now, auto))
            // separate quotas: when the automatic ones are full the oldest automatic one goes; manual ones are never pushed out by automatic ones
            for ((isAuto, max) in listOf(true to MAX_AUTO, false to MAX_MANUAL)) {
                while (l.count { it.auto == isAuto } > max) {
                    val old = l.removeAt(l.indexOfLast { it.auto == isAuto })
                    try {
                        backupFile(old.id).delete()
                    } catch (_: Exception) {
                    }
                }
            }
            writeBackupIndex(l)
            main.post { onLibrary?.invoke() }
            n
        } catch (_: Exception) {
            null
        }
    }

    /** Which saved backup a TV restore pulls: the one the person picked, else the newest. */
    @Synchronized
    fun selectedBackupId(): String {
        val l = profilesBackups()
        val s = if (::prefs.isInitialized) prefs.getString("pb_sel", "") ?: "" else ""
        return if (l.any { it.id == s }) s else (l.firstOrNull()?.id ?: "")
    }

    fun selectBackup(id: String) {
        if (::prefs.isInitialized) prefs.edit().putString("pb_sel", id).apply()
    }

    // ---- automatic backup switch (the phone decides; the TV follows through /next and can report its own change) ----
    /** Called on the main thread when the TV flipped its own automatic-backup switch. */
    @Volatile var onAbk: (() -> Unit)? = null

    fun autoBackup(): Boolean = ::prefs.isInitialized && prefs.getBoolean("abk", false)

    /** 0 = the phone never set it (the TV keeps whatever it has). */
    fun abkVersion(): Int = if (::prefs.isInitialized) prefs.getInt("abk_v", 0) else 0

    fun setAutoBackup(on: Boolean, fromPhone: Boolean) {
        if (!::prefs.isInitialized) return
        val ed = prefs.edit().putBoolean("abk", on)
        if (fromPhone) ed.putInt("abk_v", abkVersion() + 1)
        ed.apply()
        if (!fromPhone) main.post { onAbk?.invoke() }
    }

    // ---- SubDL API key (subtitles): the phone holds it, the TV follows through /next and can report its own change ----
    /** Called on the main thread when the TV reported a key typed on the TV itself. */
    @Volatile var onSdk: (() -> Unit)? = null

    fun sdKey(): String = if (::prefs.isInitialized) (prefs.getString("sdk", "") ?: "") else ""

    /** 0 = the phone never set it (the TV keeps whatever it has and reports it to the phone). */
    fun sdkVersion(): Int = if (::prefs.isInitialized) prefs.getInt("sdk_v", 0) else 0

    fun setSdKey(key: String, fromPhone: Boolean) {
        if (!::prefs.isInitialized) return
        val ed = prefs.edit().putString("sdk", key.trim().take(200))
        if (fromPhone) ed.putInt("sdk_v", sdkVersion() + 1)
        ed.apply()
        if (!fromPhone) main.post { onSdk?.invoke() }
    }

    /** All accounts backups kept on the phone, newest first. */
    @Synchronized
    fun profilesBackups(): List<BackupEntry> {
        if (!::prefs.isInitialized || appCtx == null) return emptyList()
        migrateLegacyBackup()
        return backupIndex()
    }

    /** The accounts backup a TV restore pulls (the picked one, else the newest) as JSON — kept for the HTTP endpoint. */
    fun profilesBackupJson(): JSONObject? = selectedBackupId().takeIf { it.isNotEmpty() }?.let { profilesBackupJson(it) }

    /** One specific saved accounts backup as a JSON object (what the TV originally sent), or null when there is none with that id. */
    fun profilesBackupJson(id: String): JSONObject? {
        val c = appCtx ?: return null
        return try {
            val f = java.io.File(c.filesDir, "tv_profiles_backup_$id.json")
            if (f.exists()) JSONObject(f.readText(Charsets.UTF_8)) else null
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun deleteProfilesBackup(id: String) {
        try {
            backupFile(id).delete()
        } catch (_: Exception) {
        }
        writeBackupIndex(backupIndex().filter { it.id != id })
    }

    fun deleteAllProfilesBackups() {
        for (e in profilesBackups()) deleteProfilesBackup(e.id)
    }

    fun send(e: JSONObject) {
        while (queue.size > 60) queue.poll()
        try {
            e.put("t", System.currentTimeMillis())
        } catch (_: Exception) {
        }
        queue.offer(e)
    }

    fun changed() {
        main.post { onChange?.invoke() }
    }

    fun localIp(): String {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            var fallback = ""
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ni.name.startsWith("wlan")) return ip
                        if (fallback.isEmpty()) fallback = ip
                    }
                }
            }
            if (fallback.isNotEmpty()) return fallback
        } catch (_: Exception) {
        }
        return ""
    }
}

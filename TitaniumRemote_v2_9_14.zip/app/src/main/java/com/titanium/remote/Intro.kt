package com.titanium.remote

import android.animation.ValueAnimator
import android.content.Context
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.max
import kotlin.math.min

/**
 * App intro: the real Titanium logo (outlined play | wordmark | outlined pause bars, the same one and the same
 * motion as the TV app) followed by the remote, which rises from the bottom edge of the screen.
 *
 * Timeline (ms):
 *      0 - 1600  logo plays its own intro in the middle of the screen (play + bars slide apart, wordmark fades in)
 *   1900 - 2700  logo glides up to the top third
 *   1900 - 3100  remote slides up from the bottom (it continues off-screen, like the real remote)
 *   3100 - 3800  hold
 *
 * The view fills its parent. Call [play] once laid out.
 */
class TitaniumIntro(ctx: Context) : FrameLayout(ctx) {
    companion object {
        const val DURATION = 3800L

        private const val LOGO_W = 0.84f      // logo width / screen width
        private const val REMOTE_H = 0.56f    // remote height / screen height (limited by REMOTE_MAX_W too)
        private const val REMOTE_MAX_W = 0.66f
        private const val REMOTE_RATIO = 677f / 1133f

        private val EASE_OUT = PathInterpolator(0.22f, 0.8f, 0.24f, 1f)
        private val EASE_MOVE = PathInterpolator(0.45f, 0f, 0.15f, 1f)
    }

    private var logo: TitaniumLogo? = null
    private var remote: ImageView? = null
    private var anim: ValueAnimator? = null
    private var startY = 0f
    private var endY = 0f
    private var remoteSlide = 0f
    private var lastMs = 0f
    private var pendingPlay = false

    private fun unit(v: Float): Float = max(0f, min(1f, v))

    private var builtW = 0
    private var builtH = 0

    /**
     * The children are created here (not in onSizeChanged) and measured by hand: views added while the parent is
     * already being laid out get no measure pass, so they ended up 0x0 and the intro showed only a black screen.
     */
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        if (w > 0 && h > 0 && (logo == null || builtW != w || builtH != h)) build(w, h)
        super.onLayout(changed, l, t, r, b)
    }

    private fun build(w: Int, h: Int) {
        builtW = w
        builtH = h
        removeAllViewsInLayout()

        // remote: bottom aligned, cropped by the screen edge
        var rh = (h * REMOTE_H).toInt()
        var rw = (rh * REMOTE_RATIO).toInt()
        if (rw > w * REMOTE_MAX_W) {
            rw = (w * REMOTE_MAX_W).toInt()
            rh = (rw / REMOTE_RATIO).toInt()
        }
        val r = ImageView(context)
        r.setImageResource(R.drawable.intro_remote)
        r.scaleType = ImageView.ScaleType.FIT_XY
        val rlp = LayoutParams(rw, rh)
        rlp.leftMargin = (w - rw) / 2
        rlp.topMargin = h - rh
        addViewInLayout(r, -1, rlp, true)
        r.measure(MeasureSpec.makeMeasureSpec(rw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(rh, MeasureSpec.EXACTLY))
        remote = r
        remoteSlide = rh * 0.55f

        // logo: the real app logo
        val wordH = ((w * LOGO_W) / TitaniumLogo.RATIO).toInt()
        val l = TitaniumLogo(context, wordH)
        l.showFinal()
        val llp = LayoutParams(l.logoWidth, wordH)
        llp.leftMargin = (w - l.logoWidth) / 2
        llp.topMargin = 0
        addViewInLayout(l, -1, llp, true)
        l.measure(MeasureSpec.makeMeasureSpec(l.logoWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(wordH, MeasureSpec.EXACTLY))
        logo = l

        val remoteTop = h - rh
        startY = h / 2f - wordH / 2f
        endY = max(h * 0.05f, remoteTop / 2f - wordH / 2f)
        render(lastMs)
        if (pendingPlay) {
            pendingPlay = false
            start()
        }
    }

    /** Draws the remote + logo position at [ms] milliseconds. */
    private fun render(ms: Float) {
        lastMs = ms
        val l = logo ?: return
        val r = remote ?: return

        // logo: centre of the screen -> top third
        val m = EASE_MOVE.getInterpolation(unit((ms - 1900f) / 800f))
        l.translationY = startY + (endY - startY) * m

        // remote: slides up from the bottom edge
        val e = EASE_OUT.getInterpolation(unit((ms - 1900f) / 1200f))
        r.alpha = unit(e * 2.2f)
        r.translationY = (1f - e) * remoteSlide
    }

    private fun start() {
        val l = logo ?: return
        l.playIntro()
        val a = ValueAnimator.ofFloat(0f, DURATION.toFloat())
        a.duration = DURATION
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { render(it.animatedValue as Float) }
        anim = a
        a.start()
    }

    fun play() {
        stop()
        render(0f)
        if (logo == null) {
            pendingPlay = true   // not laid out yet: starts from onSizeChanged
        } else {
            start()
        }
    }

    fun stop() {
        pendingPlay = false
        anim?.cancel()
        anim = null
        logo?.stop()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }
}

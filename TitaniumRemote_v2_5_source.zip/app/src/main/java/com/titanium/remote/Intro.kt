package com.titanium.remote

import android.animation.ValueAnimator
import android.content.Context
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * App intro built from the app artwork (play glyph + bars, swoosh, remote), split into three transparent layers
 * that all share the artwork's 1254 px square:  intro_logo / intro_swoosh / intro_remote.
 *
 * Timeline (ms) - the camera starts as a close-up on the logo and pulls back to reveal the whole picture:
 *      0 -  500  logo fades in (close-up), little pulse 150-800
 *    600 - 2500  camera pull-back (zoom 1.5 -> 1.0, focus moves from the logo to the centre)
 *    900 - 2300  swoosh sweeps in (rotates / grows into place)
 *   1100 - 2600  remote slides in along its own axis from the lower left
 *   2600 - 3500  hold on the finished artwork
 *
 * [size] is the side of the square in px (the activity passes the screen width). Call [play] once laid out.
 */
class TitaniumIntro(ctx: Context, private val size: Int) : FrameLayout(ctx) {
    companion object {
        const val DURATION = 3500L

        private const val SRC = 1254f            // artwork size in px
        private const val LOGO_X = 552f          // centre of the play glyph + bars
        private const val LOGO_Y = 292f
        private const val REMOTE_X = 640f        // rough centre of the remote
        private const val REMOTE_Y = 850f
        private const val START_ZOOM = 1.5f

        private val CAMERA = PathInterpolator(0.55f, 0f, 0.15f, 1f)
        private val EASE_OUT = PathInterpolator(0.22f, 0.8f, 0.24f, 1f)
        private val EASE_FADE = PathInterpolator(0f, 0f, 0.58f, 1f)
    }

    private val stage = FrameLayout(ctx)
    private val swoosh = ImageView(ctx)
    private val remote = ImageView(ctx)
    private val logo = ImageView(ctx)
    private var anim: ValueAnimator? = null

    private val cx = size / 2f
    private val lx = LOGO_X / SRC * size
    private val ly = LOGO_Y / SRC * size

    init {
        clipChildren = false
        clipToPadding = false
        stage.clipChildren = false
        stage.clipToPadding = false
        // back to front: swoosh, remote, logo
        for ((v, res) in listOf(
            swoosh to R.drawable.intro_swoosh,
            remote to R.drawable.intro_remote,
            logo to R.drawable.intro_logo
        )) {
            v.setImageResource(res)
            v.scaleType = ImageView.ScaleType.FIT_XY
            stage.addView(v, LayoutParams(size, size))
        }
        addView(stage, LayoutParams(size, size))

        stage.pivotX = cx
        stage.pivotY = cx
        logo.pivotX = lx
        logo.pivotY = ly
        swoosh.pivotX = cx
        swoosh.pivotY = cx
        remote.pivotX = REMOTE_X / SRC * size
        remote.pivotY = REMOTE_Y / SRC * size
        render(0f)
    }

    private fun unit(v: Float): Float = max(0f, min(1f, v))

    /** Draws the scene at [ms] milliseconds. */
    private fun render(ms: Float) {
        // camera: zoom + focus point travel from the logo to the centre of the picture
        val p = CAMERA.getInterpolation(unit((ms - 600f) / 1900f))
        val s = START_ZOOM + (1f - START_ZOOM) * p
        val fx = lx + (cx - lx) * p
        val fy = ly + (cx - ly) * p
        stage.scaleX = s
        stage.scaleY = s
        stage.translationX = -(fx - cx) * s
        stage.translationY = -(fy - cx) * s

        // logo: fade in + small pulse
        logo.alpha = EASE_FADE.getInterpolation(unit(ms / 500f))
        val u = unit((ms - 150f) / 650f)
        val pulse = 1f + 0.05f * sin(PI.toFloat() * u)
        logo.scaleX = pulse
        logo.scaleY = pulse

        // swoosh: sweeps in
        val e1 = EASE_OUT.getInterpolation(unit((ms - 900f) / 1400f))
        swoosh.alpha = unit(e1 * 2f)
        swoosh.rotation = -14f * (1f - e1)
        val ss = 0.88f + 0.12f * e1
        swoosh.scaleX = ss
        swoosh.scaleY = ss

        // remote: slides in along its axis (from the lower left)
        val e2 = EASE_OUT.getInterpolation(unit((ms - 1100f) / 1500f))
        remote.alpha = unit(e2 * 1.8f)
        remote.translationX = -(1f - e2) * 0.18f * size
        remote.translationY = (1f - e2) * 0.09f * size
        val rs = 1.06f - 0.06f * e2
        remote.scaleX = rs
        remote.scaleY = rs
    }

    fun play() {
        stop()
        val a = ValueAnimator.ofFloat(0f, DURATION.toFloat())
        a.duration = DURATION
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { render(it.animatedValue as Float) }
        anim = a
        a.start()
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }
}

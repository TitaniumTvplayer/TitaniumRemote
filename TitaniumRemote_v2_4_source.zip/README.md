# Titanium Remote 2.0

Phone-side remote for the Titanium TV app (`TitaniumTV_0.3.504.wgt`).

- Pairing: the TV shows a 4-digit code + QR. Scan it (or type the code) once; the pairing is saved on both sides.
- Remote: arrows / OK / Back / Home, touchpad, play-pause, seek, CH +/-, keyboard text, IPTV source sending.
- Runs as a foreground service, so it keeps working with the screen off.
- Alexandria font, the same Titanium logo and intro as the TV app (play glyph + bars slide apart, wordmark, tagline, loader, intro sound).

Build: push to GitHub (Actions builds `app-release.apk` + `app-debug.apk`) or open in Android Studio.
The repo contains a fixed signing key (`app/titanium.jks`) so new builds install over old ones.
Protocol: see `TV_INTEGRATION_PROTOCOL.md` (v1 endpoints unchanged; added `X-Titanium-Code` pairing and `key` events).

## 2.4
- Logo and intro now identical to the TV app (TitaniumTVbeta3_507): same vector logo (outlined play | wordmark | outlined bars), same intro timeline and easing, same tagline, loader and sound. Tap skips it. "Intro sound" switch in the phone settings.
- New consistent rounded-stroke icon set; glass surfaces (same look as the TV), accent-gradient primary buttons, press feedback on every key.
- Remote: labelled shortcut row (Live / Movies / Series / Search / Settings), larger d-pad chevrons with a ring around OK, accent Play/Pause. Pairing screen with numbered steps. Bottom bar with a pill indicator. Input fields highlight on focus.
- Launcher icon = the TV app's glyph (plus a themed monochrome icon for Android 13+); notification icon is now a vector.

## 2.3
- Top row of the remote: Live, Movies, Series, Search, Settings. Live/Movies/Series press the same tabs as the TV top bar; Search opens the TV search box (needs TV app 0.3.507).

## 2.2
- Saved sources: keep many IPTV sources on the phone, pick any one and send it to the TV. Playlist name is optional (the TV falls back to host · user).

## 2.1
- Coloured keys row under the pad: Red = Accounts, Green = Sort, Yellow = Translate, Blue = Ask Titanium.
- The gear in the top shortcut row opens the TV app's Settings on the TV (needs TV app 0.3.505). Phone settings: gear in the header.

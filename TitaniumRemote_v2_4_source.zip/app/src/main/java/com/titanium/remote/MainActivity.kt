package com.titanium.remote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import kotlin.math.abs

private fun tr(ar: String, en: String): String = if (Hub.ar) ar else en
private fun dp(v: Int): Int = Ui.dp(v)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var pageHost: FrameLayout
    private val pages = ArrayList<View>()
    private val tabs = ArrayList<LinearLayout>()
    private var tab = 0

    private lateinit var chipDot: View
    private lateinit var chipText: TextView
    private lateinit var pairPanel: View
    private lateinit var remotePanel: View
    private lateinit var pairStatus: TextView
    private lateinit var pairIp: TextView
    private lateinit var codeBox: EditText
    private lateinit var padFrame: View
    private lateinit var touchFrame: View
    private lateinit var segPad: TextView
    private lateinit var segTouch: TextView
    private var settingCode = false

    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hub.init(this)
        Ui.init(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = insetsOf(ins)
            v.setPadding(0, i[0], 0, i[1])
            ins
        }
        setContentView(root)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildHeader())
        pageHost = FrameLayout(this)
        col.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
        pages.add(buildRemotePage())
        pages.add(buildSourcePage())
        pages.add(buildKeyboardPage())
        for (p in pages) pageHost.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildNav())
        selectTab(0)

        startRemoteService()
        handleIntent(intent)
        showSplash()
        root.requestApplyInsets()
    }

    @Suppress("DEPRECATION")
    private fun insetsOf(ins: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            intArrayOf(i.top, i.bottom)
        } else {
            intArrayOf(ins.systemWindowInsetTop, ins.systemWindowInsetBottom)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Hub.onChange = { refresh() }
        startRemoteService()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        Hub.onChange = null
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startRemoteService() {
        try {
            startForegroundService(Intent(this, RemoteService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "titanium") {
            val c = d.getQueryParameter("c") ?: return
            handleCode(c)
        }
    }

    // ------------------------------------------------------------------ splash (the same intro as the TV app)
    private var introPlayer: MediaPlayer? = null

    private fun playIntroSound() {
        if (!Hub.introSound()) return
        try {
            val mp = MediaPlayer.create(this, R.raw.intro_snd) ?: return
            mp.setVolume(0.9f, 0.9f)
            mp.setOnCompletionListener {
                try { it.release() } catch (_: Exception) {}
                if (introPlayer === it) introPlayer = null
            }
            introPlayer = mp
            mp.start()
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try { introPlayer?.release() } catch (_: Exception) {}
        introPlayer = null
        super.onDestroy()
    }

    /**
     * Same sequence as the TV intro: black screen, the play glyph + bars start together, pulse, slide apart while the
     * wordmark fades in, then the tagline and the spinning loader. A tap skips it (any key skips on the TV).
     */
    private fun showSplash() {
        if (Hub.splashDone) return
        Hub.splashDone = true
        val sp = FrameLayout(this)
        sp.setBackgroundColor(Color.BLACK)
        sp.isClickable = true

        val dm = resources.displayMetrics
        val wordH = (dm.widthPixels * 0.82f / TitaniumLogo.RATIO).toInt()
        val logo = TitaniumLogo(this, wordH)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(logo, LinearLayout.LayoutParams(logo.logoWidth, wordH))

        val tag = TextView(this)
        tag.text = "بلايـر كل العيـله"
        tag.typeface = Ui.f7
        tag.setTextColor(Color.parseColor("#F1F4F9"))
        tag.setTextSize(TypedValue.COMPLEX_UNIT_PX, wordH * 0.23f)
        tag.gravity = Gravity.CENTER
        tag.alpha = 0.004f
        tag.translationY = wordH * 0.05f
        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = (wordH * 0.34f).toInt()
        box.addView(tag, tl)
        sp.addView(box, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val spin = ImageView(this)
        spin.setImageResource(R.drawable.logo_spinner)
        spin.alpha = 0f
        val sl = FrameLayout.LayoutParams(dp(34), dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        sl.bottomMargin = (dm.heightPixels * 0.13f).toInt()
        sp.addView(spin, sl)
        root.addView(sp, FrameLayout.LayoutParams(MATCH, MATCH))

        // tagline: 1.7 s, 0.5 s ease-out, rises 8 px
        tag.animate().alpha(1f).translationY(0f).setStartDelay(1700).setDuration(500)
            .setInterpolator(PathInterpolator(0f, 0f, 0.58f, 1f)).start()
        // loader: fades in at 1.5 s, spins every 3.4 s, soft pulse
        spin.animate().alpha(0.95f).setStartDelay(1500).setDuration(500).start()
        val rot = ObjectAnimator.ofFloat(spin, "rotation", 0f, 360f)
        rot.duration = 3400
        rot.interpolator = LinearInterpolator()
        rot.repeatCount = ValueAnimator.INFINITE
        rot.start()
        val pulse = ValueAnimator.ofFloat(0.84f, 1.04f)
        pulse.duration = 850
        pulse.repeatMode = ValueAnimator.REVERSE
        pulse.repeatCount = ValueAnimator.INFINITE
        pulse.interpolator = AccelerateDecelerateInterpolator()
        pulse.addUpdateListener {
            val v = it.animatedValue as Float
            spin.scaleX = v
            spin.scaleY = v
        }
        pulse.start()

        sp.post { logo.playIntro() }
        playIntroSound()

        var finished = false
        val finish = object : Runnable {
            override fun run() {
                if (finished) return
                finished = true
                ui.removeCallbacks(this)
                rot.cancel()
                pulse.cancel()
                logo.stop()
                sp.animate().alpha(0f).setDuration(160).withEndAction {
                    root.removeView(sp)
                    askNotificationPermission()
                }.start()
            }
        }
        sp.setOnClickListener { finish.run() }
        ui.postDelayed(finish, 3300)
    }

    private fun askNotificationPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ header + navigation
    private fun buildHeader(): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(20), dp(14), dp(20), dp(10))

        val logo = TitaniumLogo(this, dp(24))
        logo.showFinal()
        h.addView(logo, LinearLayout.LayoutParams(logo.logoWidth, dp(24)))

        val sp = View(this)
        h.addView(sp, LinearLayout.LayoutParams(0, 1, 1f))

        val chip = LinearLayout(this)
        chip.orientation = LinearLayout.HORIZONTAL
        chip.gravity = Gravity.CENTER_VERTICAL
        chip.setPadding(dp(14), dp(7), dp(14), dp(7))
        chip.background = Ui.glass(20)
        chipDot = View(this)
        chipDot.background = Ui.oval(Ui.MUTED)
        val dl = LinearLayout.LayoutParams(dp(9), dp(9))
        dl.marginEnd = dp(8)
        chip.addView(chipDot, dl)
        chipText = Ui.text(this, "", 12f, Ui.TEXT, 5)
        chip.addView(chipText)
        h.addView(chip)

        val gear = Ui.roundBtn(this, R.drawable.ic_gear, 40, 20)
        val gl = LinearLayout.LayoutParams(dp(40), dp(40))
        gl.marginStart = dp(10)
        gear.layoutParams = gl
        gear.setOnClickListener { openSettingsDialog() }
        h.addView(gear)
        return h
    }

    private fun openSettingsDialog() {
        val box = vbox()
        box.setPadding(dp(24), dp(4), dp(24), dp(4))

        box.addView(Ui.text(this, tr("الإعدادات", "Settings"), 18f, Ui.TEXT, 7))
        box.addView(gap(16))

        box.addView(Ui.text(this, tr("هذا الجهاز", "This device"), 12f, Ui.MUTED, 5))
        box.addView(Ui.text(this, Hub.deviceName(), 15f, Ui.TEXT, 5))
        box.addView(gap(14))

        box.addView(Ui.text(this, tr("عنوان IP والمنفذ", "IP address & port"), 12f, Ui.MUTED, 5))
        val ipRow = Ui.text(this, "${Hub.localIp()}:${Hub.PORT}", 15f, Ui.TEXT, 5)
        ipRow.textDirection = View.TEXT_DIRECTION_LTR
        box.addView(ipRow)
        box.addView(gap(14))

        box.addView(Ui.text(this, tr("حالة الربط", "Pairing status"), 12f, Ui.MUTED, 5))
        box.addView(Ui.text(this, if (Hub.isPaired()) tr("مرتبط بتلفزيون", "Paired with a TV") else tr("غير مرتبط", "Not paired"), 15f, Ui.TEXT, 5))
        box.addView(gap(18))
        box.addView(soundRow())
        box.addView(gap(20))

        if (Hub.isPaired()) {
            val unpair = Ui.pill(this, tr("إلغاء الربط", "Unpair TV"), Color.TRANSPARENT, Ui.RED, R.drawable.ic_tv, Ui.BORDER) {}
            box.addView(unpair, LinearLayout.LayoutParams(MATCH, WRAP))
            box.addView(gap(10))
            unpair.setOnClickListener {
                confirmUnpair()
            }
        }

        val dlg = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setView(scrollPage(box))
            .setNegativeButton(tr("تم", "Done"), null)
            .create()
        dlg.window?.setBackgroundDrawable(Ui.rect(Ui.CARD, 24, 1, Ui.BORDER))
        dlg.show()
    }

    /** "Intro sound" switch (the intro plays the same sound as the TV's). */
    private fun soundRow(): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, tr("صوت الانترو", "Intro sound"), 15f, Ui.TEXT, 5), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = android.widget.Switch(this)
        sw.isChecked = Hub.introSound()
        val on = intArrayOf(android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Ui.ACCENT, Ui.MUTED))
        sw.trackTintList = ColorStateList(arrayOf(on, intArrayOf()), intArrayOf(Color.argb(90, 110, 168, 255), Color.argb(60, 255, 255, 255)))
        sw.setOnCheckedChangeListener { _, v -> Hub.setIntroSound(v) }
        r.addView(sw)
        return r
    }

    private fun buildNav(): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setBackgroundColor(Color.parseColor("#0C0F14"))
        val hair = View(this)
        hair.setBackgroundColor(Ui.HAIR)
        wrap.addView(hair, LinearLayout.LayoutParams(MATCH, 1))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setPadding(dp(8), dp(6), dp(8), dp(6))
        wrap.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        val items = listOf(
            Pair(R.drawable.ic_remote, tr("الريموت", "Remote")),
            Pair(R.drawable.ic_list, tr("المصدر", "Source")),
            Pair(R.drawable.ic_keyboard, tr("الكيبورد", "Keyboard"))
        )
        for ((idx, item) in items.withIndex()) {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(4), 0, dp(4))
            val pill = FrameLayout(this)
            val ic = Ui.icon(this, item.first, 22, Ui.MUTED)
            pill.addView(ic, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            t.addView(pill, LinearLayout.LayoutParams(dp(58), dp(30)))
            val lbl = Ui.text(this, item.second, 11f, Ui.MUTED, 5)
            val ll = LinearLayout.LayoutParams(WRAP, WRAP)
            ll.topMargin = dp(3)
            t.addView(lbl, ll)
            t.setOnClickListener { selectTab(idx) }
            Ui.pressable(t)
            tabs.add(t)
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return wrap
    }

    private fun selectTab(i: Int) {
        tab = i
        for ((idx, p) in pages.withIndex()) p.visibility = if (idx == i) View.VISIBLE else View.GONE
        for ((idx, t) in tabs.withIndex()) {
            val on = idx == i
            val pill = t.getChildAt(0) as FrameLayout
            (pill.getChildAt(0) as ImageView).setColorFilter(if (on) Ui.ACCENT else Ui.MUTED)
            pill.background = if (on) Ui.rect(Color.argb(46, 110, 168, 255), 15) else null
            (t.getChildAt(1) as TextView).setTextColor(if (on) Ui.TEXT else Ui.MUTED)
        }
        hideKeyboard()
    }

    private fun scrollPage(content: View): ScrollView {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(8), dp(20), dp(24))
        return l
    }

    private fun field(hint: String, type: Int): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        e.typeface = Ui.f4
        e.textSize = 15f
        val focused = Ui.glass(14, true)
        focused.setStroke(dp(1), Ui.ACCENT)
        val states = StateListDrawable()
        states.addState(intArrayOf(android.R.attr.state_focused), focused)
        states.addState(intArrayOf(), Ui.glass(14))
        e.background = states
        e.setPadding(dp(16), dp(14), dp(16), dp(14))
        return e
    }

    private fun gap(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    // ------------------------------------------------------------------ remote page
    private fun buildRemotePage(): View {
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        pairPanel = buildPairPanel()
        remotePanel = buildRemotePanel()
        holder.addView(pairPanel)
        holder.addView(remotePanel)
        return scrollPage(holder)
    }

    private fun step(n: String, text: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val badge = Ui.text(this, n, 13f, Ui.ACCENT, 7)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.oval(Color.argb(40, 110, 168, 255), 1, Color.argb(90, 110, 168, 255))
        val bl = LinearLayout.LayoutParams(dp(30), dp(30))
        bl.marginEnd = dp(12)
        r.addView(badge, bl)
        val t = Ui.text(this, text, 14f, Ui.MUTED, 4)
        t.setLineSpacing(dp(3).toFloat(), 1f)
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    private fun buildPairPanel(): View {
        val p = vbox()
        val hero = FrameLayout(this)
        hero.background = Ui.glass(22, true)
        hero.addView(Ui.icon(this, R.drawable.ic_tv, 30, Ui.ACCENT), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        p.addView(hero, LinearLayout.LayoutParams(dp(64), dp(64)).also { it.topMargin = dp(8) })
        p.addView(Ui.text(this, tr("اربط التلفزيون", "Pair your TV"), 22f, Ui.TEXT, 7), LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(16) })

        val steps = LinearLayout(this)
        steps.orientation = LinearLayout.VERTICAL
        steps.background = Ui.glass(20)
        steps.setPadding(dp(16), dp(16), dp(16), dp(16))
        steps.addView(step(tr("١", "1"), tr("على التلفزيون افتح: الإعدادات ← ريموت الهاتف.", "On the TV open: Settings → Phone remote.")))
        steps.addView(step(tr("٢", "2"), tr("هيظهر QR وكود من ٤ أرقام.", "A QR and a 4-digit code appear.")), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) })
        steps.addView(step(tr("٣", "3"), tr("امسح الـ QR أو اكتب الكود هنا. الربط بيتحفظ ومش هتكرره تاني.", "Scan the QR or type the code here. The pairing is saved — you won't repeat it.")), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(14) })
        p.addView(steps, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(18) })

        val scan = Ui.pill(this, tr("مسح QR من التلفزيون", "Scan the QR on the TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_qr) { scanQr() }
        val sl = LinearLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = dp(22)
        p.addView(scan, sl)

        val orRow = LinearLayout(this)
        orRow.orientation = LinearLayout.HORIZONTAL
        orRow.gravity = Gravity.CENTER_VERTICAL
        val l1 = View(this)
        l1.setBackgroundColor(Ui.HAIR)
        val l2 = View(this)
        l2.setBackgroundColor(Ui.HAIR)
        orRow.addView(l1, LinearLayout.LayoutParams(0, 1, 1f))
        val orLbl = Ui.text(this, tr("أو اكتب الكود", "or type the code"), 13f, Ui.MUTED, 5)
        orRow.addView(orLbl, LinearLayout.LayoutParams(WRAP, WRAP).also { it.setMargins(dp(12), 0, dp(12), 0) })
        orRow.addView(l2, LinearLayout.LayoutParams(0, 1, 1f))
        p.addView(orRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(20) })

        codeBox = field("0000", InputType.TYPE_CLASS_NUMBER)
        codeBox.gravity = Gravity.CENTER
        codeBox.textSize = 34f
        codeBox.typeface = Ui.f7
        codeBox.letterSpacing = 0.4f
        codeBox.textDirection = View.TEXT_DIRECTION_LTR
        codeBox.filters = arrayOf(InputFilter.LengthFilter(4))
        codeBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (settingCode) return
                val v = s?.toString() ?: ""
                if (v.length == 4) handleCode(v)
                else if (Hub.pendingCode != null) Hub.disarm()
            }
        })
        val cl = LinearLayout.LayoutParams(MATCH, WRAP)
        cl.topMargin = dp(10)
        p.addView(codeBox, cl)

        pairStatus = Ui.text(this, "", 13f, Ui.AMBER, 5)
        pairStatus.gravity = Gravity.CENTER
        pairStatus.setLineSpacing(dp(3).toFloat(), 1f)
        val pl = LinearLayout.LayoutParams(MATCH, WRAP)
        pl.topMargin = dp(16)
        p.addView(pairStatus, pl)

        pairIp = Ui.text(this, "", 12f, Ui.MUTED, 4)
        pairIp.gravity = Gravity.CENTER
        pairIp.textDirection = View.TEXT_DIRECTION_LTR
        val il = LinearLayout.LayoutParams(MATCH, WRAP)
        il.topMargin = dp(28)
        p.addView(pairIp, il)
        return p
    }

    private fun key(k: String, action: String = "press", rep: Boolean = false) {
        if (!Hub.isPaired()) {
            toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            return
        }
        Hub.send(JSONObject().put("type", "key").put("key", k).put("action", action).put("rep", rep))
    }

    private fun spaced(v: View, m: Int = 9): View {
        val lp = v.layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(m), dp(m), dp(m), dp(m))
        v.layoutParams = lp
        return v
    }

    private fun row(vararg vs: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        for (v in vs) r.addView(v)
        return r
    }

    private fun keyBtn(res: Int, k: String, size: Int = 60, iconDp: Int = 26): FrameLayout {
        val b = Ui.roundBtn(this, res, size, iconDp)
        Ui.holdRepeat(b, false) { rep -> key(k, "press", rep) }
        return b
    }

    /** Coloured remote key (Red / Green / Yellow / Blue) that sends the matching key to the TV. */
    private fun colorKey(label: String, k: String, bg: Int, fg: Int): TextView {
        val t = Ui.text(this, label, 11.5f, fg, 7)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.setLineSpacing(0f, 0.95f)
        t.setPadding(dp(4), dp(4), dp(4), dp(4))
        t.background = Ui.ripple(Ui.keyRect(bg, 16), Ui.rect(Color.WHITE, 16))
        val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        t.layoutParams = lp
        Ui.holdRepeat(t, false) { rep -> key(k, "press", rep) }
        return t
    }

    private fun labelKey(label: String, k: String): TextView {
        val t = Ui.labelBtn(this, label)
        t.layoutParams = LinearLayout.LayoutParams(dp(84), dp(44))
        Ui.holdRepeat(t, false) { rep -> key(k, "press", rep) }
        return t
    }

    /** Round shortcut key with a small caption under it. */
    private fun shortcut(res: Int, k: String, label: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(keyBtn(res, k, 52, 24))
        val t = Ui.text(this, label, 10.5f, Ui.MUTED, 5)
        t.gravity = Gravity.CENTER
        c.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(5) })
        return c
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildRemotePanel(): View {
        val p = vbox()
        p.gravity = Gravity.CENTER_HORIZONTAL

        // top shortcuts: Live / Movies / Series direct-jump keys + Settings
        // same tabs as the TV's top bar (Live / Movies / Series) + its Search button
        val live = shortcut(R.drawable.ic_live, "live", tr("مباشر", "Live"))
        val movies = shortcut(R.drawable.ic_movie, "movies", tr("أفلام", "Movies"))
        val series = shortcut(R.drawable.ic_series, "series", tr("مسلسلات", "Series"))
        val search = shortcut(R.drawable.ic_search, "search", tr("بحث", "Search"))
        val settings = shortcut(R.drawable.ic_gear, "settings", tr("إعدادات", "Settings")) // opens the TV app's Settings on the TV screen (phone settings = gear in the header)
        val shortcuts = row(spaced(live, 3), spaced(movies, 3), spaced(series, 3), spaced(search, 3), spaced(settings, 3))
        p.addView(shortcuts, LinearLayout.LayoutParams(WRAP, WRAP))

        // pad / touchpad switch
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.glass(20)
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        segPad = Ui.text(this, tr("أسهم", "Arrows"), 13f, Ui.TEXT, 7)
        segTouch = Ui.text(this, tr("لوحة لمس", "Touchpad"), 13f, Ui.TEXT, 7)
        for (t in listOf(segPad, segTouch)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        segPad.setOnClickListener { setPadMode(false) }
        segTouch.setOnClickListener { setPadMode(true) }
        seg.addView(segPad)
        seg.addView(segTouch)
        val segL = LinearLayout.LayoutParams(WRAP, WRAP)
        segL.topMargin = dp(14)
        p.addView(seg, segL)

        // back / home / info
        val back = Ui.roundBtn(this, R.drawable.ic_back, 60, 26)
        Ui.holdKey(back, { key("back", "down") }, { key("back", "up") })
        val home = keyBtn(R.drawable.ic_home, "home")
        val info = keyBtn(R.drawable.ic_info, "info")
        val top = row(spaced(back), spaced(home), spaced(info))
        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = dp(14)
        p.addView(top, tl)

        // pad area
        val area = FrameLayout(this)
        padFrame = buildDpad()
        touchFrame = buildTouchpad()
        area.addView(padFrame, FrameLayout.LayoutParams(dp(280), dp(280), Gravity.CENTER))
        area.addView(touchFrame, FrameLayout.LayoutParams(dp(280), dp(280), Gravity.CENTER))
        val al = LinearLayout.LayoutParams(MATCH, dp(292))
        al.topMargin = dp(8)
        p.addView(area, al)

        // coloured keys: Red = accounts, Green = sort, Yellow = translate, Blue = Ask Titanium (same order as a TV remote)
        val colors = LinearLayout(this)
        colors.orientation = LinearLayout.HORIZONTAL
        colors.layoutDirection = View.LAYOUT_DIRECTION_LTR
        colors.addView(colorKey(tr("الحسابات", "Accounts"), "red", Color.parseColor("#E5484D"), Color.WHITE))
        colors.addView(colorKey(tr("ترتيب", "Sort"), "green", Color.parseColor("#2FBF71"), Color.parseColor("#06210F")))
        colors.addView(colorKey(tr("ترجمة", "Translate"), "yellow", Color.parseColor("#FFC21A"), Color.parseColor("#2A1E00")))
        colors.addView(colorKey(tr("اسأل تيتانيوم", "Ask Titanium"), "blue", Color.parseColor("#2B6FF0"), Color.WHITE))
        val cl2 = LinearLayout.LayoutParams(MATCH, WRAP)
        cl2.topMargin = dp(6)
        p.addView(colors, cl2)

        // media
        val pp = Ui.roundBtn(this, R.drawable.ic_play_pause, 72, 30, Ui.ACCENT_DEEP, Color.WHITE)
        Ui.holdRepeat(pp, false) { rep -> key("play_pause", "press", rep) }
        val media = row(spaced(keyBtn(R.drawable.ic_rw, "rw")), spaced(pp), spaced(keyBtn(R.drawable.ic_ff, "ff")))
        val ml = LinearLayout.LayoutParams(WRAP, WRAP)
        ml.topMargin = dp(8)
        p.addView(media, ml)

        val ch = row(spaced(labelKey("CH −", "ch_down"), 6), spaced(labelKey("CH +", "ch_up"), 6))
        p.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP))

        val unpair = Ui.pill(this, tr("إلغاء الربط", "Unpair TV"), Color.TRANSPARENT, Ui.RED, R.drawable.ic_tv, Ui.BORDER) { confirmUnpair() }
        val ul = LinearLayout.LayoutParams(WRAP, WRAP)
        ul.topMargin = dp(18)
        p.addView(unpair, ul)

        setPadMode(false)
        return p
    }

    private fun setPadMode(touch: Boolean) {
        padFrame.visibility = if (touch) View.GONE else View.VISIBLE
        touchFrame.visibility = if (touch) View.VISIBLE else View.GONE
        segPad.background = if (touch) null else Ui.accentRect(17)
        segTouch.background = if (touch) Ui.accentRect(17) else null
        segPad.setTextColor(if (touch) Ui.MUTED else Color.WHITE)
        segTouch.setTextColor(if (touch) Color.WHITE else Ui.MUTED)
    }

    private fun buildDpad(): View {
        val f = FrameLayout(this)
        f.background = Ui.glassOval()
        fun arrow(res: Int, dir: String, g: Int) {
            val v = ImageView(this)
            v.setImageResource(res)
            v.setColorFilter(Ui.TEXT)
            v.setPadding(dp(24), dp(24), dp(24), dp(24))
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.TRANSPARENT)
            val mask = GradientDrawable()
            mask.shape = GradientDrawable.OVAL
            mask.setColor(Color.WHITE)
            v.background = Ui.ripple(bg, mask)
            Ui.holdRepeat(v, true) { rep -> key(dir, "press", rep) }
            val lp = FrameLayout.LayoutParams(dp(86), dp(86), g)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            f.addView(v, lp)
        }
        arrow(R.drawable.ic_up, "up", Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        arrow(R.drawable.ic_down, "down", Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        arrow(R.drawable.ic_left, "left", Gravity.LEFT or Gravity.CENTER_VERTICAL)
        arrow(R.drawable.ic_right, "right", Gravity.RIGHT or Gravity.CENTER_VERTICAL)

        val ring = View(this)
        ring.background = Ui.oval(Color.TRANSPARENT, 1, Ui.HAIR)
        f.addView(ring, FrameLayout.LayoutParams(dp(124), dp(124), Gravity.CENTER))
        val ok = FrameLayout(this)
        ok.background = Ui.ripple(Ui.accentOval(), Ui.oval(Color.WHITE))
        val okText = Ui.text(this, "OK", 22f, Color.WHITE, 7)
        ok.addView(okText, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        Ui.holdKey(ok, { key("enter", "down") }, { key("enter", "up") })
        f.addView(ok, FrameLayout.LayoutParams(dp(104), dp(104), Gravity.CENTER))
        return f
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildTouchpad(): View {
        val f = FrameLayout(this)
        f.background = Ui.glass(28)
        val hint = Ui.text(
            this,
            tr("مرّر للتنقل\nاضغط = OK", "Swipe to move\nTap = OK"), 14f, Ui.MUTED, 5
        )
        hint.gravity = Gravity.CENTER
        f.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        var sx = 0f
        var sy = 0f
        var moved = false
        var downAt = 0L
        val step = dp(46).toFloat()
        f.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.x
                    sy = ev.y
                    moved = false
                    downAt = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - sx
                    val dy = ev.y - sy
                    if (abs(dx) > step || abs(dy) > step) {
                        val k = if (abs(dx) > abs(dy)) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
                        key(k)
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        sx = ev.x
                        sy = ev.y
                        moved = true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downAt < 350) {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        key("enter")
                    }
                }
            }
            true
        }
        return f
    }

    private fun confirmUnpair() {
        AlertDialog.Builder(this)
            .setTitle(tr("إلغاء الربط؟", "Unpair the TV?"))
            .setMessage(tr("هتحتاج تربط التلفزيون من جديد بكود.", "You will need to pair again with a code."))
            .setPositiveButton(tr("إلغاء الربط", "Unpair")) { _, _ -> Hub.forgetAll() }
            .setNegativeButton(tr("رجوع", "Cancel"), null)
            .show()
    }

    // ------------------------------------------------------------------ pairing
    private fun scanQr() {
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(this, opts).startScan()
                .addOnSuccessListener { code ->
                    val m = Regex("(\\d{4})").find(code.rawValue ?: "")
                    if (m != null) handleCode(m.groupValues[1])
                    else toast(tr("الـ QR ده مش من التلفزيون", "That QR is not from the TV"))
                }
                .addOnFailureListener {
                    toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
                }
        } catch (_: Exception) {
            toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
        }
    }

    private fun handleCode(code: String) {
        if (code.length != 4 || !code.all { it.isDigit() }) return
        Hub.armCode(code)
        settingCode = true
        codeBox.setText(code)
        codeBox.setSelection(codeBox.text.length)
        settingCode = false
        hideKeyboard()
        selectTab(0)
        refresh()
    }

    // ------------------------------------------------------------------ IPTV source page
    private fun buildSourcePage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("مصادر IPTV", "IPTV sources"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("احفظ أكتر من مصدر على الموبايل، وبعدين اختار أي واحد وابعته للتلفزيون. هتراجعه على التلفزيون وتضغط موافق.", "Save as many sources as you like on the phone, then pick any one and send it to the TV. You confirm on the TV."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        val hl = LinearLayout.LayoutParams(WRAP, WRAP)
        hl.topMargin = dp(8)
        p.addView(hint, hl)

        // ---- saved list ----
        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        p.addView(listBox, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(16) })

        // ---- add / edit form ----
        val formTitle = Ui.text(this, tr("إضافة مصدر", "Add a source"), 16f, Ui.TEXT, 7)
        p.addView(formTitle, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(26) })

        var xtream = true
        var editId: String? = null
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.glass(20)
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        val sx = Ui.text(this, "Xtream Codes", 13f, Ui.TEXT, 7)
        val sm = Ui.text(this, "M3U", 13f, Ui.TEXT, 7)
        for (t in listOf(sx, sm)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        seg.addView(sx)
        seg.addView(sm)
        p.addView(seg, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(12) })

        val name = field(tr("اسم القائمة (اختياري)", "Playlist name (optional)"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        name.filters = arrayOf(InputFilter.LengthFilter(60))
        val server = field("http://host:port", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field(tr("اسم المستخدم", "Username"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
        val pass = field(tr("كلمة المرور", "Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        val m3u = field(tr("رابط M3U كامل (http / https)", "Full M3U link (http / https)"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        for (e in listOf(name, server, user, pass, m3u)) {
            e.textDirection = View.TEXT_DIRECTION_LTR
            p.addView(e, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(12) })
        }
        fun render() {
            sx.background = if (xtream) Ui.accentRect(17) else null
            sm.background = if (xtream) null else Ui.accentRect(17)
            sx.setTextColor(if (xtream) Color.WHITE else Ui.MUTED)
            sm.setTextColor(if (xtream) Ui.MUTED else Color.WHITE)
            val xv = if (xtream) View.VISIBLE else View.GONE
            server.visibility = xv
            user.visibility = xv
            pass.visibility = xv
            m3u.visibility = if (xtream) View.GONE else View.VISIBLE
        }
        sx.setOnClickListener { xtream = true; render() }
        sm.setOnClickListener { xtream = false; render() }
        render()

        var refreshList: () -> Unit = {}
        val cancel = Ui.text(this, tr("إلغاء التعديل", "Cancel editing"), 13f, Ui.ACCENT, 7)
        cancel.setPadding(dp(4), dp(10), dp(4), dp(10))
        cancel.visibility = View.GONE

        fun resetForm() {
            editId = null
            for (e in listOf(name, server, user, pass, m3u)) e.text.clear()
            formTitle.text = tr("إضافة مصدر", "Add a source")
            cancel.visibility = View.GONE
        }
        cancel.setOnClickListener { resetForm(); hideKeyboard() }

        /** Validates the form and returns the source, or null (after showing why). */
        fun readForm(): Hub.Src? {
            val nm = name.text.toString().trim()
            val id = editId ?: Hub.newSourceId()
            if (xtream) {
                val srv = server.text.toString().trim()
                val usr = user.text.toString().trim()
                val pwd = pass.text.toString()
                if (srv.isEmpty() || usr.isEmpty() || pwd.isEmpty()) {
                    toast(tr("اكتب السيرفر واسم المستخدم وكلمة المرور", "Enter server, username and password"))
                    return null
                }
                return Hub.Src(id, nm, true, srv, usr, pwd, "")
            }
            val url = m3u.text.toString().trim()
            if (!Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(url) || url.length > 2000) {
                toast(tr("اكتب رابط M3U كامل", "Enter a complete M3U link"))
                return null
            }
            return Hub.Src(id, nm, false, "", "", "", url)
        }

        fun sendSource(s: Hub.Src) {
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else {
                Hub.send(Hub.sourceEvent(s))
                toast(tr("اتبعت للتلفزيون — افتح «إضافة مصدر» عليه", "Sent — open “Add source” on the TV"))
            }
        }

        val saveBtn = Ui.pill(this, tr("حفظ", "Save"), Ui.SURF, Ui.TEXT, 0, Ui.BORDER) {
            val s = readForm()
            if (s != null) {
                Hub.saveSource(s)
                resetForm()
                hideKeyboard()
                refreshList()
                toast(tr("تم الحفظ", "Saved"))
            }
        }
        val saveSendBtn = Ui.pill(this, tr("حفظ وإرسال للتلفزيون", "Save & send to TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) {
            val s = readForm()
            if (s != null) {
                Hub.saveSource(s)
                resetForm()
                hideKeyboard()
                refreshList()
                sendSource(s)
            }
        }
        p.addView(saveSendBtn, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(20) })
        p.addView(saveBtn, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })
        p.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(6) })

        fun startEdit(s: Hub.Src) {
            editId = s.id
            xtream = s.xtream
            name.setText(s.name)
            server.setText(s.server)
            user.setText(s.user)
            pass.setText(s.pass)
            m3u.setText(s.url)
            render()
            formTitle.text = tr("تعديل المصدر", "Edit source")
            cancel.visibility = View.VISIBLE
            name.requestFocus()
        }

        refreshList = {
            listBox.removeAllViews()
            val all = Hub.sources()
            if (all.isEmpty()) {
                val empty = Ui.text(this, tr("مفيش مصادر محفوظة لسه. أضف أول مصدر من تحت.", "No saved sources yet. Add your first one below."), 13f, Ui.MUTED, 4)
                listBox.addView(empty, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(4) })
            } else {
                listBox.addView(Ui.text(this, tr("المصادر المحفوظة", "Saved sources"), 16f, Ui.TEXT, 7))
                for (s in all) {
                    val card = LinearLayout(this)
                    card.orientation = LinearLayout.VERTICAL
                    card.background = Ui.glass(18)
                    card.setPadding(dp(16), dp(14), dp(16), dp(12))
                    val t1 = Ui.text(this, s.title(), 15f, Ui.TEXT, 7)
                    t1.maxLines = 1
                    t1.ellipsize = android.text.TextUtils.TruncateAt.END
                    t1.textDirection = View.TEXT_DIRECTION_LTR
                    val t2 = Ui.text(this, s.subtitle(), 12f, Ui.MUTED, 4)
                    t2.maxLines = 1
                    t2.ellipsize = android.text.TextUtils.TruncateAt.END
                    t2.textDirection = View.TEXT_DIRECTION_LTR
                    card.addView(t1)
                    card.addView(t2, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = dp(2) })

                    val row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    val send = Ui.pill(this, tr("ابعت للتلفزيون", "Send to TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) { sendSource(s) }
                    send.minimumHeight = dp(44)
                    row.addView(send, LinearLayout.LayoutParams(0, WRAP, 1f))
                    val edit = Ui.labelBtn(this, tr("تعديل", "Edit"))
                    edit.setPadding(dp(16), dp(11), dp(16), dp(11))
                    edit.setOnClickListener { startEdit(s) }
                    row.addView(edit, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(8) })
                    val del = Ui.labelBtn(this, tr("حذف", "Delete"))
                    del.setTextColor(Ui.RED)
                    del.setPadding(dp(16), dp(11), dp(16), dp(11))
                    del.setOnClickListener {
                        AlertDialog.Builder(this)
                            .setMessage(tr("تحذف «${s.title()}» من الموبايل؟", "Delete “${s.title()}” from this phone?"))
                            .setPositiveButton(tr("حذف", "Delete")) { _, _ ->
                                if (editId == s.id) resetForm()
                                Hub.deleteSource(s.id)
                                refreshList()
                            }
                            .setNegativeButton(tr("إلغاء", "Cancel"), null)
                            .show()
                    }
                    row.addView(del, LinearLayout.LayoutParams(WRAP, WRAP).also { it.marginStart = dp(8) })
                    card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(12) })
                    listBox.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = dp(10) })
                }
            }
        }
        refreshList()
        return scrollPage(p)
    }

    // ------------------------------------------------------------------ keyboard page
    private fun buildKeyboardPage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("الكيبورد", "Keyboard"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("افتح خانة كتابة على التلفزيون، واكتب هنا، وبعدين ابعت. النص بيتحط في الخانة المفتوحة.", "Open a text field on the TV, type here, then send. The text goes into the open field."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        val hl = LinearLayout.LayoutParams(WRAP, WRAP)
        hl.topMargin = dp(8)
        p.addView(hint, hl)

        val box = field(tr("اكتب هنا…", "Type here…"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        box.minLines = 4
        box.gravity = Gravity.TOP
        val bl = LinearLayout.LayoutParams(MATCH, WRAP)
        bl.topMargin = dp(16)
        p.addView(box, bl)

        val send = Ui.pill(this, tr("ابعت النص", "Send text"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) {
            val v = box.text.toString()
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else if (v.isBlank()) {
                toast(tr("اكتب حاجة الأول", "Type something first"))
            } else {
                Hub.send(JSONObject().put("type", "text").put("text", v))
                box.text.clear()
                toast(tr("اتبعت للتلفزيون", "Sent to the TV"))
            }
        }
        val sl = LinearLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = dp(18)
        p.addView(send, sl)
        return scrollPage(p)
    }

    // ------------------------------------------------------------------ state
    private fun refresh() {
        val paired = Hub.isPaired()
        pairPanel.visibility = if (paired) View.GONE else View.VISIBLE
        remotePanel.visibility = if (paired) View.VISIBLE else View.GONE

        val seen = System.currentTimeMillis() - Hub.lastSeen < 7000
        val err = Hub.error
        val dot: Int
        val label: String
        if (!Hub.running && err != null) {
            dot = Ui.RED
            label = tr("السيرفر واقف", "Server stopped")
        } else if (!paired) {
            dot = Ui.MUTED
            label = tr("مش مربوط", "Not paired")
        } else if (seen) {
            dot = Ui.GREEN
            label = tr("التلفزيون متصل", "TV connected")
        } else {
            dot = Ui.AMBER
            label = tr("مربوط • التلفزيون مش متصل", "Paired • TV offline")
        }
        chipDot.background = Ui.oval(dot)
        chipText.text = label

        if (!paired) {
            val c = Hub.pendingCode
            if (Hub.mismatch && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.RED)
                pairStatus.text = tr("الكود اللي على التلفزيون مختلف. اتأكد من الأرقام.", "The code on the TV is different. Check the digits.")
            } else if (c != null && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.AMBER)
                pairStatus.text = tr("بانتظار التلفزيون… سيب شاشة «ريموت الهاتف» مفتوحة عليه.", "Waiting for the TV… keep the “Phone remote” screen open on it.")
            } else {
                pairStatus.setTextColor(Ui.MUTED)
                pairStatus.text = ""
            }
            val ip = Hub.localIp()
            pairIp.text = if (ip.isEmpty()) "" else tr("عنوان الموبايل: $ip", "Phone address: $ip")
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val v = currentFocus ?: root
            im.hideSoftInputFromWindow(v.windowToken, 0)
        } catch (_: Exception) {
        }
    }
}

package com.titanium.remote

import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Titanium Remote protocol v1 (+ v2 additions): the TV is the HTTP client.
 *   GET /health  -> app / protocol / id / name / pairable
 *   GET /pair    -> X-Titanium-Token (already paired)  or  X-Titanium-Code (4 digits, first pairing -> returns a long token)
 *   GET /next    -> long-poll (up to 2.5 s) for the next event
 */
class RemoteServer {
    @Volatile private var ss: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (ss != null) return
        thread(name = "TitaniumHTTP") {
            try {
                val s = ServerSocket()
                s.reuseAddress = true
                s.bind(InetSocketAddress(Hub.PORT))
                ss = s
                Hub.running = true
                Hub.error = null
                Hub.changed()
                while (!s.isClosed) {
                    val c = s.accept()
                    pool.execute { handle(c) }
                }
            } catch (e: Exception) {
                Hub.running = false
                Hub.error = e.message
                Hub.changed()
            }
        }
    }

    fun stop() {
        try {
            ss?.close()
        } catch (_: Exception) {
        }
        ss = null
        Hub.running = false
        pool.shutdownNow()
    }

    private fun handle(socket: Socket) {
        var polled: JSONObject? = null
        socket.use { s ->
            try {
                s.soTimeout = 4000
                s.tcpNoDelay = true
                val reader = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
                val line = reader.readLine() ?: return
                val parts = line.split(" ")
                val method = parts.getOrNull(0)?.uppercase() ?: "GET"
                val full = parts.getOrNull(1) ?: "/"
                val path = full.substringBefore('?')
                var token = ""
                var code = ""
                while (true) {
                    val h = reader.readLine() ?: break
                    if (h.isEmpty()) break
                    val i = h.indexOf(':')
                    if (i <= 0) continue
                    val k = h.substring(0, i).trim().lowercase()
                    val v = h.substring(i + 1).trim()
                    if (k == "x-titanium-token") token = v
                    else if (k == "x-titanium-code") code = v
                }

                val status: Int
                val body: ByteArray
                if (method == "OPTIONS") {
                    status = 204
                    body = ByteArray(0)
                } else {
                    status = 200
                    val r: JSONObject = when {
                        method != "GET" -> JSONObject().put("error", "method_not_allowed")
                        path == "/health" -> JSONObject()
                            .put("app", "Titanium Remote").put("protocol", 1).put("v", 2).put("status", "ok")
                            .put("id", Hub.deviceId()).put("name", Hub.deviceName())
                            .put("pairable", Hub.codeActive())
                        path == "/pair" -> pair(token, code)
                        path == "/next" -> if (Hub.validToken(token)) {
                            val e = nextEvent()
                            polled = if (e.optString("type") != "none") e else null
                            e
                        } else JSONObject().put("error", "unauthorized")
                        path == "/ack" -> if (Hub.validToken(token)) JSONObject().put("ok", true)
                        else JSONObject().put("error", "unauthorized")
                        else -> JSONObject().put("error", "not_found")
                    }
                    body = r.toString().toByteArray(Charsets.UTF_8)
                }
                val reason = if (status == 204) "No Content" else "OK"
                val headers = "HTTP/1.1 $status $reason\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: X-Titanium-Token, X-Titanium-Code, Content-Type\r\n" +
                    "Access-Control-Max-Age: 600\r\n" +
                    "Cache-Control: no-store, no-cache, must-revalidate\r\n" +
                    "Pragma: no-cache\r\n" +
                    "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
                val out = s.getOutputStream()
                out.write(headers.toByteArray(Charsets.US_ASCII))
                out.write(body)
                out.flush()
                polled = null // delivered
            } catch (_: Exception) {
                // TV closed the connection: give an undelivered event back to the queue
                polled?.let { Hub.queue.offerFirst(it) }
            }
        }
    }

    private fun pair(token: String, code: String): JSONObject {
        val o = JSONObject().put("id", Hub.deviceId()).put("name", Hub.deviceName())
        if (Hub.validToken(token)) {
            Hub.lastSeen = System.currentTimeMillis()
            Hub.changed()
            return o.put("paired", true).put("token_required", true)
        }
        if (code.length == 4 && code.all { it.isDigit() }) {
            val (t, err) = Hub.tryPair(code)
            return if (t != null) o.put("paired", true).put("token", t)
            else o.put("paired", false).put("error", err)
        }
        return o.put("paired", false).put("token_required", true).put("need_code", !Hub.codeActive())
    }

    private fun nextEvent(): JSONObject {
        val deadline = System.currentTimeMillis() + 2500
        Hub.lastSeen = System.currentTimeMillis()
        while (true) {
            val wait = deadline - System.currentTimeMillis()
            if (wait <= 0) break
            val e = Hub.queue.poll(wait, TimeUnit.MILLISECONDS) ?: break
            val t = e.optLong("t", 0L)
            // a key press that waited more than 2 s (TV was away) is stale: dropping it is safer than firing it late
            if (e.optString("type") == "key" && t > 0 && System.currentTimeMillis() - t > 2000) continue
            e.remove("t")
            Hub.lastSeen = System.currentTimeMillis()
            return e
        }
        Hub.lastSeen = System.currentTimeMillis()
        return JSONObject().put("type", "none").put("lp", true)
    }
}

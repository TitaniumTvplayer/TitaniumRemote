package com.titanium.remote

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Look & feel shared with the TV app: near-black background, soft blue accent, Alexandria font. */
object Ui {
    val BG = Color.parseColor("#07080B")
    val CARD = Color.parseColor("#11151C")
    val SURF = Color.parseColor("#1A1F29")
    val BORDER = Color.parseColor("#2A303C")
    val TEXT = Color.parseColor("#F4F5F7")
    val MUTED = Color.parseColor("#9AA0AB")
    val ACCENT = Color.parseColor("#6EA8FF")
    val ACCENT_DEEP = Color.parseColor("#2B6FF0")
    val GREEN = Color.parseColor("#3DDC84")
    val AMBER = Color.parseColor("#FFBE3C")
    val RED = Color.parseColor("#FF7878")

    var f4: Typeface = Typeface.DEFAULT
    var f5: Typeface = Typeface.DEFAULT
    var f7: Typeface = Typeface.DEFAULT_BOLD
    var density = 1f

    fun init(ctx: Context) {
        density = ctx.resources.displayMetrics.density
        try {
            f4 = Typeface.createFromAsset(ctx.assets, "fonts/alexandria-400.ttf")
            f5 = Typeface.createFromAsset(ctx.assets, "fonts/alexandria-500.ttf")
            f7 = Typeface.createFromAsset(ctx.assets, "fonts/alexandria-700.ttf")
        } catch (_: Exception) {
        }
    }

    fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    fun rect(color: Int, radius: Int, strokeDp: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    fun oval(color: Int, strokeDp: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    fun ripple(bg: Drawable, mask: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), bg, mask)

    fun text(ctx: Context, s: String, size: Float, color: Int = TEXT, weight: Int = 4): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = when (weight) {
            7 -> f7
            5 -> f5
            else -> f4
        }
        return t
    }

    fun icon(ctx: Context, res: Int, sizeDp: Int, tint: Int = TEXT): ImageView {
        val v = ImageView(ctx)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    /** Rounded pill button with an optional leading icon. */
    fun pill(ctx: Context, label: String, bg: Int, fg: Int = TEXT, iconRes: Int = 0, strokeColor: Int = 0, onClick: () -> Unit): LinearLayout {
        val b = LinearLayout(ctx)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER
        b.minimumHeight = dp(52)
        b.setPadding(dp(22), dp(10), dp(22), dp(10))
        val shape = if (strokeColor != 0) rect(bg, 26, 1, strokeColor) else rect(bg, 26)
        b.background = ripple(shape, rect(Color.WHITE, 26))
        if (iconRes != 0) {
            val ic = icon(ctx, iconRes, 22, fg)
            (ic.layoutParams as LinearLayout.LayoutParams).marginEnd = dp(10)
            b.addView(ic)
        }
        b.addView(text(ctx, label, 15f, fg, 7))
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    /** Round icon button (used by the remote). */
    fun roundBtn(ctx: Context, res: Int, sizeDp: Int, iconDp: Int, bg: Int = SURF, tint: Int = TEXT): FrameLayout {
        val f = FrameLayout(ctx)
        f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        f.background = ripple(oval(bg, 1, BORDER), oval(Color.WHITE))
        val ic = ImageView(ctx)
        ic.setImageResource(res)
        ic.setColorFilter(tint)
        val lp = FrameLayout.LayoutParams(dp(iconDp), dp(iconDp))
        lp.gravity = Gravity.CENTER
        f.addView(ic, lp)
        return f
    }

    /** Text key (CH+, CH-, Info ...). */
    fun labelBtn(ctx: Context, label: String): TextView {
        val t = text(ctx, label, 14f, TEXT, 7)
        t.gravity = Gravity.CENTER
        t.background = ripple(rect(SURF, 22, 1, BORDER), rect(Color.WHITE, 22))
        return t
    }

    @SuppressLint("ClickableViewAccessibility")
    fun holdRepeat(v: View, repeat: Boolean, fire: (Boolean) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                fire(true)
                h.postDelayed(this, 110)
            }
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    fire(false)
                    if (repeat) h.postDelayed(tick, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    h.removeCallbacks(tick)
                }
            }
            true
        }
    }

    /** Press-and-hold key: sends "down" on touch and "up" on release (the TV app has long-press behaviour on OK / Back). */
    @SuppressLint("ClickableViewAccessibility")
    fun holdKey(v: View, down: () -> Unit, up: () -> Unit) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    down()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    up()
                }
            }
            true
        }
    }
}

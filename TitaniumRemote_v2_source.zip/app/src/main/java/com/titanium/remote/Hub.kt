package com.titanium.remote

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.LinkedBlockingDeque

/** Shared state between the UI, the foreground service and the HTTP server. */
object Hub {
    const val PORT = 8765
    val queue = LinkedBlockingDeque<JSONObject>()

    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val rnd = SecureRandom()

    @Volatile var running = false
    @Volatile var error: String? = null
    @Volatile var lastSeen = 0L
    @Volatile var splashDone = false
    @Volatile var mismatch = false
    @Volatile var onChange: (() -> Unit)? = null

    @Volatile var pendingCode: String? = null
    @Volatile private var pendingUntil = 0L
    @Volatile private var lockUntil = 0L
    private val tried = HashSet<String>()

    val ar: Boolean get() = Locale.getDefault().language == "ar"

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences("titanium_remote", Context.MODE_PRIVATE)
        }
    }

    private fun randomHex(bytes: Int): String {
        val b = ByteArray(bytes)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun deviceId(): String {
        var id = prefs.getString("id", null)
        if (id == null) {
            id = randomHex(8)
            prefs.edit().putString("id", id).apply()
        }
        return id
    }

    fun deviceName(): String = android.os.Build.MODEL ?: "Android"

    // ---- saved TV pairings (long random tokens, stored on the phone) ----
    private fun tokenList(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(prefs.getString("tokens", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun isPaired(): Boolean = tokenList().isNotEmpty()

    fun validToken(t: String?): Boolean = !t.isNullOrEmpty() && tokenList().contains(t)

    @Synchronized
    private fun addToken(): String {
        val t = randomHex(16)
        val l = tokenList()
        l.add(t)
        while (l.size > 5) l.removeAt(0)
        prefs.edit().putString("tokens", JSONArray(l).toString()).apply()
        return t
    }

    fun forgetAll() {
        prefs.edit().remove("tokens").apply()
        queue.clear()
        pendingCode = null
        changed()
    }

    // ---- 4-digit pairing code shown on the TV and typed / scanned on the phone ----
    fun armCode(code: String) {
        synchronized(this) {
            pendingCode = code
            pendingUntil = System.currentTimeMillis() + 5 * 60_000L
            tried.clear()
            mismatch = false
        }
        changed()
    }

    fun disarm() {
        pendingCode = null
        mismatch = false
        changed()
    }

    fun codeActive(): Boolean = pendingCode != null && System.currentTimeMillis() < pendingUntil

    /** Returns (token, "") when the TV's code matches the one entered on the phone, else (null, reason). */
    @Synchronized
    fun tryPair(code: String): Pair<String?, String> {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return Pair(null, "locked")
        if (!codeActive()) return Pair(null, "need_code")
        if (code == pendingCode) {
            pendingCode = null
            mismatch = false
            tried.clear()
            val t = addToken()
            changed()
            return Pair(t, "")
        }
        // the same wrong code retried by the TV does not count; many DIFFERENT guesses lock pairing for a minute
        val fresh = tried.add(code)
        val wasMismatch = mismatch
        mismatch = true
        if (tried.size >= 5) {
            lockUntil = now + 60_000L
            pendingCode = null
            tried.clear()
            changed()
        } else if (fresh || !wasMismatch) {
            changed()
        }
        return Pair(null, "bad_code")
    }

    fun send(e: JSONObject) {
        while (queue.size > 60) queue.poll()
        try {
            e.put("t", System.currentTimeMillis())
        } catch (_: Exception) {
        }
        queue.offer(e)
    }

    fun changed() {
        main.post { onChange?.invoke() }
    }

    fun localIp(): String {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            var fallback = ""
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ni.name.startsWith("wlan")) return ip
                        if (fallback.isEmpty()) fallback = ip
                    }
                }
            }
            if (fallback.isNotEmpty()) return fallback
        } catch (_: Exception) {
        }
        return ""
    }
}

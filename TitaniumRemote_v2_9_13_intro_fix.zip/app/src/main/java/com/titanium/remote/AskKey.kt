package com.titanium.remote

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.random.Random

/**
 * "Ask Titanium" key face: light-blue disc, the two pause bars of the Titanium logo and, above them, two dots that
 * blink like eyes (same look as the TV app's button).
 */
class AskKeyFace(ctx: Context, private val discColorValue: Int = Color.parseColor("#6B9BFF"), barColor: Int = Color.parseColor("#EEF2FF"), eyeColor: Int = Color.parseColor("#3E9BF3")) : View(ctx) {
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = discColorValue }
    private val bars = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = barColor }
    private val eyes = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = eyeColor }
    private val r = RectF()
    private val h = Handler(Looper.getMainLooper())
    private var open = 1f            // 1 = eyes open, ~0 = closed
    private var running = false

    private val blink = object : Runnable {
        override fun run() {
            if (!running) return
            // close -> open in ~200 ms, sometimes a quick double blink, then wait 2.2 - 4.8 s
            val double = Random.nextInt(4) == 0
            step(listOf(0.55f, 0.08f, 0.55f, 1f), 55L) {
                if (double) step(listOf(0.55f, 0.08f, 0.55f, 1f), 55L, null)
            }
            h.postDelayed(this, 2200L + Random.nextLong(2600L))
        }
    }

    private fun step(vals: List<Float>, gap: Long, then: (() -> Unit)?) {
        vals.forEachIndexed { i, v ->
            h.postDelayed({
                if (!running) return@postDelayed
                open = v
                invalidate()
                if (i == vals.lastIndex) then?.invoke()
            }, gap * i)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        h.postDelayed(blink, 900L)
    }

    override fun onDetachedFromWindow() {
        running = false
        h.removeCallbacksAndMessages(null)
        open = 1f
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val s = Math.min(w, height.toFloat())
        c.drawCircle(w / 2f, height / 2f, s / 2f, disc)

        val x0 = (w - s) / 2f
        val y0 = (height - s) / 2f
        // bars (lower half), centred under the eyes
        val bw = s * 0.16f
        val cx1 = x0 + s * 0.385f
        val cx2 = x0 + s * 0.615f
        val rad = s * 0.015f
        for (cx in floatArrayOf(cx1, cx2)) {
            r.set(cx - bw / 2f, y0 + s * 0.40f, cx + bw / 2f, y0 + s * 0.84f)
            c.drawRoundRect(r, rad, rad, bars)
        }
        // eyes (upper part): ovals that squash vertically when blinking
        val ew = s * 0.19f
        val eh = s * 0.19f * open
        val ecy = y0 + s * 0.27f
        for (cx in floatArrayOf(cx1, cx2)) {
            r.set(cx - ew / 2f, ecy - eh / 2f, cx + ew / 2f, ecy + eh / 2f)
            c.drawOval(r, eyes)
        }
    }
}

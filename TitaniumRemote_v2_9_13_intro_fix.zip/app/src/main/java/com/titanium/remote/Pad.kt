package com.titanium.remote

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot

/**
 * Remote layout canvas. Children are placed by their centre and diameter in a fixed design space
 * (DESIGN_W x DESIGN_H dp, taken from the user's layout sketch) and the whole thing is scaled uniformly to fit the page.
 */
class DesignCanvas(ctx: Context) : ViewGroup(ctx) {
    companion object {
        const val DESIGN_W = 360f
        const val DESIGN_H = 640f
        const val MAX_SCALE = 1.3f
    }

    private class Spec(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val specs = HashMap<View, Spec>()

    fun put(v: View, cx: Float, cy: Float, d: Float) = put(v, cx, cy, d, d)

    /** Rectangular child (pill keys): centre + width + height in design dp. */
    fun put(v: View, cx: Float, cy: Float, w: Float, h: Float) {
        specs[v] = Spec(cx, cy, w, h)
        addView(v)
    }

    /** Changes the size / place of a child that was added with put() (used when the touchpad switch changes the Arcs layout live). */
    fun update(v: View, cx: Float, cy: Float, w: Float, h: Float) {
        specs[v] = Spec(cx, cy, w, h)
        requestLayout()
    }

    private fun scale(w: Int, h: Int): Float {
        val dn = Ui.density
        return minOf(w / (DESIGN_W * dn), h / (DESIGN_H * dn), MAX_SCALE)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        val k = scale(w, h) * Ui.density
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val s = specs[c] ?: continue
            c.measure(MeasureSpec.makeMeasureSpec((s.w * k).toInt(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec((s.h * k).toInt(), MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val k = scale(w, h) * Ui.density
        val ox = (w - DESIGN_W * k) / 2f
        val oy = (h - DESIGN_H * k) / 2f
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val s = specs[c] ?: continue
            val x = (ox + s.cx * k - c.measuredWidth / 2f).toInt()
            val y = (oy + s.cy * k - c.measuredHeight / 2f).toInt()
            c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight)
        }
    }
}

/** Soft glass like the reference design: a thin light rim (a bit brighter at the top-left), a very faint gloss. */
object Glass {
    val EDGE = intArrayOf(0x70FFFFFF, 0x1CFFFFFF, 0x44FFFFFF)
    val EDGE_POS = floatArrayOf(0f, 0.55f, 1f)
    val GLOSS = intArrayOf(0x16FFFFFF, 0x06FFFFFF, 0x00FFFFFF, 0x16000000)
    val GLOSS_POS = floatArrayOf(0f, 0.32f, 0.6f, 1f)
}

/** Glass surface for the keys of the Arcs layout: base colour + soft top-to-bottom gloss + a faint highlight + a thin multicolour edge. */
class GlassDrawable(private val base: Int, private val oval: Boolean, private val radiusFrac: Float = 0.34f) : Drawable() {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = base }
    private val glossP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val specP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rf = RectF()
    private val shape = Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        val sw = Math.max(1.2f, Math.min(w, h) / 55f)
        edgeP.strokeWidth = sw
        rf.set(b.left + sw / 2f, b.top + sw / 2f, b.right - sw / 2f, b.bottom - sw / 2f)
        shape.reset()
        if (oval) shape.addOval(rf, Path.Direction.CW) else shape.addRoundRect(rf, h * radiusFrac, h * radiusFrac, Path.Direction.CW)
        glossP.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), Glass.GLOSS, Glass.GLOSS_POS, Shader.TileMode.CLAMP)
        specP.shader = RadialGradient(b.left + w * 0.3f, b.top + h * 0.2f, Math.max(w, h) * 0.6f, 0x12FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        edgeP.shader = LinearGradient(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), Glass.EDGE, Glass.EDGE_POS, Shader.TileMode.CLAMP)
    }

    override fun draw(c: Canvas) {
        if (rf.isEmpty) return
        c.drawPath(shape, fillP)
        c.drawPath(shape, glossP)
        c.drawPath(shape, specP)
        c.drawPath(shape, edgeP)
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Flat round key whose icon is a fraction of the key's own size (so it scales with the canvas). */
class DiscKey(ctx: Context, res: Int, iconFrac: Float, private val bg: Int, tint: Int, desc: String, private val corner: Float = 0.5f, private val outline: Int = 0, private val glass: Boolean = false) : FrameLayout(ctx) {
    private val frac = iconFrac
    private val icon = ImageView(ctx)

    init {
        contentDescription = desc
        background = if (glass) Ui.ripple(GlassDrawable(bg, true), Ui.oval(Color.WHITE)) else Ui.ripple(Ui.oval(bg, if (outline != 0) 2 else 0, outline), Ui.oval(Color.WHITE))
        icon.setImageResource(res)
        icon.setColorFilter(tint)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(icon, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val p = (w * (1f - frac) / 2f).toInt()
        icon.setPadding(p, p, p, p)
        if (corner < 0.5f && !glass) {   // squircle keys (left column)
            val rad = w * corner
            fun sq(c: Int) = android.graphics.drawable.GradientDrawable().also { it.setColor(c); it.cornerRadius = rad }
            background = Ui.ripple(sq(bg), sq(Color.WHITE))
        }
    }
}

/** Wide rounded key (icon + caption) used for Sort & Filter / Settings / Previous / Next / Reorder categories. The caption scales with the key. */
class PillKey(ctx: Context, res: Int, label: String, private val bg: Int, fg: Int, desc: String, private val iconAfter: Boolean = false, private val glass: Boolean = false) : LinearLayout(ctx) {
    private val icon = ImageView(ctx)
    private val caption = TextView(ctx)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        layoutDirection = LAYOUT_DIRECTION_LTR
        contentDescription = desc
        icon.setImageResource(res)
        icon.setColorFilter(fg)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        caption.text = label
        caption.setTextColor(fg)
        caption.typeface = Ui.f7
        caption.maxLines = 1
        caption.includeFontPadding = false
        if (iconAfter) { addView(caption); addView(icon) } else { addView(icon); addView(caption) }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val ic = (h * 0.46f).toInt()
        val gap = (h * 0.24f).toInt()
        val lp = LayoutParams(ic, ic)
        if (iconAfter) lp.leftMargin = gap else lp.rightMargin = gap
        icon.layoutParams = lp
        var sz = h * 0.33f
        val avail = w - ic - gap - h * 0.5f
        val pt = caption.paint
        pt.typeface = caption.typeface
        pt.textSize = sz
        while (sz > h * 0.18f && pt.measureText(caption.text.toString()) > avail) { sz *= 0.94f; pt.textSize = sz }
        caption.setTextSize(TypedValue.COMPLEX_UNIT_PX, sz)
        fun sq(c: Int) = android.graphics.drawable.GradientDrawable().also { it.setColor(c); it.cornerRadius = h * 0.34f }
        background = if (glass) Ui.ripple(GlassDrawable(bg, false, 0.34f), sq(Color.WHITE)) else Ui.ripple(sq(bg), sq(Color.WHITE))
        post { requestLayout() }   // icon / caption sizes were set after the first measure: measure again so nothing is clipped
    }
}

/** Labelled tile button (icon above, caption below) for Series / Movies / Live. Glass squircle with a tinted icon. */
class TileKey(ctx: Context, res: Int, label: String, private val bg: Int, tint: Int, desc: String, fg: Int = Color.WHITE) : LinearLayout(ctx) {
    private val icon = ImageView(ctx)
    private val caption = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        contentDescription = desc
        icon.setImageResource(res)
        icon.setColorFilter(tint)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        caption.text = label
        caption.setTextColor(fg)
        caption.typeface = Ui.f7
        caption.maxLines = 1
        caption.includeFontPadding = false
        caption.gravity = Gravity.CENTER
        addView(icon)
        addView(caption)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val ic = (h * 0.42f).toInt()
        icon.layoutParams = LayoutParams(ic, ic)
        var sz = h * 0.22f
        val pt = caption.paint
        pt.typeface = caption.typeface
        pt.textSize = sz
        while (sz > h * 0.12f && pt.measureText(caption.text.toString()) > w * 0.88f) { sz *= 0.94f; pt.textSize = sz }
        caption.setTextSize(TypedValue.COMPLEX_UNIT_PX, sz)
        (caption.layoutParams as LayoutParams).topMargin = (h * 0.06f).toInt()
        fun sq(c: Int) = android.graphics.drawable.GradientDrawable().also { it.setColor(c); it.cornerRadius = h * 0.30f }
        background = Ui.ripple(GlassDrawable(bg, false, 0.30f), sq(Color.WHITE))
        post { requestLayout() }
    }
}

/**
 * Big black ring with the dark OK disc in the middle. No arrow glyphs are drawn: the ring is split into four
 * quadrants (up / right / down / left, hold to repeat) and the centre disc is OK (press & hold sends down / up).
 * In touchpad mode the same surface is a swipe pad: swipe = arrows (a fast swipe or flick moves several steps),
 * tap = OK, press & hold = long OK. With [wide] set (classic layout) the touchpad is a larger rounded rectangle.
 */
class PadFace(ctx: Context, private val night: Boolean, private val send: (key: String, action: String, rep: Boolean) -> Unit) : View(ctx) {
    var touchMode = false
    var glass = false
    /** The view is wider than tall; arrows mode keeps its circle (diameter = shorter side) centred, touchpad mode fills the whole view. */
    var wide = false
    private val gEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gGloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gDisc = Paint(Paint.ANTI_ALIAS_FLAG)

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(if (night) "#1A1D23" else "#080B0E") }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(if (night) 130 else 70, 255, 255, 255)
    }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 255, 255, 255) }
    private val box = RectF()
    private val chev = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        color = Color.argb(120, 255, 255, 255)
    }
    private val okP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 255, 255, 255); typeface = Ui.f7; textAlign = Paint.Align.CENTER
    }
    private val chevPath = Path()
    private val tpTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 255, 255); typeface = Ui.f7; textAlign = Paint.Align.CENTER }

    private val h = Handler(Looper.getMainLooper())
    private var held: String? = null     // "up" / "down" / "left" / "right" / "enter" (arrows mode), "pad" (touchpad mode)
    private val tick = object : Runnable {
        override fun run() {
            val k = held ?: return
            if (k != "enter") send(k, "press", true)
            h.postDelayed(this, 110)
        }
    }

    // circle diameter (arrows mode, and the touchpad in square layouts) and the rounded-rectangle touchpad
    private val dia get() = minOf(width, height).toFloat()
    private val rectMode get() = touchMode && wide

    // swipe state (touch mode)
    private var sx = 0f
    private var sy = 0f
    private var ox = 0f
    private var oy = 0f
    private var maxDrift = 0f
    private var moved = false
    private var longSent = false
    private var downAt = 0L
    private var vt: VelocityTracker? = null
    private val slop get() = Ui.dp(10).toFloat()
    private val longPress = Runnable {
        if (held == "pad" && !moved && !longSent && maxDrift < slop) {
            longSent = true
            Ui.haptic(this)
            send("enter", "down", false)
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, hh, ow, oh)
        val d = minOf(w, hh).toFloat()
        disc.color = Color.parseColor(if (night) "#34373B" else "#1E2023")   // flat OK disc
        edge.strokeWidth = Math.max(1f, d / 250f)
        gEdge.strokeWidth = Math.max(1.2f, d / 110f)
        gEdge.shader = LinearGradient(0f, 0f, w.toFloat(), hh.toFloat(), Glass.EDGE, Glass.EDGE_POS, Shader.TileMode.CLAMP)
        gGloss.shader = RadialGradient(w * 0.38f, hh * 0.28f, Math.max(w, hh) * 0.7f, 0x14FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        gDisc.shader = RadialGradient(w * 0.44f, hh * 0.42f, d * 0.26f, 0x14FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    /** The pad's outline: a rounded rectangle (wide touchpad) or the circle. */
    private fun shape(c: Canvas, p: Paint, inset: Float = 0f) {
        if (rectMode) {
            box.set(inset, inset, width - inset, height - inset)
            val rad = dia * 0.17f
            c.drawRoundRect(box, rad, rad, p)
        } else {
            c.drawCircle(width / 2f, height / 2f, dia / 2f - inset, p)
        }
    }

    /** Draws [text] centred at ([x], [y]) at [size], shrinking it if it would not fit in [maxW]. */
    private fun fitText(c: Canvas, text: String, x: Float, y: Float, size: Float, maxW: Float) {
        tpTxt.textSize = size
        val w = tpTxt.measureText(text)
        if (w > maxW) tpTxt.textSize = size * maxW / w
        c.drawText(text, x, y, tpTxt)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val R = dia / 2f
        val r = R * 0.42f   // OK disc as in the reference design (the tap zone in zone() stays R / 2)
        shape(c, ring)
        if (glass) { shape(c, gGloss); shape(c, gEdge, gEdge.strokeWidth / 2f) }
        if (touchMode) {
            // touchpad: one big surface, no OK disc, no arrow hints (a tap always sends OK here); a short caption says how it works
            if (held != null) shape(c, hi)
            val maxW = (if (rectMode) width.toFloat() else dia) * 0.84f
            val big = R * 0.17f
            tpTxt.alpha = 215
            fitText(c, if (Hub.ar) "لوحة لمس" else "Touchpad", cx, cy - big * 0.5f, big, maxW)
            tpTxt.alpha = 190
            val small = R * 0.105f
            fitText(c, if (Hub.ar) "اسحب للتنقل • اضغط للاختيار" else "Swipe to move • tap to select", cx, cy + big * 0.85f, small, maxW)
            tpTxt.alpha = 160
            fitText(c, if (Hub.ar) "اضغط مطولًا = ضغطة OK مطوّلة" else "Hold = long OK press", cx, cy + big * 0.85f + small * 1.6f, small, maxW)
            tpTxt.alpha = 200
            return
        }
        // pressed quadrant highlight (arrows mode only)
        val k = held
        if (k != null && k != "enter") {
            val start = when (k) { "up" -> -135f; "right" -> -45f; "down" -> 45f; else -> 135f }
            box.set(cx - R, cy - R, cx + R, cy + R)
            c.drawArc(box, start, 90f, true, hi)
            c.drawCircle(cx, cy, r + 2f, ring)
        }
        c.drawCircle(cx, cy, r, disc)
        if (glass) c.drawCircle(cx, cy, r, gDisc)
        c.drawCircle(cx, cy, r, edge)
        if (k == "enter") c.drawCircle(cx, cy, r, hi)

        drawChevrons(c, cx, cy, R)
        okP.textSize = r * 0.62f
        c.drawText("OK", cx, cy - (okP.ascent() + okP.descent()) / 2f, okP)
    }

    /** Faint arrow hints around the ring (arrows mode only: tapping them moves, in touchpad mode a tap is OK). */
    private fun drawChevrons(c: Canvas, cx: Float, cy: Float, R: Float) {
        val dist = R * 0.76f
        val s = R * 0.075f
        chev.strokeWidth = Math.max(1.5f, R * 0.026f)
        chevPath.reset()
        chevPath.moveTo(cx - s, cy - dist + s * 0.6f)
        chevPath.lineTo(cx, cy - dist - s * 0.6f)
        chevPath.lineTo(cx + s, cy - dist + s * 0.6f)
        for (a in intArrayOf(0, 90, 180, 270)) {
            c.save()
            c.rotate(a.toFloat(), cx, cy)
            c.drawPath(chevPath, chev)
            c.restore()
        }
    }

    private fun zone(x: Float, y: Float): String {
        val dx = x - width / 2f
        val dy = y - height / 2f
        if (hypot(dx, dy) < dia / 4f) return "enter"
        val a = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))   // 0 = right, 90 = down
        return when {
            a >= -45 && a < 45 -> "right"
            a >= 45 && a < 135 -> "down"
            a >= -135 && a < -45 -> "up"
            else -> "left"
        }
    }

    private fun inside(x: Float, y: Float) = hypot(x - width / 2f, y - height / 2f) <= dia / 2f

    /** Where a touch may start: anywhere on the rectangle (wide touchpad) or inside the circle. */
    private fun hit(x: Float, y: Float) = if (rectMode) x >= 0f && x <= width && y >= 0f && y <= height else inside(x, y)

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (touchMode) return touchpad(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!inside(ev.x, ev.y)) return false
                val z = zone(ev.x, ev.y)
                held = z
                Ui.haptic(this)
                if (z == "enter") send("enter", "down", false) else {
                    send(z, "press", false)
                    h.postDelayed(tick, 380)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    private fun release() {
        val k = held
        h.removeCallbacks(tick)
        held = null
        if (k == "enter") send("enter", "up", false)
        invalidate()
    }

    /** Distance (px) the finger must travel for one arrow step. */
    private val step get() = Ui.dp(46) * dia / (252f * Ui.density)

    /** Presses [k] [n] times, the first at once and the rest 40 ms apart so the TV does not get them in one burst. */
    private fun burst(k: String, n: Int) {
        send(k, "press", false)
        for (i in 1 until n) h.postDelayed({ send(k, "press", false) }, 40L * i)
    }

    /** 1 for a normal swipe, 2 or 3 for a fast one (speed in steps per second). */
    private fun boost(speed: Float): Int {
        val sps = speed / step
        return if (sps > 14f) 3 else if (sps > 8f) 2 else 1
    }

    private fun endPad(sendUp: Boolean) {
        h.removeCallbacks(longPress)
        if (longSent && sendUp) send("enter", "up", false)
        longSent = false
        vt?.recycle(); vt = null
        held = null
        invalidate()
    }

    private fun touchpad(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!hit(ev.x, ev.y)) return false
                sx = ev.x; sy = ev.y; ox = ev.x; oy = ev.y
                moved = false; longSent = false; maxDrift = 0f
                downAt = System.currentTimeMillis()
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(ev) }
                held = "pad"
                h.removeCallbacks(longPress)
                h.postDelayed(longPress, 450)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                maxDrift = maxOf(maxDrift, hypot(ev.x - ox, ev.y - oy))
                if (longSent) return true            // a long press stays a press: no arrows while it is held
                if (maxDrift >= slop) h.removeCallbacks(longPress)
                val dx = ev.x - sx
                val dy = ev.y - sy
                val horiz = abs(dx) > abs(dy)
                val d = if (horiz) abs(dx) else abs(dy)
                if (d > step) {
                    val k = if (horiz) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
                    vt?.computeCurrentVelocity(1000)
                    val v = if (horiz) abs(vt?.xVelocity ?: 0f) else abs(vt?.yVelocity ?: 0f)
                    val n = minOf(maxOf((d / step).toInt(), 1) * boost(v), 6)
                    burst(k, n)
                    Ui.haptic(this)
                    sx = ev.x; sy = ev.y; moved = true
                }
            }
            MotionEvent.ACTION_UP -> {
                vt?.addMovement(ev)
                h.removeCallbacks(longPress)
                if (!longSent && !moved) {
                    if (maxDrift < slop) {
                        // a tap, however long it lasted (before the long-press time it is a tap; after it, the long press already fired)
                        Ui.haptic(this)
                        send("enter", "press", false)
                    } else if (System.currentTimeMillis() - downAt < 300 && maxDrift >= slop * 1.5f) {
                        // a short, quick flick that did not reach one full step: one step (more if it was very fast)
                        val dx = ev.x - ox
                        val dy = ev.y - oy
                        val horiz = abs(dx) > abs(dy)
                        val k = if (horiz) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
                        vt?.computeCurrentVelocity(1000)
                        val v = if (horiz) abs(vt?.xVelocity ?: 0f) else abs(vt?.yVelocity ?: 0f)
                        Ui.haptic(this)
                        burst(k, boost(v))
                    }
                }
                endPad(true)
            }
            MotionEvent.ACTION_CANCEL -> endPad(true)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        h.removeCallbacks(tick)
        h.removeCallbacks(longPress)
        if (longSent) send("enter", "up", false)
        longSent = false
        vt?.recycle(); vt = null
        held = null
        super.onDetachedFromWindow()
    }
}

/**
 * "Arcs" layout: four fat, bean-like curved keys around the direction pad, one on each diagonal (top-left, top-right, bottom-right, bottom-left).
 * Design space: 244 x 244 units centred on the pad (pad radius 64). Each key is a short piece of a ring (centre line radius 100, thickness 38,
 * fully rounded ends) and carries its icon and caption on ONE line that follows the curve and always reads left to right
 * (Arabic captions put the icon on the right, as in a normal RTL line).
 */
class ArcRing(ctx: Context, night: Boolean, private val rtl: Boolean, private val items: List<Arc>, private val send: (String) -> Unit) : View(ctx) {
    class Arc(val res: Int, val label: String, val tint: Int, val key: String, val bg: Int = 0, val fg: Int = Color.WHITE)

    private val mids = floatArrayOf(-135f, -45f, 45f, 135f)   // TL, TR, BR, BL (degrees, 0 = right, clockwise)
    private val RC = 100f       // centre line radius
    private val BAND = 41.04f   // thickness (+8%)
    private val SWEEP = 44f     // centre-line sweep (the round caps add the rest)
    private val baseFill = Color.parseColor(if (night) "#1C1E27" else "#14171A")
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = baseFill }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.WHITE }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(46, 255, 255, 255) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Ui.f7 }
    private val icons = items.map { a -> context.getDrawable(a.res)?.mutate()?.also { it.setTint(a.tint) } }
    private val box = RectF()
    private val path = Path()
    private val bnd = RectF()
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var pressed = -1

    /** Rounded-rectangle mode (Arcs layout + touchpad): the four keys follow a rounded rectangle around the rectangular pad instead of a circle. */
    var rect = false
        set(v) { field = v; pressed = -1; invalidate() }

    // rounded-rectangle geometry in design units; the view is 304 x 278 (pad 190 x 164 with a 28 corner, 8 gap, 46 band)
    private val RW = 126f       // centre line, half width
    private val RH = 113f       // centre line, half height
    private val RR = 59f        // centre line, corner radius
    private val RBAND = 46f     // key thickness
    private val RGAP = 80f      // centre-line gap between two keys, in the middle of each side
    private fun ru() = width / 304f

    /** Centre line of key [i] (0 TL, 1 TR, 2 BR, 3 BL) along the rounded rectangle, in reading direction (left to right). Returns the distance along it to the middle of the corner. */
    private fun rectKey(i: Int, p: Path, cx: Float, cy: Float, s: Float): Float {
        val ex = RW * s
        val ey = RH * s
        val hx = (RW - RR) * s
        val hy = (RH - RR) * s
        val r = RR * s
        val gx = RGAP / 2f * s
        val half = (Math.PI / 2.0).toFloat() * r / 2f
        p.reset()
        return when (i) {
            0 -> {
                p.moveTo(cx - ex, cy - gx); p.lineTo(cx - ex, cy - hy)
                p.arcTo(RectF(cx - hx - r, cy - hy - r, cx - hx + r, cy - hy + r), 180f, 90f)
                p.lineTo(cx - gx, cy - ey)
                (hy - gx) + half
            }
            1 -> {
                p.moveTo(cx + gx, cy - ey); p.lineTo(cx + hx, cy - ey)
                p.arcTo(RectF(cx + hx - r, cy - hy - r, cx + hx + r, cy - hy + r), 270f, 90f)
                p.lineTo(cx + ex, cy - gx)
                (hx - gx) + half
            }
            2 -> {
                p.moveTo(cx + gx, cy + ey); p.lineTo(cx + hx, cy + ey)
                p.arcTo(RectF(cx + hx - r, cy + hy - r, cx + hx + r, cy + hy + r), 90f, -90f)
                p.lineTo(cx + ex, cy + gx)
                (hx - gx) + half
            }
            else -> {
                p.moveTo(cx - ex, cy + gx); p.lineTo(cx - ex, cy + hy)
                p.arcTo(RectF(cx - hx - r, cy + hy - r, cx - hx + r, cy + hy + r), 180f, -90f)
                p.lineTo(cx - gx, cy + ey)
                (hy - gx) + half
            }
        }
    }

    private fun u() = width / 244f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        edge.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Glass.EDGE, Glass.EDGE_POS, Shader.TileMode.CLAMP)   // soft light rim
    }

    override fun onDraw(c: Canvas) {
        val rm = rect
        val k = if (rm) ru() * 1.2f else u()          // px per circle design unit (icon and caption sizes are tuned for it)
        val band = if (rm) RBAND * ru() else BAND * k
        val cx = width / 2f
        val cy = height / 2f
        val ew = Math.max(1f, k * 0.9f)
        box.set(cx - RC * k, cy - RC * k, cx + RC * k, cy + RC * k)
        for (i in items.indices) {
            val mid = mids[i]
            var dm = 0f
            if (rm) dm = rectKey(i, path, cx, cy, ru()) else { path.reset(); path.addArc(box, mid - SWEEP / 2f, SWEEP) }
            val coloured = items[i].bg != 0
            edge.strokeWidth = band + 2f * ew
            c.drawPath(path, edge)
            fill.color = if (coloured) items[i].bg else baseFill
            txt.color = items[i].fg
            fill.strokeWidth = band
            c.drawPath(path, fill)
            // glass gloss over the band: light at the top of the key, a little shade at the bottom
            path.computeBounds(bnd, true)
            gloss.strokeWidth = band
            gloss.shader = LinearGradient(0f, bnd.top - band / 2f, 0f, bnd.bottom + band / 2f, Glass.GLOSS, Glass.GLOSS_POS, Shader.TileMode.CLAMP)
            c.drawPath(path, gloss)
            if (pressed == i) { hi.strokeWidth = band; c.drawPath(path, hi) }

            // icon + caption on one line along the centre line
            val iconW = 15f * k
            val gap = 4f * k
            val label = items[i].label
            var size = 10f * k
            txt.textSize = size
            val maxLen = 80f * k
            while (size > 5f * k && iconW + gap + txt.measureText(label) > maxLen) { size -= 0.5f * k; txt.textSize = size }
            val tw = txt.measureText(label)
            val total = iconW + gap + tw
            val s0 = -total / 2f                                  // arc length (px) from the key's middle to the start of the line
            val half = iconW / 2f
            val cap = size * 0.36f

            if (rm) {
                val pm = PathMeasure(path, false)
                val iconT = dm + (if (rtl) s0 + tw + gap + iconW / 2f else s0 + iconW / 2f)
                val textT = dm + (if (rtl) s0 else s0 + iconW + gap)
                val pos = FloatArray(2)
                val tan = FloatArray(2)
                if (pm.getPosTan(iconT, pos, tan)) {
                    val rot = Math.toDegrees(atan2(tan[1].toDouble(), tan[0].toDouble())).toFloat()
                    c.save()
                    c.rotate(rot, pos[0], pos[1])
                    icons[i]?.let { d -> d.setBounds((pos[0] - half).toInt(), (pos[1] - half).toInt(), (pos[0] + half).toInt(), (pos[1] + half).toInt()); d.draw(c) }
                    c.restore()
                }
                c.drawTextOnPath(label, path, textT, cap, txt)
                continue
            }

            val top = i < 2
            val dir = if (top) 1f else -1f                      // direction of travel: clockwise on top, counter-clockwise below (always left -> right)
            val rc = RC * k
            fun ang(t: Float) = mid + dir * Math.toDegrees((t / rc).toDouble()).toFloat()

            val iconT = if (rtl) s0 + tw + gap + iconW / 2f else s0 + iconW / 2f
            val textT = if (rtl) s0 else s0 + iconW + gap
            val ia = ang(iconT)
            val iar = Math.toRadians(ia.toDouble())
            val ix = cx + cos(iar).toFloat() * rc
            val iy = cy + sin(iar).toFloat() * rc
            c.save()
            c.rotate(if (top) ia + 90f else ia - 90f, ix, iy)
            icons[i]?.let { d -> d.setBounds((ix - half).toInt(), (iy - half).toInt(), (ix + half).toInt(), (iy + half).toInt()); d.draw(c) }
            c.restore()

            // caption: baseline so that the glyphs are centred on the centre line
            val rt = if (top) rc - cap else rc + cap
            val tb = RectF(cx - rt, cy - rt, cx + rt, cy + rt)
            val tp = Path()
            tp.addArc(tb, ang(textT), dir * Math.toDegrees(((tw + 2f * k) / rt).toDouble()).toFloat())
            c.drawTextOnPath(label, tp, 0f, 0f, txt)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best = -1
                if (rect) {
                    val s = ru()
                    val dx = (ev.x - width / 2f) / s
                    val dy = (ev.y - height / 2f) / s
                    val ax = abs(dx)
                    val ay = abs(dy)
                    val hx = RW - RR
                    val hy = RH - RR
                    val corner = ax > hx && ay > hy
                    val d = if (corner) hypot(ax - hx, ay - hy) - RR else if (ax <= hx) ay - RH else ax - RW
                    if (abs(d) > RBAND / 2f + 4f) return false
                    if (!corner && (if (ax <= hx) ax else ay) < RGAP / 2f) return false   // the gap in the middle of a side
                    best = if (dy < 0) (if (dx < 0) 0 else 1) else (if (dx >= 0) 2 else 3)
                } else {
                    val k = u()
                    val dx = ev.x - width / 2f
                    val dy = ev.y - height / 2f
                    val r = hypot(dx, dy) / k
                    if (r < 72f || r > 124f) return false
                    val ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                    var bd = 999f
                    for (i in mids.indices) {
                        var d = abs(ang - mids[i]) % 360f
                        if (d > 180f) d = 360f - d
                        if (d < bd) { bd = d; best = i }
                    }
                    if (best < 0 || bd > 34f) return false
                }
                pressed = best
                Ui.haptic(this)
                send(items[best].key)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }
}

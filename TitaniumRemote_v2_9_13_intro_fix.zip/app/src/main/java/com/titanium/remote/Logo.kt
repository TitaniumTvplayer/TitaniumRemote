package com.titanium.remote

import android.animation.ValueAnimator
import android.content.Context
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * The Titanium logo, identical to the TV app's: outlined 3D play glyph | wordmark | two outlined bars.
 *
 * Geometry is taken from the TV intro (1920 px layout) and scaled by [wordH] (the height of the wordmark).
 * [showFinal] shows the finished logo (header); [playIntro] plays the TV intro timeline:
 *   0-1450 ms : play + bars start together in the middle, pulse (x1.06) and then slide apart,
 *   850-1600 ms: the wordmark fades/rises in between them.
 */
class TitaniumLogo(ctx: Context, private val wordH: Int) : FrameLayout(ctx) {
    companion object {
        // layout in TV pixels, relative to the logo's left/top (word height 156.8)
        private const val TV_W = 837.6f
        private const val TV_H = 156.8f
        private const val PAD = 3.09f            // half the stroke, so the outline is not clipped
        private const val SLIDE = 311.4f         // how far play / bars travel from the joined start position
        const val RATIO = TV_W / TV_H            // width / word-height

        val EASE_OUT = PathInterpolator(0.22f, 0.8f, 0.24f, 1f)
        private val EASE_START = PathInterpolator(0.3f, 0.7f, 0.3f, 1f)
        private val EASE_IO = PathInterpolator(0.42f, 0f, 0.58f, 1f)
    }

    private val k = wordH / TV_H
    private val glyph = FrameLayout(ctx)
    private val play = ImageView(ctx)
    private val cubes = ImageView(ctx)
    private val word = ImageView(ctx)
    private var anim: ValueAnimator? = null

    val logoWidth: Int = (TV_W * k).toInt()

    init {
        clipChildren = false
        clipToPadding = false
        glyph.clipChildren = false
        glyph.clipToPadding = false

        play.setImageResource(R.drawable.logo_play)
        play.scaleType = ImageView.ScaleType.FIT_XY
        cubes.setImageResource(R.drawable.logo_cubes)
        cubes.scaleType = ImageView.ScaleType.FIT_XY
        word.setImageResource(R.drawable.logo_word)
        word.scaleType = ImageView.ScaleType.FIT_XY

        place(play, 0f - PAD, 16.6f - PAD, 114.2f + 2 * PAD, 123.5f + 2 * PAD)
        place(cubes, 741.9f - PAD, 13.5f - PAD, 95.7f + 2 * PAD, 135.9f + 2 * PAD)
        glyph.addView(play)
        glyph.addView(cubes)
        addView(glyph, LayoutParams(logoWidth, wordH))

        val wl = LayoutParams((552.8f * k).toInt(), wordH)
        wl.leftMargin = (151.1f * k).toInt()
        addView(word, wl)

    }

    private fun place(v: View, x: Float, y: Float, w: Float, h: Float) {
        val lp = LayoutParams((w * k).toInt(), (h * k).toInt())
        lp.leftMargin = (x * k).toInt()
        lp.topMargin = (y * k).toInt()
        v.layoutParams = lp
    }

    /** Finished logo, no animation. */
    fun showFinal() {
        stop()
        glyph.scaleX = 1f
        glyph.scaleY = 1f
        play.translationX = 0f
        cubes.translationX = 0f
        word.alpha = 1f
        word.translationY = 0f
    }

    /** The TV intro timeline. Call after the view has been laid out (or just post it). */
    fun playIntro() {
        stop()
        val slide = SLIDE * k
        visibility = View.VISIBLE
        alpha = 1f
        glyph.visibility = View.VISIBLE
        play.visibility = View.VISIBLE
        cubes.visibility = View.VISIBLE
        word.visibility = View.VISIBLE
        glyph.alpha = 1f
        play.alpha = 1f
        cubes.alpha = 1f
        word.alpha = 0.004f
        word.translationY = 10f * k
        word.animate().alpha(1f).translationY(0f).setStartDelay(850).setDuration(750)
            .setInterpolator(EASE_OUT).start()

        glyph.post {
            glyph.pivotX = glyph.width / 2f
            glyph.pivotY = glyph.height / 2f
        }
        play.translationX = slide
        cubes.translationX = -slide

        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1450
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { va ->
            val f = va.animatedFraction
            // scale: 1 -> 1.06 (0-14 %), 1.06 -> 1 (14-24 %), hold
            val s = when {
                f < 0.14f -> 1f + 0.06f * EASE_START.getInterpolation(f / 0.14f)
                f < 0.24f -> 1.06f - 0.06f * EASE_IO.getInterpolation((f - 0.14f) / 0.10f)
                else -> 1f
            }
            glyph.scaleX = s
            glyph.scaleY = s
            // slide apart: 45-100 %
            val e = if (f < 0.45f) 0f else EASE_OUT.getInterpolation((f - 0.45f) / 0.55f)
            play.translationX = slide * (1f - e)
            cubes.translationX = -slide * (1f - e)
        }
        anim = a
        a.start()
    }

    fun stop() {
        anim?.cancel()
        anim = null
        word.animate().cancel()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }
}

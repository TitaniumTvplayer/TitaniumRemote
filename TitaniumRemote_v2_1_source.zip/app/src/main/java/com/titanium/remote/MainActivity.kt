package com.titanium.remote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import kotlin.math.abs

private fun tr(ar: String, en: String): String = if (Hub.ar) ar else en
private fun dp(v: Int): Int = Ui.dp(v)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var pageHost: FrameLayout
    private val pages = ArrayList<View>()
    private val tabs = ArrayList<LinearLayout>()
    private var tab = 0

    private lateinit var chipDot: View
    private lateinit var chipText: TextView
    private lateinit var pairPanel: View
    private lateinit var remotePanel: View
    private lateinit var pairStatus: TextView
    private lateinit var pairIp: TextView
    private lateinit var codeBox: EditText
    private lateinit var padFrame: View
    private lateinit var touchFrame: View
    private lateinit var segPad: TextView
    private lateinit var segTouch: TextView
    private var settingCode = false

    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hub.init(this)
        Ui.init(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val i = insetsOf(ins)
            v.setPadding(0, i[0], 0, i[1])
            ins
        }
        setContentView(root)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildHeader())
        pageHost = FrameLayout(this)
        col.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
        pages.add(buildRemotePage())
        pages.add(buildSourcePage())
        pages.add(buildKeyboardPage())
        for (p in pages) pageHost.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(buildNav())
        selectTab(0)

        startRemoteService()
        handleIntent(intent)
        showSplash()
        root.requestApplyInsets()
    }

    @Suppress("DEPRECATION")
    private fun insetsOf(ins: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            intArrayOf(i.top, i.bottom)
        } else {
            intArrayOf(ins.systemWindowInsetTop, ins.systemWindowInsetBottom)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Hub.onChange = { refresh() }
        startRemoteService()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        Hub.onChange = null
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startRemoteService() {
        try {
            startForegroundService(Intent(this, RemoteService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "titanium") {
            val c = d.getQueryParameter("c") ?: return
            handleCode(c)
        }
    }

    // ------------------------------------------------------------------ splash (3 s intro)
    private fun showSplash() {
        if (Hub.splashDone) return
        Hub.splashDone = true
        val sp = FrameLayout(this)
        sp.setBackgroundColor(Ui.BG)
        sp.isClickable = true

        val glow = View(this)
        val gd = GradientDrawable()
        gd.gradientType = GradientDrawable.RADIAL_GRADIENT
        gd.gradientRadius = dp(230).toFloat()
        gd.colors = intArrayOf(Color.parseColor("#336EA8FF"), Color.TRANSPARENT)
        glow.background = gd
        sp.addView(glow, FrameLayout.LayoutParams(dp(460), dp(460), Gravity.CENTER))

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val glyph = ImageView(this)
        glyph.setImageResource(R.drawable.splash_glyph)
        glyph.alpha = 0f
        glyph.scaleX = 0.8f
        glyph.scaleY = 0.8f
        box.addView(glyph, LinearLayout.LayoutParams(dp(150), dp(98)))
        val word = ImageView(this)
        word.setImageResource(R.drawable.logo_word)
        word.alpha = 0f
        val wl = LinearLayout.LayoutParams(dp(220), dp(51))
        wl.topMargin = dp(26)
        box.addView(word, wl)
        val tag = Ui.text(this, tr("ريموت التلفزيون", "TV REMOTE"), 12f, Ui.MUTED, 5)
        tag.letterSpacing = 0.3f
        tag.alpha = 0f
        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = dp(14)
        box.addView(tag, tl)
        sp.addView(box, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(sp, FrameLayout.LayoutParams(MATCH, MATCH))

        glyph.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(800).setStartDelay(150).start()
        word.animate().alpha(1f).setDuration(700).setStartDelay(700).start()
        tag.animate().alpha(1f).setDuration(600).setStartDelay(1250).start()
        ui.postDelayed({
            sp.animate().alpha(0f).setDuration(450).withEndAction {
                root.removeView(sp)
                askNotificationPermission()
            }.start()
        }, 2900)
    }

    private fun askNotificationPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ header + navigation
    private fun buildHeader(): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(20), dp(14), dp(20), dp(10))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_word)
        logo.scaleType = ImageView.ScaleType.FIT_START
        h.addView(logo, LinearLayout.LayoutParams(dp(112), dp(26)))

        val sp = View(this)
        h.addView(sp, LinearLayout.LayoutParams(0, 1, 1f))

        val chip = LinearLayout(this)
        chip.orientation = LinearLayout.HORIZONTAL
        chip.gravity = Gravity.CENTER_VERTICAL
        chip.setPadding(dp(14), dp(7), dp(14), dp(7))
        chip.background = Ui.rect(Ui.SURF, 20, 1, Ui.BORDER)
        chipDot = View(this)
        chipDot.background = Ui.oval(Ui.MUTED)
        val dl = LinearLayout.LayoutParams(dp(9), dp(9))
        dl.marginEnd = dp(8)
        chip.addView(chipDot, dl)
        chipText = Ui.text(this, "", 12f, Ui.TEXT, 5)
        chip.addView(chipText)
        h.addView(chip)

        val gear = Ui.roundBtn(this, R.drawable.ic_gear, 40, 20)
        val gl = LinearLayout.LayoutParams(dp(40), dp(40))
        gl.marginStart = dp(10)
        gear.layoutParams = gl
        gear.setOnClickListener { openSettingsDialog() }
        h.addView(gear)
        return h
    }

    private fun openSettingsDialog() {
        val box = vbox()
        box.setPadding(dp(24), dp(4), dp(24), dp(4))

        box.addView(Ui.text(this, tr("الإعدادات", "Settings"), 18f, Ui.TEXT, 7))
        box.addView(gap(16))

        box.addView(Ui.text(this, tr("هذا الجهاز", "This device"), 12f, Ui.MUTED, 5))
        box.addView(Ui.text(this, Hub.deviceName(), 15f, Ui.TEXT, 5))
        box.addView(gap(14))

        box.addView(Ui.text(this, tr("عنوان IP والمنفذ", "IP address & port"), 12f, Ui.MUTED, 5))
        val ipRow = Ui.text(this, "${Hub.localIp()}:${Hub.PORT}", 15f, Ui.TEXT, 5)
        ipRow.textDirection = View.TEXT_DIRECTION_LTR
        box.addView(ipRow)
        box.addView(gap(14))

        box.addView(Ui.text(this, tr("حالة الربط", "Pairing status"), 12f, Ui.MUTED, 5))
        box.addView(Ui.text(this, if (Hub.isPaired()) tr("مرتبط بتلفزيون", "Paired with a TV") else tr("غير مرتبط", "Not paired"), 15f, Ui.TEXT, 5))
        box.addView(gap(20))

        if (Hub.isPaired()) {
            val unpair = Ui.pill(this, tr("إلغاء الربط", "Unpair TV"), Color.TRANSPARENT, Ui.RED, R.drawable.ic_tv, Ui.BORDER) {}
            box.addView(unpair, LinearLayout.LayoutParams(MATCH, WRAP))
            box.addView(gap(10))
            unpair.setOnClickListener {
                confirmUnpair()
            }
        }

        val dlg = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setView(scrollPage(box))
            .setNegativeButton(tr("تم", "Done"), null)
            .create()
        dlg.window?.setBackgroundDrawable(Ui.rect(Ui.CARD, 18, 1, Ui.BORDER))
        dlg.show()
    }

    private fun buildNav(): View {
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.background = Ui.rect(Ui.CARD, 0)
        val items = listOf(
            Pair(R.drawable.ic_remote, tr("الريموت", "Remote")),
            Pair(R.drawable.ic_list, tr("المصدر", "Source")),
            Pair(R.drawable.ic_keyboard, tr("الكيبورد", "Keyboard"))
        )
        for ((idx, item) in items.withIndex()) {
            val t = LinearLayout(this)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.addView(Ui.icon(this, item.first, 24, Ui.MUTED))
            val lbl = Ui.text(this, item.second, 11f, Ui.MUTED, 5)
            val ll = LinearLayout.LayoutParams(WRAP, WRAP)
            ll.topMargin = dp(3)
            t.addView(lbl, ll)
            t.setOnClickListener { selectTab(idx) }
            tabs.add(t)
            nav.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return nav
    }

    private fun selectTab(i: Int) {
        tab = i
        for ((idx, p) in pages.withIndex()) p.visibility = if (idx == i) View.VISIBLE else View.GONE
        for ((idx, t) in tabs.withIndex()) {
            val c = if (idx == i) Ui.ACCENT else Ui.MUTED
            (t.getChildAt(0) as ImageView).setColorFilter(c)
            (t.getChildAt(1) as TextView).setTextColor(c)
        }
        hideKeyboard()
    }

    private fun scrollPage(content: View): ScrollView {
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(8), dp(20), dp(24))
        return l
    }

    private fun field(hint: String, type: Int): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = type
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        e.typeface = Ui.f4
        e.textSize = 15f
        e.background = Ui.rect(Ui.SURF, 14, 1, Ui.BORDER)
        e.setPadding(dp(16), dp(14), dp(16), dp(14))
        return e
    }

    private fun gap(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    // ------------------------------------------------------------------ remote page
    private fun buildRemotePage(): View {
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        pairPanel = buildPairPanel()
        remotePanel = buildRemotePanel()
        holder.addView(pairPanel)
        holder.addView(remotePanel)
        return scrollPage(holder)
    }

    private fun buildPairPanel(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("اربط التلفزيون", "Pair your TV"), 22f, Ui.TEXT, 7))
        val body = Ui.text(
            this,
            tr(
                "١. على التلفزيون افتح: الإعدادات ← ريموت الهاتف.\n٢. هيظهر QR وكود من ٤ أرقام.\n٣. امسح الـ QR أو اكتب الكود هنا. الربط بيتحفظ ومش هتكرره تاني.",
                "1. On the TV open: Settings → Phone remote.\n2. A QR and a 4-digit code appear.\n3. Scan the QR or type the code here. The pairing is saved — you won't repeat it."
            ), 14f, Ui.MUTED, 4
        )
        body.setLineSpacing(dp(4).toFloat(), 1f)
        val bl = LinearLayout.LayoutParams(WRAP, WRAP)
        bl.topMargin = dp(10)
        p.addView(body, bl)

        val scan = Ui.pill(this, tr("مسح QR من التلفزيون", "Scan the QR on the TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_qr) { scanQr() }
        val sl = LinearLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = dp(24)
        p.addView(scan, sl)

        val orLbl = Ui.text(this, tr("أو اكتب الكود", "or type the code"), 13f, Ui.MUTED, 5)
        orLbl.gravity = Gravity.CENTER
        val ol = LinearLayout.LayoutParams(MATCH, WRAP)
        ol.topMargin = dp(20)
        p.addView(orLbl, ol)

        codeBox = field("0000", InputType.TYPE_CLASS_NUMBER)
        codeBox.gravity = Gravity.CENTER
        codeBox.textSize = 34f
        codeBox.typeface = Ui.f7
        codeBox.letterSpacing = 0.4f
        codeBox.textDirection = View.TEXT_DIRECTION_LTR
        codeBox.filters = arrayOf(InputFilter.LengthFilter(4))
        codeBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (settingCode) return
                val v = s?.toString() ?: ""
                if (v.length == 4) handleCode(v)
                else if (Hub.pendingCode != null) Hub.disarm()
            }
        })
        val cl = LinearLayout.LayoutParams(MATCH, WRAP)
        cl.topMargin = dp(10)
        p.addView(codeBox, cl)

        pairStatus = Ui.text(this, "", 13f, Ui.AMBER, 5)
        pairStatus.gravity = Gravity.CENTER
        pairStatus.setLineSpacing(dp(3).toFloat(), 1f)
        val pl = LinearLayout.LayoutParams(MATCH, WRAP)
        pl.topMargin = dp(16)
        p.addView(pairStatus, pl)

        pairIp = Ui.text(this, "", 12f, Ui.MUTED, 4)
        pairIp.gravity = Gravity.CENTER
        pairIp.textDirection = View.TEXT_DIRECTION_LTR
        val il = LinearLayout.LayoutParams(MATCH, WRAP)
        il.topMargin = dp(28)
        p.addView(pairIp, il)
        return p
    }

    private fun key(k: String, action: String = "press", rep: Boolean = false) {
        if (!Hub.isPaired()) {
            toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            return
        }
        Hub.send(JSONObject().put("type", "key").put("key", k).put("action", action).put("rep", rep))
    }

    private fun spaced(v: View, m: Int = 9): View {
        val lp = v.layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(m), dp(m), dp(m), dp(m))
        v.layoutParams = lp
        return v
    }

    private fun row(vararg vs: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        for (v in vs) r.addView(v)
        return r
    }

    private fun keyBtn(res: Int, k: String, size: Int = 60, iconDp: Int = 26): FrameLayout {
        val b = Ui.roundBtn(this, res, size, iconDp)
        Ui.holdRepeat(b, false) { rep -> key(k, "press", rep) }
        return b
    }

    /** Coloured remote key (Red / Green / Yellow / Blue) that sends the matching key to the TV. */
    private fun colorKey(label: String, k: String, bg: Int, fg: Int): TextView {
        val t = Ui.text(this, label, 11.5f, fg, 7)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.setLineSpacing(0f, 0.95f)
        t.setPadding(dp(4), dp(4), dp(4), dp(4))
        t.background = Ui.ripple(Ui.rect(bg, 16), Ui.rect(Color.WHITE, 16))
        val lp = LinearLayout.LayoutParams(0, dp(52), 1f)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        t.layoutParams = lp
        Ui.holdRepeat(t, false) { rep -> key(k, "press", rep) }
        return t
    }

    private fun labelKey(label: String, k: String): TextView {
        val t = Ui.labelBtn(this, label)
        t.layoutParams = LinearLayout.LayoutParams(dp(84), dp(44))
        Ui.holdRepeat(t, false) { rep -> key(k, "press", rep) }
        return t
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildRemotePanel(): View {
        val p = vbox()
        p.gravity = Gravity.CENTER_HORIZONTAL

        // top shortcuts: Live / Movies / Series direct-jump keys + Settings
        val live = keyBtn(R.drawable.ic_live, "live")
        val movies = keyBtn(R.drawable.ic_movie, "movies")
        val series = keyBtn(R.drawable.ic_series, "series")
        val settings = keyBtn(R.drawable.ic_gear, "settings") // opens the TV app's Settings on the TV screen (phone settings = gear in the header)
        val shortcuts = row(spaced(live), spaced(movies), spaced(series), spaced(settings))
        p.addView(shortcuts, LinearLayout.LayoutParams(WRAP, WRAP))

        // pad / touchpad switch
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.rect(Ui.SURF, 20, 1, Ui.BORDER)
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        segPad = Ui.text(this, tr("أسهم", "Arrows"), 13f, Ui.TEXT, 7)
        segTouch = Ui.text(this, tr("لوحة لمس", "Touchpad"), 13f, Ui.TEXT, 7)
        for (t in listOf(segPad, segTouch)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        segPad.setOnClickListener { setPadMode(false) }
        segTouch.setOnClickListener { setPadMode(true) }
        seg.addView(segPad)
        seg.addView(segTouch)
        val segL = LinearLayout.LayoutParams(WRAP, WRAP)
        segL.topMargin = dp(14)
        p.addView(seg, segL)

        // back / home / info
        val back = Ui.roundBtn(this, R.drawable.ic_back, 60, 26)
        Ui.holdKey(back, { key("back", "down") }, { key("back", "up") })
        val home = keyBtn(R.drawable.ic_home, "home")
        val info = keyBtn(R.drawable.ic_info, "info")
        val top = row(spaced(back), spaced(home), spaced(info))
        val tl = LinearLayout.LayoutParams(WRAP, WRAP)
        tl.topMargin = dp(14)
        p.addView(top, tl)

        // pad area
        val area = FrameLayout(this)
        padFrame = buildDpad()
        touchFrame = buildTouchpad()
        area.addView(padFrame, FrameLayout.LayoutParams(dp(280), dp(280), Gravity.CENTER))
        area.addView(touchFrame, FrameLayout.LayoutParams(dp(280), dp(280), Gravity.CENTER))
        val al = LinearLayout.LayoutParams(MATCH, dp(292))
        al.topMargin = dp(8)
        p.addView(area, al)

        // coloured keys: Red = accounts, Green = sort, Yellow = translate, Blue = Ask Titanium (same order as a TV remote)
        val colors = LinearLayout(this)
        colors.orientation = LinearLayout.HORIZONTAL
        colors.layoutDirection = View.LAYOUT_DIRECTION_LTR
        colors.addView(colorKey(tr("الحسابات", "Accounts"), "red", Color.parseColor("#E5484D"), Color.WHITE))
        colors.addView(colorKey(tr("ترتيب", "Sort"), "green", Color.parseColor("#2FBF71"), Color.parseColor("#06210F")))
        colors.addView(colorKey(tr("ترجمة", "Translate"), "yellow", Color.parseColor("#FFC21A"), Color.parseColor("#2A1E00")))
        colors.addView(colorKey(tr("اسأل تيتانيوم", "Ask Titanium"), "blue", Color.parseColor("#2B6FF0"), Color.WHITE))
        val cl2 = LinearLayout.LayoutParams(MATCH, WRAP)
        cl2.topMargin = dp(6)
        p.addView(colors, cl2)

        // media
        val media = row(spaced(keyBtn(R.drawable.ic_rw, "rw")), spaced(keyBtn(R.drawable.ic_play_pause, "play_pause", 72, 30)), spaced(keyBtn(R.drawable.ic_ff, "ff")))
        val ml = LinearLayout.LayoutParams(WRAP, WRAP)
        ml.topMargin = dp(8)
        p.addView(media, ml)

        val ch = row(spaced(labelKey("CH −", "ch_down"), 6), spaced(labelKey("CH +", "ch_up"), 6))
        p.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP))

        val unpair = Ui.pill(this, tr("إلغاء الربط", "Unpair TV"), Color.TRANSPARENT, Ui.RED, R.drawable.ic_tv, Ui.BORDER) { confirmUnpair() }
        val ul = LinearLayout.LayoutParams(WRAP, WRAP)
        ul.topMargin = dp(18)
        p.addView(unpair, ul)

        setPadMode(false)
        return p
    }

    private fun setPadMode(touch: Boolean) {
        padFrame.visibility = if (touch) View.GONE else View.VISIBLE
        touchFrame.visibility = if (touch) View.VISIBLE else View.GONE
        segPad.background = if (touch) null else Ui.rect(Ui.ACCENT_DEEP, 17)
        segTouch.background = if (touch) Ui.rect(Ui.ACCENT_DEEP, 17) else null
        segPad.setTextColor(if (touch) Ui.MUTED else Color.WHITE)
        segTouch.setTextColor(if (touch) Color.WHITE else Ui.MUTED)
    }

    private fun buildDpad(): View {
        val f = FrameLayout(this)
        f.background = Ui.oval(Ui.CARD, 1, Ui.BORDER)
        fun arrow(res: Int, dir: String, g: Int) {
            val v = ImageView(this)
            v.setImageResource(res)
            v.setColorFilter(Ui.TEXT)
            v.setPadding(dp(26), dp(26), dp(26), dp(26))
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.TRANSPARENT)
            val mask = GradientDrawable()
            mask.shape = GradientDrawable.OVAL
            mask.setColor(Color.WHITE)
            v.background = Ui.ripple(bg, mask)
            Ui.holdRepeat(v, true) { rep -> key(dir, "press", rep) }
            val lp = FrameLayout.LayoutParams(dp(86), dp(86), g)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            f.addView(v, lp)
        }
        arrow(R.drawable.ic_up, "up", Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        arrow(R.drawable.ic_down, "down", Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        arrow(R.drawable.ic_left, "left", Gravity.LEFT or Gravity.CENTER_VERTICAL)
        arrow(R.drawable.ic_right, "right", Gravity.RIGHT or Gravity.CENTER_VERTICAL)

        val ok = FrameLayout(this)
        ok.background = Ui.ripple(Ui.oval(Ui.ACCENT_DEEP), Ui.oval(Color.WHITE))
        val okText = Ui.text(this, "OK", 22f, Color.WHITE, 7)
        ok.addView(okText, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        Ui.holdKey(ok, { key("enter", "down") }, { key("enter", "up") })
        f.addView(ok, FrameLayout.LayoutParams(dp(104), dp(104), Gravity.CENTER))
        return f
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildTouchpad(): View {
        val f = FrameLayout(this)
        f.background = Ui.rect(Ui.CARD, 28, 1, Ui.BORDER)
        val hint = Ui.text(
            this,
            tr("مرّر للتنقل\nاضغط = OK", "Swipe to move\nTap = OK"), 14f, Ui.MUTED, 5
        )
        hint.gravity = Gravity.CENTER
        f.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        var sx = 0f
        var sy = 0f
        var moved = false
        var downAt = 0L
        val step = dp(46).toFloat()
        f.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.x
                    sy = ev.y
                    moved = false
                    downAt = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - sx
                    val dy = ev.y - sy
                    if (abs(dx) > step || abs(dy) > step) {
                        val k = if (abs(dx) > abs(dy)) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
                        key(k)
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        sx = ev.x
                        sy = ev.y
                        moved = true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downAt < 350) {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        key("enter")
                    }
                }
            }
            true
        }
        return f
    }

    private fun confirmUnpair() {
        AlertDialog.Builder(this)
            .setTitle(tr("إلغاء الربط؟", "Unpair the TV?"))
            .setMessage(tr("هتحتاج تربط التلفزيون من جديد بكود.", "You will need to pair again with a code."))
            .setPositiveButton(tr("إلغاء الربط", "Unpair")) { _, _ -> Hub.forgetAll() }
            .setNegativeButton(tr("رجوع", "Cancel"), null)
            .show()
    }

    // ------------------------------------------------------------------ pairing
    private fun scanQr() {
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(this, opts).startScan()
                .addOnSuccessListener { code ->
                    val m = Regex("(\\d{4})").find(code.rawValue ?: "")
                    if (m != null) handleCode(m.groupValues[1])
                    else toast(tr("الـ QR ده مش من التلفزيون", "That QR is not from the TV"))
                }
                .addOnFailureListener {
                    toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
                }
        } catch (_: Exception) {
            toast(tr("الماسح مش متاح — اكتب الكود يدويًا", "Scanner unavailable — type the code"))
        }
    }

    private fun handleCode(code: String) {
        if (code.length != 4 || !code.all { it.isDigit() }) return
        Hub.armCode(code)
        settingCode = true
        codeBox.setText(code)
        codeBox.setSelection(codeBox.text.length)
        settingCode = false
        hideKeyboard()
        selectTab(0)
        refresh()
    }

    // ------------------------------------------------------------------ IPTV source page
    private fun buildSourcePage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("مصدر IPTV", "IPTV source"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("ابعت بيانات الاشتراك للتلفزيون بدل ما تكتبها بالريموت. هتراجعها على التلفزيون وتضغط موافق.", "Send your subscription details to the TV instead of typing them with the remote. You confirm on the TV."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        val hl = LinearLayout.LayoutParams(WRAP, WRAP)
        hl.topMargin = dp(8)
        p.addView(hint, hl)

        var xtream = true
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.rect(Ui.SURF, 20, 1, Ui.BORDER)
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        val sx = Ui.text(this, "Xtream Codes", 13f, Ui.TEXT, 7)
        val sm = Ui.text(this, "M3U", 13f, Ui.TEXT, 7)
        for (t in listOf(sx, sm)) {
            t.gravity = Gravity.CENTER
            t.setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        seg.addView(sx)
        seg.addView(sm)
        val sgl = LinearLayout.LayoutParams(WRAP, WRAP)
        sgl.topMargin = dp(18)
        p.addView(seg, sgl)

        val server = field("http://host:port", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field(tr("اسم المستخدم", "Username"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
        val pass = field(tr("كلمة المرور", "Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        val m3u = field(tr("رابط M3U كامل (http / https)", "Full M3U link (http / https)"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        for (e in listOf(server, user, pass, m3u)) {
            e.textDirection = View.TEXT_DIRECTION_LTR
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(12)
            p.addView(e, lp)
        }
        fun render() {
            sx.background = if (xtream) Ui.rect(Ui.ACCENT_DEEP, 17) else null
            sm.background = if (xtream) null else Ui.rect(Ui.ACCENT_DEEP, 17)
            sx.setTextColor(if (xtream) Color.WHITE else Ui.MUTED)
            sm.setTextColor(if (xtream) Ui.MUTED else Color.WHITE)
            val xv = if (xtream) View.VISIBLE else View.GONE
            server.visibility = xv
            user.visibility = xv
            pass.visibility = xv
            m3u.visibility = if (xtream) View.GONE else View.VISIBLE
        }
        sx.setOnClickListener { xtream = true; render() }
        sm.setOnClickListener { xtream = false; render() }
        render()

        val send = Ui.pill(this, tr("ابعت للتلفزيون", "Send to TV"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) {
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else if (xtream) {
                val srv = server.text.toString().trim()
                val usr = user.text.toString().trim()
                val pwd = pass.text.toString()
                if (srv.isEmpty() || usr.isEmpty() || pwd.isEmpty()) {
                    toast(tr("اكتب السيرفر واسم المستخدم وكلمة المرور", "Enter server, username and password"))
                } else {
                    Hub.send(JSONObject().put("type", "iptv_credentials").put("format", "xtream").put("server", srv).put("username", usr).put("password", pwd))
                    toast(tr("اتبعت للتلفزيون — افتح «إضافة مصدر» عليه", "Sent — open “Add source” on the TV"))
                }
            } else {
                val url = m3u.text.toString().trim()
                if (!Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(url) || url.length > 2000) {
                    toast(tr("اكتب رابط M3U كامل", "Enter a complete M3U link"))
                } else {
                    Hub.send(JSONObject().put("type", "iptv_credentials").put("format", "m3u").put("url", url))
                    toast(tr("اتبعت للتلفزيون — افتح «إضافة مصدر» عليه", "Sent — open “Add source” on the TV"))
                }
            }
        }
        val snl = LinearLayout.LayoutParams(MATCH, WRAP)
        snl.topMargin = dp(22)
        p.addView(send, snl)
        return scrollPage(p)
    }

    // ------------------------------------------------------------------ keyboard page
    private fun buildKeyboardPage(): View {
        val p = vbox()
        p.addView(Ui.text(this, tr("الكيبورد", "Keyboard"), 22f, Ui.TEXT, 7))
        val hint = Ui.text(
            this,
            tr("افتح خانة كتابة على التلفزيون، واكتب هنا، وبعدين ابعت. النص بيتحط في الخانة المفتوحة.", "Open a text field on the TV, type here, then send. The text goes into the open field."),
            13f, Ui.MUTED, 4
        )
        hint.setLineSpacing(dp(3).toFloat(), 1f)
        val hl = LinearLayout.LayoutParams(WRAP, WRAP)
        hl.topMargin = dp(8)
        p.addView(hint, hl)

        val box = field(tr("اكتب هنا…", "Type here…"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        box.minLines = 4
        box.gravity = Gravity.TOP
        val bl = LinearLayout.LayoutParams(MATCH, WRAP)
        bl.topMargin = dp(16)
        p.addView(box, bl)

        val send = Ui.pill(this, tr("ابعت النص", "Send text"), Ui.ACCENT_DEEP, Color.WHITE, R.drawable.ic_send) {
            val v = box.text.toString()
            if (!Hub.isPaired()) {
                toast(tr("اربط التلفزيون الأول", "Pair the TV first"))
            } else if (v.isBlank()) {
                toast(tr("اكتب حاجة الأول", "Type something first"))
            } else {
                Hub.send(JSONObject().put("type", "text").put("text", v))
                box.text.clear()
                toast(tr("اتبعت للتلفزيون", "Sent to the TV"))
            }
        }
        val sl = LinearLayout.LayoutParams(MATCH, WRAP)
        sl.topMargin = dp(18)
        p.addView(send, sl)
        return scrollPage(p)
    }

    // ------------------------------------------------------------------ state
    private fun refresh() {
        val paired = Hub.isPaired()
        pairPanel.visibility = if (paired) View.GONE else View.VISIBLE
        remotePanel.visibility = if (paired) View.VISIBLE else View.GONE

        val seen = System.currentTimeMillis() - Hub.lastSeen < 7000
        val err = Hub.error
        val dot: Int
        val label: String
        if (!Hub.running && err != null) {
            dot = Ui.RED
            label = tr("السيرفر واقف", "Server stopped")
        } else if (!paired) {
            dot = Ui.MUTED
            label = tr("مش مربوط", "Not paired")
        } else if (seen) {
            dot = Ui.GREEN
            label = tr("التلفزيون متصل", "TV connected")
        } else {
            dot = Ui.AMBER
            label = tr("مربوط • التلفزيون مش متصل", "Paired • TV offline")
        }
        chipDot.background = Ui.oval(dot)
        chipText.text = label

        if (!paired) {
            val c = Hub.pendingCode
            if (Hub.mismatch && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.RED)
                pairStatus.text = tr("الكود اللي على التلفزيون مختلف. اتأكد من الأرقام.", "The code on the TV is different. Check the digits.")
            } else if (c != null && Hub.codeActive()) {
                pairStatus.setTextColor(Ui.AMBER)
                pairStatus.text = tr("بانتظار التلفزيون… سيب شاشة «ريموت الهاتف» مفتوحة عليه.", "Waiting for the TV… keep the “Phone remote” screen open on it.")
            } else {
                pairStatus.setTextColor(Ui.MUTED)
                pairStatus.text = ""
            }
            val ip = Hub.localIp()
            pairIp.text = if (ip.isEmpty()) "" else tr("عنوان الموبايل: $ip", "Phone address: $ip")
        }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val v = currentFocus ?: root
            im.hideSoftInputFromWindow(v.windowToken, 0)
        } catch (_: Exception) {
        }
    }
}

# TitaniumTV 0.3.503 — Titanium Remote protocol v1

This Android project implements the phone-side HTTP server expected by `TitaniumTVbeta3_503.wgt`.

## Pairing
1. Put the Android phone and Samsung TV on the same Wi-Fi/LAN.
2. Open Titanium Remote and keep it in the foreground.
3. On the TV open Settings → Phone remote.
4. Enter the phone's displayed IPv4 address (port 8765 is the default) and pairing code.
5. The TV performs `GET /health`, then `GET /pair` with `X-Titanium-Token: <pairing code>`.

## Polling
After pairing, the TV polls `GET /next` with the same `X-Titanium-Token` header. The phone returns one queued JSON event or `{"type":"none"}`.

### Text event
```json
{"type":"text","text":"typed text"}
```

### Xtream Codes event
```json
{"type":"iptv_credentials","format":"xtream","server":"http://host:port","username":"user","password":"pass"}
```

### M3U event
```json
{"type":"iptv_credentials","format":"m3u","url":"https://example.test/list.m3u"}
```

The WGT fills its existing Add Source form. The user must review and confirm on the TV; this app does not save a subscription by itself.

## HTTP behavior
- Port: TCP 8765, bound to all IPv4 interfaces.
- Routes: `GET /health`, `GET /pair`, `GET /next`, `GET /ack`.
- `OPTIONS` is answered with CORS headers, including `Access-Control-Allow-Headers: X-Titanium-Token, Content-Type`, to support browser/XHR preflight if the TV runtime requests it.
- Responses are JSON, no-store, and connection-close.
- Protocol version: `1`; health response app name must be exactly `Titanium Remote`.

## Security and limitations
This is a local-network prototype. HTTP and the pairing token are not encrypted; use only on a trusted private Wi-Fi network, never port-forward 8765 to the internet. Keep the app open while connected. Android may stop the server if the app is backgrounded or the OS kills it. The WGT itself only acts on `text` and `iptv_credentials` events.

## 0.3.504 / app 2.0 additions
- `GET /health` also returns `id`, `name`, `pairable`.
- First pairing: TV shows a 4-digit code; the phone user enters/scans it; the TV scans its /24 for `/health`, then `GET /pair` with `X-Titanium-Code: <code>`. A matching code returns `{"paired":true,"token":"<32 hex>"}`. The TV stores token + phone id and later authenticates with `X-Titanium-Token`. Five different wrong codes lock pairing for 60 s.
- `/next` is a long poll (≤ 2.5 s, `"lp":true` on empty answers).
- New event: `{"type":"key","key":"up|down|left|right|enter|back|home|play_pause|ff|rw|ch_up|ch_down|info","action":"press|down|up","rep":false}`.

## 2.0 remote top-row shortcuts
The phone app's remote screen has a top row with three direct-jump keys plus a Settings
shortcut (the Settings button is local to the phone app and sends nothing to the TV).
These three send the existing `key` event with new `key` values:
- `live` — jump straight to the Live section (and Today's Matches, if present).
- `movies` — jump straight to All Movies.
- `series` — jump straight to All Series.

## TV-side implementation status (as of this pass)
A first pass at the TV side has been written into `app.js` (a self-contained block appended
near the end of the file, plus a "Phone remote" row in Settings → Server & playback that shows
the pairing code / status). It implements: pairing (code generation + a /24 subnet scan calling
`/health` then `/pair`), the `/next` long-poll loop, and `key` / `text` / `iptv_credentials`
event handling (`live`/`movies`/`series`/`home` call the app's internal navigation functions
directly; the rest dispatch synthetic keydown/keyup events with the same keyCodes the physical
remote uses).

**This has not been run on a real TV or emulator** — there was no device or Tizen tooling
available while writing it. Known soft spots, in rough priority order:
1. `prScan()` only tries `192.168.{0,1,2,43}.x` and `10.0.0.x` — a TV on another subnet will
   never find the phone. The real fix is reading the TV's own IP (Tizen `systeminfo` /
   `connectivitymanager` API) and deriving the /24 from that.
2. The synthetic `KeyboardEvent` + `Object.defineProperty(ev, 'keyCode', ...)` dispatch trick
   needs confirming against Tizen's actual WebKit build — it's a well-known Chromium workaround
   but untested here.
2. `prApplyIptv()` (the `iptv_credentials` event) opens Settings → Sources but does not fill
   the Add Source form fields yet — it's a stub pending the form's exact field ids.
3. `info` is still a no-op: Tizen's key registration list already includes it, but no existing
   keydown handler in `app.js` reacts to it, so there was nothing safe to hook it to.

Next useful step: get this onto a real TV (or the Tizen TV emulator) and fix whatever the first
pairing attempt reveals — almost certainly #1 above.

## 2.1 coloured keys + TV Settings key
New `key` values sent by the phone's remote screen:
- `red` (403) - profiles/accounts page, `green` (404) - sort categories, `yellow` (405) - translate title / refresh Home suggestions, `blue` (406) - Ask Titanium.
- `settings` - opens the TV app's Settings on the TV screen (TV app 0.3.505+). The top-row gear now sends this; the phone's own settings are behind the gear in the header.

package com.titanium.remote

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.LinkedBlockingDeque

/** Shared state between the UI, the foreground service and the HTTP server. */
object Hub {
    const val PORT = 8765
    val queue = LinkedBlockingDeque<JSONObject>()

    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val rnd = SecureRandom()

    @Volatile var running = false
    @Volatile var error: String? = null
    @Volatile var lastSeen = 0L
    @Volatile var splashDone = false
    @Volatile var mismatch = false
    @Volatile var onChange: (() -> Unit)? = null

    @Volatile var pendingCode: String? = null
    @Volatile private var pendingUntil = 0L
    @Volatile private var lockUntil = 0L
    private val tried = HashSet<String>()

    /** App language: "" = follow the phone, "ar" or "en" = chosen in the app settings. */
    fun lang(): String = if (::prefs.isInitialized) prefs.getString("lang", "") ?: "" else ""

    fun setLang(l: String) {
        if (::prefs.isInitialized) prefs.edit().putString("lang", l).apply()
    }

    val ar: Boolean get() = when (lang()) {
        "ar" -> true
        "en" -> false
        else -> Locale.getDefault().language == "ar"
    }

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences("titanium_remote", Context.MODE_PRIVATE)
        }
    }

    private fun randomHex(bytes: Int): String {
        val b = ByteArray(bytes)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun deviceId(): String {
        var id = prefs.getString("id", null)
        if (id == null) {
            id = randomHex(8)
            prefs.edit().putString("id", id).apply()
        }
        return id
    }

    fun deviceName(): String = android.os.Build.MODEL ?: "Android"

    /** Play the TV intro sound together with the phone intro (on by default, same as the TV). */
    fun introSound(): Boolean = ::prefs.isInitialized && prefs.getBoolean("intro_sound", true)

    fun setIntroSound(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("intro_sound", on).apply()
    }

    /** Remote page shows the touchpad instead of the arrows pad (set from the phone settings). */
    fun touchMode(): Boolean = ::prefs.isInitialized && prefs.getBoolean("touch_mode", false)

    fun setTouchMode(on: Boolean) {
        if (::prefs.isInitialized) prefs.edit().putBoolean("touch_mode", on).apply()
    }

    /** Remote page layout: 0 = classic, 1 = arcs (chosen in the phone settings). */
    fun layout(): Int = if (::prefs.isInitialized) prefs.getInt("layout", 0) else 0

    fun setLayout(l: Int) {
        if (::prefs.isInitialized) prefs.edit().putInt("layout", l).apply()
    }

    // ---- saved TV pairings (long random tokens, stored on the phone) ----
    private fun tokenList(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(prefs.getString("tokens", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun isPaired(): Boolean = tokenList().isNotEmpty()

    fun validToken(t: String?): Boolean = !t.isNullOrEmpty() && tokenList().contains(t)

    @Synchronized
    private fun addToken(): String {
        val t = randomHex(16)
        val l = tokenList()
        l.add(t)
        while (l.size > 5) l.removeAt(0)
        prefs.edit().putString("tokens", JSONArray(l).toString()).apply()
        return t
    }

    fun forgetAll() {
        prefs.edit().remove("tokens").apply()
        queue.clear()
        pendingCode = null
        changed()
    }

    // ---- 4-digit pairing code shown on the TV and typed / scanned on the phone ----
    fun armCode(code: String) {
        synchronized(this) {
            pendingCode = code
            pendingUntil = System.currentTimeMillis() + 5 * 60_000L
            tried.clear()
            mismatch = false
        }
        changed()
    }

    fun disarm() {
        pendingCode = null
        mismatch = false
        changed()
    }

    fun codeActive(): Boolean = pendingCode != null && System.currentTimeMillis() < pendingUntil

    /** Returns (token, "") when the TV's code matches the one entered on the phone, else (null, reason). */
    @Synchronized
    fun tryPair(code: String): Pair<String?, String> {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return Pair(null, "locked")
        if (!codeActive()) return Pair(null, "need_code")
        if (code == pendingCode) {
            pendingCode = null
            mismatch = false
            tried.clear()
            val t = addToken()
            changed()
            return Pair(t, "")
        }
        // the same wrong code retried by the TV does not count; many DIFFERENT guesses lock pairing for a minute
        val fresh = tried.add(code)
        val wasMismatch = mismatch
        mismatch = true
        if (tried.size >= 5) {
            lockUntil = now + 60_000L
            pendingCode = null
            tried.clear()
            changed()
        } else if (fresh || !wasMismatch) {
            changed()
        }
        return Pair(null, "bad_code")
    }

    // ---- saved IPTV sources (kept on the phone, sent to the TV on demand) ----
    class Src(
        val id: String,
        var name: String,
        var xtream: Boolean,
        var server: String = "",
        var user: String = "",
        var pass: String = "",
        var url: String = ""
    ) {
        /** Name shown in the list: the playlist name if given, else the host (and user for Xtream). */
        fun title(): String {
            if (name.isNotBlank()) return name
            val h = hostOf(if (xtream) server else url)
            return if (xtream && user.isNotBlank()) "$h · $user" else h
        }

        fun subtitle(): String =
            if (xtream) "Xtream · " + hostOf(server) + " · " + user else "M3U · " + hostOf(url)
    }

    fun hostOf(s: String): String =
        s.trim().replace(Regex("^[a-zA-Z]+://"), "").substringBefore('/').ifEmpty { s }

    fun newSourceId(): String = randomHex(4)

    @Synchronized
    fun sources(): MutableList<Src> {
        val out = mutableListOf<Src>()
        try {
            val a = JSONArray(prefs.getString("sources", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Src(
                        o.getString("id"), o.optString("name"), o.optString("fmt") != "m3u",
                        o.optString("server"), o.optString("user"), o.optString("pass"), o.optString("url")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeSources(l: List<Src>) {
        val a = JSONArray()
        for (s in l) {
            a.put(
                JSONObject().put("id", s.id).put("name", s.name).put("fmt", if (s.xtream) "xtream" else "m3u")
                    .put("server", s.server).put("user", s.user).put("pass", s.pass).put("url", s.url)
            )
        }
        prefs.edit().putString("sources", a.toString()).apply()
    }

    /** Adds the source, or replaces the one with the same id. */
    @Synchronized
    fun saveSource(s: Src) {
        val l = sources()
        val i = l.indexOfFirst { it.id == s.id }
        if (i >= 0) l[i] = s else l.add(s)
        writeSources(l)
    }

    @Synchronized
    fun deleteSource(id: String) {
        writeSources(sources().filter { it.id != id })
    }

    /** The event the TV expects; "name" is only added when the user gave one. */
    fun sourceEvent(s: Src): JSONObject {
        val e = JSONObject().put("type", "iptv_credentials")
        if (s.xtream) e.put("format", "xtream").put("server", s.server).put("username", s.user).put("password", s.pass)
        else e.put("format", "m3u").put("url", s.url)
        if (s.name.isNotBlank()) e.put("name", s.name)
        return e
    }

    fun send(e: JSONObject) {
        while (queue.size > 60) queue.poll()
        try {
            e.put("t", System.currentTimeMillis())
        } catch (_: Exception) {
        }
        queue.offer(e)
    }

    fun changed() {
        main.post { onChange?.invoke() }
    }

    fun localIp(): String {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            var fallback = ""
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ni.name.startsWith("wlan")) return ip
                        if (fallback.isEmpty()) fallback = ip
                    }
                }
            }
            if (fallback.isNotEmpty()) return fallback
        } catch (_: Exception) {
        }
        return ""
    }
}

package com.titanium.remote

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot

/**
 * Remote layout canvas. Children are placed by their centre and diameter in a fixed design space
 * (DESIGN_W x DESIGN_H dp, taken from the user's layout sketch) and the whole thing is scaled uniformly to fit the page.
 */
class DesignCanvas(ctx: Context) : ViewGroup(ctx) {
    companion object {
        const val DESIGN_W = 360f
        const val DESIGN_H = 640f
        const val MAX_SCALE = 1.3f
    }

    private class Spec(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val specs = HashMap<View, Spec>()

    fun put(v: View, cx: Float, cy: Float, d: Float) = put(v, cx, cy, d, d)

    /** Rectangular child (pill keys): centre + width + height in design dp. */
    fun put(v: View, cx: Float, cy: Float, w: Float, h: Float) {
        specs[v] = Spec(cx, cy, w, h)
        addView(v)
    }

    private fun scale(w: Int, h: Int): Float {
        val dn = Ui.density
        return minOf(w / (DESIGN_W * dn), h / (DESIGN_H * dn), MAX_SCALE)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        val k = scale(w, h) * Ui.density
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val s = specs[c] ?: continue
            c.measure(MeasureSpec.makeMeasureSpec((s.w * k).toInt(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec((s.h * k).toInt(), MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val k = scale(w, h) * Ui.density
        val ox = (w - DESIGN_W * k) / 2f
        val oy = (h - DESIGN_H * k) / 2f
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val s = specs[c] ?: continue
            val x = (ox + s.cx * k - c.measuredWidth / 2f).toInt()
            val y = (oy + s.cy * k - c.measuredHeight / 2f).toInt()
            c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight)
        }
    }
}

/** Flat round key whose icon is a fraction of the key's own size (so it scales with the canvas). */
class DiscKey(ctx: Context, res: Int, iconFrac: Float, private val bg: Int, tint: Int, desc: String, private val corner: Float = 0.5f, private val outline: Int = 0) : FrameLayout(ctx) {
    private val frac = iconFrac
    private val icon = ImageView(ctx)

    init {
        contentDescription = desc
        background = Ui.ripple(Ui.oval(bg, if (outline != 0) 2 else 0, outline), Ui.oval(Color.WHITE))
        icon.setImageResource(res)
        icon.setColorFilter(tint)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(icon, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val p = (w * (1f - frac) / 2f).toInt()
        icon.setPadding(p, p, p, p)
        if (corner < 0.5f) {   // squircle keys (left column)
            val rad = w * corner
            fun sq(c: Int) = android.graphics.drawable.GradientDrawable().also { it.setColor(c); it.cornerRadius = rad }
            background = Ui.ripple(sq(bg), sq(Color.WHITE))
        }
    }
}

/** Wide rounded key (icon + caption) used for Sort & Filter / Settings / Previous / Next / Reorder categories. The caption scales with the key. */
class PillKey(ctx: Context, res: Int, label: String, private val bg: Int, fg: Int, desc: String, private val iconAfter: Boolean = false) : LinearLayout(ctx) {
    private val icon = ImageView(ctx)
    private val caption = TextView(ctx)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        layoutDirection = LAYOUT_DIRECTION_LTR
        contentDescription = desc
        icon.setImageResource(res)
        icon.setColorFilter(fg)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        caption.text = label
        caption.setTextColor(fg)
        caption.typeface = Ui.f7
        caption.maxLines = 1
        caption.includeFontPadding = false
        if (iconAfter) { addView(caption); addView(icon) } else { addView(icon); addView(caption) }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val ic = (h * 0.46f).toInt()
        val gap = (h * 0.24f).toInt()
        val lp = LayoutParams(ic, ic)
        if (iconAfter) lp.leftMargin = gap else lp.rightMargin = gap
        icon.layoutParams = lp
        caption.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.33f)
        fun sq(c: Int) = android.graphics.drawable.GradientDrawable().also { it.setColor(c); it.cornerRadius = h * 0.34f }
        background = Ui.ripple(sq(bg), sq(Color.WHITE))
    }
}

/**
 * Big black ring with the dark OK disc in the middle. No arrow glyphs are drawn: the ring is split into four
 * quadrants (up / right / down / left, hold to repeat) and the centre disc is OK (press & hold sends down / up).
 * In touchpad mode the same surface is a swipe pad (swipe = arrow, tap = OK).
 */
class PadFace(ctx: Context, private val night: Boolean, private val send: (key: String, action: String, rep: Boolean) -> Unit) : View(ctx) {
    var touchMode = false

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(if (night) "#16181B" else "#080B0E") }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(if (night) 130 else 70, 255, 255, 255)
    }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 255, 255, 255) }
    private val box = RectF()

    private val h = Handler(Looper.getMainLooper())
    private var held: String? = null     // "up" / "down" / "left" / "right" / "enter"
    private val tick = object : Runnable {
        override fun run() {
            val k = held ?: return
            if (k != "enter") send(k, "press", true)
            h.postDelayed(this, 110)
        }
    }

    // swipe state (touch mode)
    private var sx = 0f
    private var sy = 0f
    private var moved = false
    private var downAt = 0L

    override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, hh, ow, oh)
        val r = w / 4f   // centre disc radius = half the ring radius
        disc.color = Color.parseColor(if (night) "#34373B" else "#1E2023")   // flat OK disc
        edge.strokeWidth = Math.max(1f, w / 250f)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val R = width / 2f
        val r = R * 0.42f   // OK disc as in the reference design (the tap zone in zone() stays R / 2)
        c.drawCircle(cx, cy, R, ring)
        // pressed quadrant highlight (arrows mode only)
        val k = held
        if (!touchMode && k != null && k != "enter") {
            val start = when (k) { "up" -> -135f; "right" -> -45f; "down" -> 45f; else -> 135f }
            box.set(cx - R, cy - R, cx + R, cy + R)
            c.drawArc(box, start, 90f, true, hi)
            c.drawCircle(cx, cy, r + 2f, ring)
        }
        c.drawCircle(cx, cy, r, disc)
        c.drawCircle(cx, cy, r, edge)
        if (k == "enter" || (touchMode && held != null)) c.drawCircle(cx, cy, r, hi)
    }

    private fun zone(x: Float, y: Float): String {
        val dx = x - width / 2f
        val dy = y - height / 2f
        if (hypot(dx, dy) < width / 4f) return "enter"
        val a = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))   // 0 = right, 90 = down
        return when {
            a >= -45 && a < 45 -> "right"
            a >= 45 && a < 135 -> "down"
            a >= -135 && a < -45 -> "up"
            else -> "left"
        }
    }

    private fun inside(x: Float, y: Float) = hypot(x - width / 2f, y - height / 2f) <= width / 2f

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (touchMode) return touchpad(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!inside(ev.x, ev.y)) return false
                val z = zone(ev.x, ev.y)
                held = z
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (z == "enter") send("enter", "down", false) else {
                    send(z, "press", false)
                    h.postDelayed(tick, 380)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    private fun release() {
        val k = held
        h.removeCallbacks(tick)
        held = null
        if (k == "enter") send("enter", "up", false)
        invalidate()
    }

    private val step get() = Ui.dp(46) * width / (252f * Ui.density)

    private fun touchpad(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!inside(ev.x, ev.y)) return false
                sx = ev.x; sy = ev.y; moved = false; downAt = System.currentTimeMillis()
                held = "enter"; invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - sx
                val dy = ev.y - sy
                if (abs(dx) > step || abs(dy) > step) {
                    val k = if (abs(dx) > abs(dy)) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
                    send(k, "press", false)
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    sx = ev.x; sy = ev.y; moved = true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && System.currentTimeMillis() - downAt < 350) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    send("enter", "press", false)
                }
                held = null; invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { held = null; invalidate() }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        h.removeCallbacks(tick)
        held = null
        super.onDetachedFromWindow()
    }
}

/**
 * "Arcs" layout: four curved keys around the direction pad, one on each diagonal (top-left, top-right, bottom-right, bottom-left).
 * Design space: 220 x 220 units centred on the pad; the band runs from radius 66 to 106. Each key = band + icon + a caption that follows the curve.
 */
class ArcRing(ctx: Context, night: Boolean, private val items: List<Arc>, private val send: (String) -> Unit) : View(ctx) {
    class Arc(val res: Int, val label: String, val tint: Int, val key: String)

    private val mids = floatArrayOf(-135f, -45f, 45f, 135f)   // TL, TR, BR, BL (degrees, 0 = right, clockwise)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor(if (night) "#16181B" else "#080B0E") }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(if (night) 110 else 60, 255, 255, 255) }
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(46, 255, 255, 255) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Ui.f7 }
    private val icons = items.map { a -> context.getDrawable(a.res)?.mutate()?.also { it.setTint(a.tint) } }
    private val box = RectF()
    private val path = Path()
    private var pressed = -1

    private fun u() = width / 220f

    override fun onDraw(c: Canvas) {
        val k = u()
        val cx = width / 2f
        val cy = height / 2f
        val band = 34f * k
        val ew = Math.max(1f, k * 0.9f)
        box.set(cx - 88f * k, cy - 88f * k, cx + 88f * k, cy + 88f * k)
        for (i in items.indices) {
            val mid = mids[i]
            path.reset()
            path.addArc(box, mid - 29f, 58f)
            edge.strokeWidth = band + 2f * ew
            c.drawPath(path, edge)
            fill.strokeWidth = band
            c.drawPath(path, fill)
            if (pressed == i) { hi.strokeWidth = band; c.drawPath(path, hi) }

            // icon on the outer half of the band
            val a = Math.toRadians(mid.toDouble())
            val ix = cx + cos(a).toFloat() * 96f * k
            val iy = cy + sin(a).toFloat() * 96f * k
            val half = 8f * k
            // the icon is turned to follow the segment, like the caption
            c.save()
            c.rotate(if (i < 2) mid + 90f else mid - 90f, ix, iy)
            icons[i]?.let { d -> d.setBounds((ix - half).toInt(), (iy - half).toInt(), (ix + half).toInt(), (iy + half).toInt()); d.draw(c) }
            c.restore()

            // caption on the inner half, following the curve (always reads left to right)
            val top = i < 2
            val r = (if (top) 76f else 84f) * k
            val sw = if (top) 52f else -52f
            val st = if (top) mid - 26f else mid + 26f
            val tb = RectF(cx - r, cy - r, cx + r, cy + r)
            val tp = Path()
            tp.addArc(tb, st, sw)
            val len = (r * Math.toRadians(52.0)).toFloat()
            var size = 9.5f * k
            txt.textSize = size
            while (size > 5f * k && txt.measureText(items[i].label) > len - 6f * k) { size -= 0.5f * k; txt.textSize = size }
            val off = Math.max(0f, (len - txt.measureText(items[i].label)) / 2f)
            c.drawTextOnPath(items[i].label, tp, off, 0f, txt)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val k = u()
                val dx = ev.x - width / 2f
                val dy = ev.y - height / 2f
                val r = hypot(dx, dy) / k
                if (r < 68f || r > 110f) return false
                val ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                var best = -1
                var bd = 999f
                for (i in mids.indices) {
                    var d = abs(ang - mids[i]) % 360f
                    if (d > 180f) d = 360f - d
                    if (d < bd) { bd = d; best = i }
                }
                if (best < 0 || bd > 40f) return false
                pressed = best
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                send(items[best].key)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }
}
